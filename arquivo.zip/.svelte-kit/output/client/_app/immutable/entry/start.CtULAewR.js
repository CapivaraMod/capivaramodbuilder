import{a as t}from"../chunks/entry.DuWPDUlt.js";export{t as start};
