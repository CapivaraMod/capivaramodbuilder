export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["icon.ico","icon.png","icon.svg"]),
	mimeTypes: {".png":"image/png",".svg":"image/svg+xml"},
	_: {
		client: {"start":"_app/immutable/entry/start.CtULAewR.js","app":"_app/immutable/entry/app.DAx5cob3.js","imports":["_app/immutable/entry/start.CtULAewR.js","_app/immutable/chunks/entry.DuWPDUlt.js","_app/immutable/chunks/scheduler.B1eZZyvF.js","_app/immutable/chunks/index.Bk2mAaNR.js","_app/immutable/entry/app.DAx5cob3.js","_app/immutable/chunks/scheduler.B1eZZyvF.js","_app/immutable/chunks/index.Cxp2rW5O.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
