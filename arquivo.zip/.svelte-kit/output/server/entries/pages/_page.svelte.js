import { c as create_ssr_component, b as createEventDispatcher, d as add_attribute, e as escape, f as add_styles, a as subscribe, v as validate_component, h as each } from "../../chunks/ssr.js";
import Blockly from "blockly/core.js";
import En from "blockly/msg/en.js";
import PtBr from "blockly/msg/pt-br.js";
import Es from "blockly/msg/es.js";
import "blockly/blocks.js";
import gen from "blockly/javascript.js";
import "jszip";
import "file-saver";
import * as ContinuousToolboxPlugin from "@blockly/continuous-toolbox";
import { w as writable } from "../../chunks/index.js";
import beautify from "js-beautify";
import Prism from "prismjs";
const ToolboxFlyout = (Blockly2, config, workspace) => {
  Blockly2.VerticalFlyout.prototype.getFlyoutScale = function() {
    return config.zoom.startScale;
  };
  Blockly2.VerticalFlyout.prototype.reflowInternal_ = function() {
    this.workspace_.scale = this.getFlyoutScale();
    let flyoutWidth = 0;
    const blocks2 = this.workspace_.getTopBlocks(false);
    for (let i = 0, block; block = blocks2[i]; i++) {
      let width = block.getHeightWidth().width;
      if (block.outputConnection) {
        width -= this.tabWidth_;
      }
      flyoutWidth = Math.max(flyoutWidth, width);
    }
    for (let i = 0, button; button = this.buttons_[i]; i++) {
      flyoutWidth = Math.max(flyoutWidth, button.width);
    }
    flyoutWidth += this.MARGIN * 1.5 + this.tabWidth_;
    flyoutWidth *= this.workspace_.scale;
    flyoutWidth += Blockly2.Scrollbar.scrollbarThickness;
    flyoutWidth = Math.min(
      flyoutWidth,
      320
    );
    if (this.width_ !== flyoutWidth) {
      for (let i = 0, block; block = blocks2[i]; i++) {
        if (this.rectMap_.has(block)) {
          this.moveRectToBlock_(this.rectMap_.get(block), block);
        }
      }
      if (this.targetWorkspace.toolboxPosition === this.toolboxPosition_ && this.toolboxPosition_ === Blockly2.utils.toolbox.Position.LEFT && !this.targetWorkspace.getToolbox()) {
        this.targetWorkspace.translate(
          this.targetWorkspace.scrollX + flyoutWidth,
          this.targetWorkspace.scrollY
        );
      }
      this.width_ = flyoutWidth;
      this.position();
      this.targetWorkspace.resizeContents();
      this.targetWorkspace.recordDragTargets();
    }
  };
  const Svg = Blockly2.utils.Svg;
  const dom = Blockly2.utils.dom;
  const parsing = Blockly2.utils.parsing;
  const style = Blockly2.utils.style;
  Blockly2.FlyoutButton.prototype.createDom = function() {
    let cssClass = this.isLabel_ ? "blocklyFlyoutLabel" : "blocklyFlyoutButton";
    if (this.cssClass_) {
      cssClass += " " + this.cssClass_;
    }
    this.svgGroup_ = dom.createSvgElement(
      Svg.G,
      { "class": cssClass },
      this.workspace.getCanvas()
    );
    const rect = dom.createSvgElement(
      Svg.RECT,
      {
        "class": this.isLabel_ ? "blocklyFlyoutLabelBackground" : "blocklyFlyoutButtonBackground",
        "rx": Blockly2.FlyoutButton.BORDER_RADIUS,
        "ry": Blockly2.FlyoutButton.BORDER_RADIUS
      },
      this.svgGroup_
    );
    const svgText = dom.createSvgElement(
      Svg.TEXT,
      {
        "class": this.isLabel_ ? "blocklyFlyoutLabelText" : "blocklyText",
        "x": 0,
        "y": 0,
        "text-anchor": "middle"
      },
      this.svgGroup_
    );
    let text = parsing.replaceMessageReferences(this.text_);
    if (this.workspace.RTL) {
      text += "‏";
    }
    svgText.textContent = text;
    if (this.isLabel_) {
      this.svgText_ = svgText;
      this.workspace.getThemeManager().subscribe(
        this.svgText_,
        "flyoutForegroundColour",
        "fill"
      );
    }
    const fontSize = style.getComputedStyle(svgText, "fontSize");
    const fontWeight = style.getComputedStyle(svgText, "fontWeight");
    const fontFamily = style.getComputedStyle(svgText, "fontFamily");
    this.width = dom.getFastTextWidthWithSizeString(
      svgText,
      fontSize,
      fontWeight,
      fontFamily
    );
    const fontMetrics = dom.measureFontMetrics(text, fontSize, fontWeight, fontFamily);
    this.height = fontMetrics.height;
    if (!this.isLabel_) {
      this.width += 4 * Blockly2.FlyoutButton.TEXT_MARGIN_X;
      this.height += 6 * Blockly2.FlyoutButton.TEXT_MARGIN_Y;
    }
    rect.setAttribute("width", String(this.width));
    rect.setAttribute("height", String(this.height));
    svgText.setAttribute("x", String(this.width / 2));
    svgText.setAttribute(
      "y",
      String(
        this.height / 2 - fontMetrics.height / 2 + fontMetrics.baseline
      )
    );
    this.updateTransform_();
    this.onMouseUpWrapper_ = Blockly2.browserEvents.conditionalBind(
      this.svgGroup_,
      "pointerup",
      this,
      this.onMouseUp_
    );
    return this.svgGroup_;
  };
};
const svgPaths = Blockly.utils.svgPaths;
class CustomConstantProvider extends Blockly.zelos.ConstantProvider {
  constructor() {
    super();
    this.NOTCH_WIDTH = 6 * this.GRID_UNIT;
    this.NOTCH_HEIGHT = 1.5 * this.GRID_UNIT;
  }
  init() {
    super.init();
    this.FIELD_TEXT_FONTSIZE = 11;
    this.FIELD_TEXT_FONTFAMILY = "Noto Sans";
    this.ADD_START_HATS = true;
    this.PLUS = this.makePlus();
    this.LEAF = this.makeLeaf();
  }
  /** @returns {import("blockly/core/renderers/common/constants").Shape} */
  makePlus() {
    const radius = this.CORNER_RADIUS;
    function makeMainPath(blockHeight, up, right) {
      return svgPaths.arc(
        "a",
        "0 0,1",
        radius,
        svgPaths.point(
          (up ? -1 : 1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.arc(
        "a",
        "0 0,0",
        radius,
        svgPaths.point(
          (up ? -1 : 1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.lineOnAxis("h", (right ? 1 : -1) * radius / 2) + svgPaths.arc(
        "a",
        "0 0,1",
        radius,
        svgPaths.point(
          (up ? -1 : 1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.lineOnAxis("v", (right ? 1 : -1) * (blockHeight - radius * 6)) + svgPaths.arc(
        "a",
        "0 0,1",
        radius,
        svgPaths.point(
          (up ? 1 : -1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.lineOnAxis("h", (right ? -1 : 1) * radius / 2) + svgPaths.arc(
        "a",
        "0 0,0",
        radius,
        svgPaths.point(
          (up ? 1 : -1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.arc(
        "a",
        "0 0,1",
        radius,
        svgPaths.point(
          (up ? 1 : -1) * radius,
          (up ? -1 : 1) * radius
        )
      );
    }
    return {
      type: this.SHAPES.HEXAGONAL,
      isDynamic: true,
      width(height) {
        const halfHeight = height / 2;
        const maxWidth = radius * 4;
        return halfHeight > maxWidth ? maxWidth : halfHeight;
      },
      height(height) {
        return height;
      },
      connectionOffsetY(connectionHeight) {
        return connectionHeight / 2;
      },
      connectionOffsetX(connectionWidth) {
        return -connectionWidth;
      },
      pathDown(height) {
        return makeMainPath(height, false, false);
      },
      pathUp(height) {
        return makeMainPath(height, true, false);
      },
      pathRightDown(height) {
        return makeMainPath(height, false, true);
      },
      pathRightUp(height) {
        return makeMainPath(height, false, true);
      }
    };
  }
  /** @returns {import("blockly/core/renderers/common/constants").Shape} */
  makeLeaf() {
    const maxWidth = this.MAX_DYNAMIC_CONNECTION_SHAPE_WIDTH;
    const maxHeight = maxWidth * 2;
    const makeMainPath = (blockHeight, up, right) => {
      const remainingHeight = blockHeight > maxHeight ? blockHeight - maxHeight : 0;
      const height = blockHeight > maxHeight ? maxHeight : blockHeight;
      const radius = height / 2;
      return svgPaths.arc(
        "a",
        "0 0,1",
        radius,
        svgPaths.point(
          (up ? -1 : 1) * radius,
          (up ? -1 : 1) * radius
        )
      ) + svgPaths.lineOnAxis("v", (right ? 1 : -1) * (remainingHeight + radius - this.CORNER_RADIUS)) + svgPaths.arc(
        "a",
        "0 0,1",
        this.CORNER_RADIUS,
        svgPaths.point((up ? 1 : -1) * this.CORNER_RADIUS, (up ? -1 : 1) * this.CORNER_RADIUS)
      ) + svgPaths.lineOnAxis("h", (right ? -1 : 1) * (radius - this.CORNER_RADIUS));
    };
    return {
      type: this.SHAPES.SQUARE,
      isDynamic: true,
      width(height) {
        const halfHeight = height / 2;
        return halfHeight > maxWidth ? maxWidth : halfHeight;
      },
      height(height) {
        return height;
      },
      connectionOffsetY(connectionHeight) {
        return connectionHeight / 2;
      },
      connectionOffsetX(connectionWidth) {
        return -connectionWidth;
      },
      pathDown(height) {
        return makeMainPath(height, false, false);
      },
      pathUp(height) {
        return makeMainPath(height, true, false);
      },
      pathRightDown(height) {
        return makeMainPath(height, false, true);
      },
      pathRightUp(height) {
        return makeMainPath(height, false, true);
      }
    };
  }
  shapeFor(connection) {
    let checks = connection.getCheck();
    if (!checks && connection.targetConnection) {
      checks = connection.targetConnection.getCheck();
    }
    if (connection.type == Blockly.ConnectionType.INPUT_VALUE || connection.type == Blockly.ConnectionType.OUTPUT_VALUE) {
      if (checks && checks.length > 1) {
        return this.ROUNDED;
      } else if (checks && checks.includes("Vector")) {
        return this.LEAF;
      } else if (checks && checks.includes("List")) {
        return this.PLUS;
      } else if (checks && checks.includes("String")) {
        return this.SQUARED;
      }
    }
    return super.shapeFor(connection);
  }
}
class PathObject extends Blockly.zelos.PathObject {
  updateShadow_() {
  }
}
class Renderer extends Blockly.zelos.Renderer {
  constructor(name) {
    super(name);
  }
  makeConstants_() {
    return new CustomConstantProvider();
  }
  makePathObject(root, style) {
    return new PathObject(root, style, this.getConstants());
  }
}
const Renderer$1 = (Blockly2) => {
  Blockly2.blockRendering.unregister("custom_renderer");
  Blockly2.blockRendering.register("custom_renderer", Renderer);
};
function DuplicateDrag(Blockly2) {
  Blockly2.Connection.REASON_DRAG_DUPLICATE = 9;
  const doSafetyChecks = Blockly2.ConnectionChecker.prototype.doSafetyChecks;
  Blockly2.ConnectionChecker.prototype.doSafetyChecks = function(a, b) {
    let actual = doSafetyChecks.call(this, a, b);
    if (actual !== Blockly2.Connection.CAN_CONNECT) return actual;
    if (a.targetConnection && a.targetConnection.sourceBlock_ && a.targetConnection.sourceBlock_.canDragDuplicate() || b.targetConnection && b.targetConnection.sourceBlock_ && b.targetConnection.sourceBlock_.canDragDuplicate()) {
      return Blockly2.Connection.REASON_DRAG_DUPLICATE;
    }
    return actual;
  };
  for (let Block of [Blockly2.Block, Blockly2.BlockSvg]) {
    Block.prototype.canDragDuplicate_ = false;
    Block.prototype.canDragDuplicate = function() {
      return this.canDragDuplicate_ && this.isShadow();
    };
    Block.prototype.setDragDuplicate = function(value) {
      this.canDragDuplicate_ = value;
    };
    const jsonInit = Block.prototype.jsonInit;
    Block.prototype.jsonInit = function(json) {
      jsonInit.call(this, json);
      if (json["canDragDuplicate"] !== void 0) {
        this.setDragDuplicate(json["canDragDuplicate"]);
      }
    };
  }
  Blockly2.Gesture.prototype.shouldDuplicateOnDrag_ = false;
  const setStartBlock = Blockly2.Gesture.prototype.setStartBlock;
  Blockly2.Gesture.prototype.setStartBlock = function(block) {
    if (!this.startBlock_ && !this.startBubble_) {
      this.shouldDuplicateOnDrag_ = block.canDragDuplicate();
    }
    return setStartBlock.call(this, block);
  };
  const updateIsDraggingBlock_ = Blockly2.Gesture.prototype.updateIsDraggingBlock_;
  Blockly2.Gesture.prototype.updateIsDraggingBlock_ = function() {
    if (this.targetBlock_ && !this.flyout_ && this.shouldDuplicateOnDrag_) {
      this.startDraggingBlock_();
      return true;
    }
    return updateIsDraggingBlock_.call(this);
  };
  const startDraggingBlock_ = Blockly2.Gesture.prototype.startDraggingBlock_;
  Blockly2.Gesture.prototype.startDraggingBlock_ = function() {
    if (this.shouldDuplicateOnDrag_ && !this.flyout_) {
      this.duplicateOnDrag_();
    }
    return startDraggingBlock_.call(this);
  };
  Blockly2.Gesture.prototype.duplicateOnDrag_ = function() {
    var newBlock = null;
    Blockly2.Events.disable();
    try {
      this.startWorkspace_.setResizesEnabled(false);
      var xmlBlock = Blockly2.Xml.blockToDom(this.targetBlock_);
      newBlock = Blockly2.Xml.domToBlock(xmlBlock, this.startWorkspace_);
      var xy = this.targetBlock_.getRelativeToSurfaceXY();
      newBlock.moveBy(xy.x, xy.y);
      newBlock.setShadow(false);
      newBlock.initSvg();
      newBlock.render();
    } finally {
      Blockly2.Events.enable();
    }
    if (!newBlock) {
      console.error("Something went wrong while duplicating a block.");
      return;
    }
    if (Blockly2.Events.isEnabled()) {
      Blockly2.Events.fire(new Blockly2.Events.BlockCreate(newBlock));
    }
    newBlock.select();
    this.targetBlock_ = newBlock;
  };
  Blockly2.Gesture.prototype.setTargetBlock_ = function(block) {
    if (block.isShadow() && !this.shouldDuplicateOnDrag_) {
      this.setTargetBlock_(block.getParent());
    } else {
      this.targetBlock_ = block;
    }
  };
}
const Patches = {
  Blockly: {
    ToolboxFlyout,
    Renderer: Renderer$1,
    DuplicateDrag
  }
};
const createExtendableElement$1 = (type) => {
  const element = document.createElement(type);
  const _setAttribute = element.setAttribute;
  const _setAttributeNS = element.setAttributeNS;
  element.setAttribute = (...args) => {
    _setAttribute.call(element, ...args);
    return element;
  };
  element.setAttributeNS = (...args) => {
    _setAttributeNS.call(element, ...args);
    return element;
  };
  element.setInnerHTML = (html) => {
    element.innerHTML = html;
    return element;
  };
  element.setInnerText = (text) => {
    element.innerText = text;
    return element;
  };
  return element;
};
const variables = (workspace) => {
  workspace.registerToolboxCategoryCallback("variables", () => {
    const blockList = [];
    blockList.push(createExtendableElement$1("button").setAttribute("text", "Register variable").setAttribute("callbackkey", "variables_register"));
    if (window.variables && Object.keys(window.variables).length > 0) {
      blockList.push(createExtendableElement$1("button").setAttribute("text", "Remove variable").setAttribute("callbackkey", "variables_remove"));
      blockList.push(createExtendableElement$1("block").setAttribute("type", "variables_get"));
      blockList.push(createExtendableElement$1("block").setAttribute("type", "variables_set"));
    }
    return blockList;
  });
};
const createExtendableElement = (type) => {
  const element = document.createElement(type);
  const _setAttribute = element.setAttribute;
  const _setAttributeNS = element.setAttributeNS;
  element.setAttribute = (...args) => {
    _setAttribute.call(element, ...args);
    return element;
  };
  element.setAttributeNS = (...args) => {
    _setAttributeNS.call(element, ...args);
    return element;
  };
  element.setInnerHTML = (html) => {
    element.innerHTML = html;
    return element;
  };
  element.setInnerText = (text) => {
    element.innerText = text;
    return element;
  };
  return element;
};
const blocks = (workspace) => {
  workspace.registerToolboxCategoryCallback("blocks", () => {
    let blockList = [];
    if (window.blocks && Object.keys(window.blocks).length >= 1) {
      for (let blockId of Object.keys(window.blocks)) {
        let node = document.createElement("block");
        node.setAttribute("type", "blocks_execute");
        let mutation = document.createElement("mutation");
        mutation.setAttribute("blockId", blockId);
        node.appendChild(mutation);
        blockList.push(node);
      }
      blockList.push(createExtendableElement("sep").setAttribute("gap", "48"));
      blockList.push(createExtendableElement("block").setAttribute("type", "blocks_return"));
    }
    return blockList;
  });
};
const registerCategories = (workspace) => {
  variables(workspace);
  blocks(workspace);
};
const Toolbox = '<xml>\r\n    <!--\r\n    <category name="Generic" colour="#fff">\r\n        <block type="generic_number" />\r\n        <block type="generic_text" />\r\n        <block type="generic_boolean" />\r\n    </category>\r\n    -->\r\n    <category name="Motion" colour="#4c97ff">\r\n        <block type="motion_move" />\r\n        <block type="motion_turnright" />\r\n        <block type="motion_turnleft" />\r\n        <sep gap="48"></sep>\r\n        <block type="motion_goto" />\r\n        <block type="motion_gototarget" />\r\n        <block type="motion_glide" />\r\n        <block type="motion_glidetarget" />\r\n        <sep gap="48"></sep>\r\n        <block type="motion_pointdirection" />\r\n        <block type="motion_pointtowards" />\r\n        <sep gap="48"></sep>\r\n        <block type="motion_changex" />\r\n        <block type="motion_setx" />\r\n        <block type="motion_changey" />\r\n        <block type="motion_sety" />\r\n        <sep gap="48"></sep>\r\n        <block type="motion_bounce" />\r\n        <block type="motion_rotationstyle" />\r\n        <sep gap="48"></sep>\r\n        <block type="motion_xposition" />\r\n        <block type="motion_yposition" />\r\n        <block type="motion_direction" />\r\n    </category>\r\n    <category name="Looks" colour="#9966ff">\r\n        <block type="looks_say" />\r\n        <block type="looks_sayfor" />\r\n        <block type="looks_think" />\r\n        <block type="looks_thinkfor" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_switchcostume" />\r\n        <block type="looks_nextcostume" />\r\n        <block type="looks_switchbackdrop" />\r\n        <block type="looks_nextbackdrop" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_changesize" />\r\n        <block type="looks_setsize" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_changeeffect" />\r\n        <block type="looks_seteffect" />\r\n        <block type="looks_cleareffects" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_show" />\r\n        <block type="looks_hide" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_gotolayer" />\r\n        <block type="looks_golayers" />\r\n        <sep gap="48"></sep>\r\n        <block type="looks_size" />\r\n        <block type="looks_costumenumber" />\r\n        <block type="looks_costumename" />\r\n        <block type="looks_backdropnumber" />\r\n        <block type="looks_backdropname" />\r\n    </category>\r\n    <category name="Events" colour="#fc6">\r\n        <block type="events_loaded" />\r\n        <sep gap="48"></sep>\r\n        <block type="events_thread" />\r\n        <sep gap="48"></sep>\r\n        <block type="events_whenflagclicked" />\r\n        <block type="events_whenkeypressed" />\r\n        <block type="events_whenspriteclicked" />\r\n        <block type="events_whenbackdropswitches" />\r\n        <block type="events_whengreaterthan" />\r\n        <block type="events_whenclonestarts" />\r\n        <sep gap="48"></sep>\r\n        <block type="events_regbroadcast" />\r\n        <block type="events_broadcast" />\r\n        <block type="events_broadcastw" />\r\n    </category>\r\n    <category name="Control" colour="#fb6">\r\n        <block type="control_wait" />\r\n        <block type="control_waitF" />\r\n        <block type="control_waitU" />\r\n        <sep gap="48"></sep>\r\n        <block type="control_if" />\r\n        <block type="control_if">\r\n            <mutation else="1" />\r\n        </block>\r\n        <sep gap="48"></sep>\r\n        <block type="control_repeat" />\r\n        <block type="control_while" />\r\n        <sep gap="48"></sep>\r\n        <block type="control_return" />\r\n        <block type="control_inline">\r\n            <statement name="BLOCKS">\r\n                <block type="control_return" />\r\n            </statement>\r\n        </block>\r\n    </category>\r\n    <category name="Math" colour="#6d6">\r\n        <block type="math_number" />\r\n        <block type="math_boolean" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_add" />\r\n        <block type="math_sub" />\r\n        <block type="math_mul" />\r\n        <block type="math_div" />\r\n        <block type="math_pow" />\r\n        <block type="math_mod" />\r\n        <block type="math_log" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_random" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_const" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_true" />\r\n        <block type="math_false" />\r\n        <block type="math_randombool" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_and" />\r\n        <block type="math_xor" />\r\n        <block type="math_or" />\r\n        <block type="math_not" />\r\n        <sep gap="48"></sep>\r\n        <block type="math_equals" />\r\n        <block type="math_gt" />\r\n        <block type="math_gte" />\r\n        <block type="math_lt" />\r\n        <block type="math_lte" />\r\n    </category>\r\n    <category name="Strings" colour="#6db">\r\n        <block type="strings_string" />\r\n        <sep gap="48"></sep>\r\n        <block type="strings_join">\r\n            <mutation items="2" />\r\n        </block>\r\n        <block type="strings_repeat" />\r\n        <block type="strings_substring" />\r\n        <block type="strings_split" />\r\n        <block type="strings_length" />\r\n        <block type="strings_contains" />\r\n        <block type="strings_amountof" />\r\n        <block type="strings_replace" />\r\n        <sep gap="48"></sep>\r\n        <block type="strings_log" />\r\n    </category>\r\n    <category name="Vectors" colour="#6cd">\r\n        <block type="vector_create" />\r\n        <sep gap="48"></sep>\r\n        <block type="vector_x" />\r\n        <block type="vector_y" />\r\n    </category>\r\n    <category name="Sensors" colour="#69d">\r\n        <block type="inputs_touching" />\r\n        <block type="inputs_touchingsprite" />\r\n        <block type="inputs_touchingcolor" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_distancemouse" />\r\n        <block type="inputs_distancesprite" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_ask" />\r\n        <block type="inputs_answer" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_keypress" />\r\n        <block type="inputs_keyspressed" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_mousex" />\r\n        <block type="inputs_mousey" />\r\n        <block type="inputs_moused" />\r\n        <block type="inputs_setdrag" />\r\n        <block type="inputs_draggable" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_timer" />\r\n        <block type="inputs_resettimer" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_current" />\r\n        <block type="inputs_dayssince2000" />\r\n        <sep gap="48"></sep>\r\n        <block type="inputs_username" />\r\n        <block type="inputs_loudness" />\r\n    </category>\r\n    <category name="Variables" colour="#f96" custom="variables">\r\n        <!-- resources/categories/variables.js -->\r\n    </category>\r\n    <category name="Lists" colour="#f76">\r\n        <block type="lists_create">\r\n            <mutation items="3" />\r\n        </block>\r\n        <block type="lists_create">\r\n            <mutation items="0" />\r\n        </block>\r\n        <sep gap="48"></sep>\r\n        <block type="lists_get" />\r\n        <block type="lists_index" />\r\n        <block type="lists_length" />\r\n        <block type="lists_contains" />\r\n        <sep gap="48"></sep>\r\n        <block type="lists_set" />\r\n        <block type="lists_join" />\r\n        <block type="lists_concat" />\r\n        <sep gap="48"></sep>\r\n        <block type="lists_foreach">\r\n            <value name="INDEX">\r\n                <shadow type="lists_foreachindex" />\r\n            </value>\r\n            <value name="VALUE">\r\n                <shadow type="lists_foreachvalue" />\r\n            </value>\r\n        </block>\r\n    </category>\r\n    <category name="Lambdas" colour="#d46">\r\n\r\n    </category>\r\n    <category name="Blocks" colour="#b6f" custom="blocks">\r\n        <!-- resources/categories/blocks.js -->\r\n    </category>\r\n\r\n    <sep />\r\n\r\n    <!--\r\n    <category name="Sprites" colour="#3cc">\r\n    \r\n    </category>\r\n    <category name="Motion" colour="#39c">\r\n    \r\n    </category>\r\n    <category name="Looks" colour="#94c">\r\n    \r\n    </category>\r\n    <category name="Sound" colour="#c4c">\r\n    \r\n    </category>\r\n    <category name="Clones" colour="#c94">\r\n    \r\n    </category>\r\n    -->\r\n    <category name="Runtime" colour="#aaa">\r\n        <block type="runtime_onstart" />\r\n        <block type="runtime_beforetick" />\r\n        <block type="runtime_aftertick" />\r\n        <block type="runtime_onstop" />\r\n        <sep gap="48"></sep>\r\n        <block type="runtime_start" />\r\n        <block type="runtime_stop" />\r\n        <block type="runtime_running" />\r\n        <block type="runtime_timer" />\r\n        <sep gap="48"></sep>\r\n        <block type="runtime_turboset" />\r\n        <block type="runtime_turboget" />\r\n        <sep gap="48"></sep>\r\n        <block type="runtime_frameset" />\r\n        <block type="runtime_frameget" />\r\n        <sep gap="48"></sep>\r\n        <block type="runtime_broadcast" />\r\n    </category>\r\n    <category name="Targets" colour="#46d">\r\n\r\n    </category>\r\n    <category name="Browser" colour="#9d5">\r\n        <block type="script_evalb" />\r\n        <block type="script_evalv" />\r\n        <sep gap="48"></sep>\r\n        <block type="script_fetch" />\r\n        <block type="script_fetchjson" />\r\n        <block type="script_fetchadvanced" />\r\n        <sep gap="48"></sep>\r\n        <block type="script_jsonparse" />\r\n        <block type="script_jsonstringify" />\r\n        <sep gap="48"></sep>\r\n        <block type="script_consolelog" />\r\n        <block type="script_consoleerror" />\r\n        <sep gap="48"></sep>\r\n        <block type="script_trycatch" />\r\n        <block type="script_lasterror" />\r\n        <sep gap="48"></sep>\r\n        <block type="script_typeof" />\r\n        <block type="script_globalget" />\r\n        <block type="script_globalset" />\r\n    </category>\r\n    <sep />\r\n    <category name="Music" colour="#ae29d6">\r\n        <block type="music_playnote" />\r\n        <block type="music_playnotenowait" />\r\n        <block type="music_stopnote" />\r\n        <block type="music_stopallnotes" />\r\n        <block type="music_setinstrument" />\r\n        <block type="music_resttime" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_settempo" />\r\n        <block type="music_changetempo" />\r\n        <block type="music_gettempo" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_setvolume" />\r\n        <block type="music_getvolume" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_playsound" />\r\n        <block type="music_startsound" />\r\n        <block type="music_stopallsounds" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_midienable" />\r\n        <block type="music_midioutputs" />\r\n        <block type="music_midiinputs" />\r\n        <block type="music_midisetoutput" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_midisendnoteon" />\r\n        <block type="music_midisendnoteoff" />\r\n        <block type="music_midisendraw" />\r\n        <sep gap="48"></sep>\r\n        <block type="music_whenmidimessage" />\r\n        <block type="music_midimessagenote" />\r\n        <block type="music_midimessagevelocity" />\r\n    </category>\r\n</xml>';
const css$e = {
  code: '.root.svelte-1f9jjoc{width:100%;height:100%}.dark .blocklyToolboxDiv{background:#333}.blocklyToolboxCategory{width:128px;position:relative;padding:0}.blocklyTreeSelected{background-color:initial !important}.blocklyTreeLabel{font-family:"Noto Sans";font-weight:500;font-size:14px;margin-left:16px;transition:0.3s cubic-bezier(0, 0, 0.3, 1);z-index:2;color:#000}.dark .blocklyTreeLabel{color:#fff}.blocklyTreeSelected .blocklyTreeLabel{margin-left:4px;font-weight:700;color:#000b}.categoryBubble{position:absolute;top:6px;left:4px;width:12px;height:12px;border-radius:4px;box-sizing:border-box;border:1px solid #0008;transition:0.3s cubic-bezier(0, 0, 0.3, 1);z-index:1}.blocklyTreeSelected .categoryBubble{top:0;left:0;width:128px;height:24px;border-radius:0;border-color:#0004;border-left:none}.blocklyFlyoutButtonBackground{fill:#0000 !important;stroke:#575e75;stroke-width:2px}.blocklyFlyoutButton:hover .blocklyFlyoutButtonBackground{fill:#0001 !important}.blocklyFlyoutButton:active .blocklyFlyoutButtonBackground{fill:#0002 !important}.blocklyFlyoutButton .blocklyText{fill:#575e75 !important}.dark .blocklyFlyoutButtonBackground{stroke:#b3bcdb}.dark .blocklyFlyoutButton:hover .blocklyFlyoutButtonBackground{fill:#fff1 !important}.dark .blocklyFlyoutButton:active .blocklyFlyoutButtonBackground{fill:#fff2 !important}.dark .blocklyFlyoutButton .blocklyText{fill:#b3bcdb !important}.blocklyTreeSeparator{border:none;width:calc(100% - 16px);height:6px;margin:8px;box-sizing:border-box;background:#8888;border-radius:6px}.blocklyMainBackground{stroke:none}.dark .blocklySvg,.dark .blocklyMutatorBackground{background:#111;fill:#111}.dark .blocklyFlyoutBackground{fill:#222}.dark .blocklyFlyoutLabelText{fill:#ccc !important}.dark .blocklyScrollbarHandle{fill:#777;opacity:0.4}.blocklyText{fill:#000b !important}.blocklyDropdownText,.blocklyEditableText > image{filter:invert(1);opacity:0.9;font-weight:400 !important}.blocklyMenuItemContent{color:#000b !important;font-weight:bold}',
  map: `{"version":3,"file":"Component.svelte","sources":["Component.svelte"],"sourcesContent":["<!-- Modified version of svelte-blockly -->\\r\\n<!-- https://www.npmjs.com/package/svelte-blockly -->\\r\\n\\r\\n<script context=\\"module\\"><\/script>\\r\\n\\r\\n<script>\\r\\n    import { createEventDispatcher } from \\"svelte\\";\\r\\n    import Blockly from \\"blockly/core.js\\";\\r\\n    import registerDynamicCategories from \\"../../resources/categories\\";\\r\\n    export let config = {};\\r\\n    export let locale;\\r\\n    export let workspace = undefined;\\r\\n    export let transform = undefined;\\r\\n    $: {\\r\\n        // evaluate transform to establish a reactive dependency\\r\\n        transform;\\r\\n        applyTransform();\\r\\n    }\\r\\n    const dispatch = createEventDispatcher();\\r\\n    let width, height;\\r\\n    function initRoot(root, param) {\\r\\n        function injectWorkspace(dom, { config, locale: { msg, rtl } }) {\\r\\n            Blockly.setLocale(msg);\\r\\n            workspace = Blockly.inject(root, {\\r\\n                ...config,\\r\\n                toolbox:\\r\\n                    config.toolbox ? '<xml><category name=\\"Loading...\\" colour=\\"100\\"></category></xml>' : null,\\r\\n                rtl,\\r\\n            });\\r\\n            registerDynamicCategories(workspace);\\r\\n            if (config.toolbox) workspace.updateToolbox(config.toolbox);\\r\\n            workspace.refreshToolboxSelection();\\r\\n            if (dom !== null) {\\r\\n                try {\\r\\n                    // don't record this reloading of the workspace for undo\\r\\n                    Blockly.Events.recordUndo = false;\\r\\n                    Blockly.Xml.clearWorkspaceAndLoadFromXml(dom, workspace);\\r\\n                    Blockly.Events.recordUndo = true;\\r\\n                } catch (ex) {\\r\\n                    console.warn(ex);\\r\\n                }\\r\\n            }\\r\\n            workspace.addChangeListener(() => {\\r\\n                dispatch(\\"change\\");\\r\\n            });\\r\\n            // TODO this is a terrible hack, but there's no scroll event\\r\\n            // translate is the most fundamental in a set of methods\\r\\n            // that move and zoom the workspace\\r\\n            // using an arrow function, so \`this\` is the component not the workspace\\r\\n            const translate = workspace.translate.bind(workspace);\\r\\n            workspace.translate = (x, y) => {\\r\\n                translate(x, y);\\r\\n                const { scrollX, scrollY, scale } = workspace;\\r\\n                transform = { scrollX, scrollY, scale };\\r\\n            };\\r\\n            if (transform !== undefined) {\\r\\n                applyTransform();\\r\\n            } else {\\r\\n                const { scrollX, scrollY, scale } = workspace;\\r\\n                transform = { scrollX, scrollY, scale };\\r\\n            }\\r\\n        }\\r\\n        injectWorkspace(null, param);\\r\\n        return {\\r\\n            update(param) {\\r\\n                const dom = Blockly.Xml.workspaceToDom(workspace);\\r\\n                workspace.dispose();\\r\\n                injectWorkspace(dom, param);\\r\\n            },\\r\\n            destroy() {\\r\\n                workspace.dispose();\\r\\n                workspace = undefined;\\r\\n            },\\r\\n        };\\r\\n    }\\r\\n    function applyTransform() {\\r\\n        if (workspace === undefined) return;\\r\\n        const { scrollX, scrollY, scale } = transform;\\r\\n        if (\\r\\n            scrollX !== workspace.scrollX ||\\r\\n            scrollY !== workspace.scrollY ||\\r\\n            scale !== workspace.scale\\r\\n        ) {\\r\\n            workspace.setScale(scale);\\r\\n            workspace.scroll(scrollX, scrollY);\\r\\n        }\\r\\n    }\\r\\n    $: {\\r\\n        // evaluate width & height to establish a reactive dependency\\r\\n        width;\\r\\n        height;\\r\\n        if (workspace) {\\r\\n            Blockly.svgResize(workspace);\\r\\n        }\\r\\n    }\\r\\n    // TODO this breaks smooth scrolling; for now, transform is read-only\\r\\n    // $: {\\r\\n    // \\tif (workspace && transform) {\\r\\n    // \\t\\tconst { scrollX, scrollY, scale } = transform;\\r\\n    // \\t\\tworkspace.scroll(scrollX, scrollY);\\r\\n    // \\t\\tworkspace.setScale(scale);\\r\\n    // \\t}\\r\\n    // }\\r\\n<\/script>\\r\\n\\r\\n<div\\r\\n    class=\\"root\\"\\r\\n    bind:offsetWidth={width}\\r\\n    bind:offsetHeight={height}\\r\\n    use:initRoot={{ config, locale }}\\r\\n/>\\r\\n\\r\\n<style>\\r\\n    .root {\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklyToolboxDiv) {\\r\\n        background: #333;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyToolboxCategory) {\\r\\n        width: 128px;\\r\\n        position: relative;\\r\\n        padding: 0;\\r\\n    }\\r\\n    :global(.blocklyTreeSelected) {\\r\\n        background-color: initial !important;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyTreeLabel) {\\r\\n        font-family: \\"Noto Sans\\";\\r\\n        font-weight: 500;\\r\\n        font-size: 14px;\\r\\n        margin-left: 16px;\\r\\n        transition: 0.3s cubic-bezier(0, 0, 0.3, 1);\\r\\n        z-index: 2;\\r\\n        color: #000;\\r\\n    }\\r\\n    :global(.dark .blocklyTreeLabel) {\\r\\n        color: #fff;\\r\\n    }\\r\\n    :global(.blocklyTreeSelected .blocklyTreeLabel) {\\r\\n        margin-left: 4px;\\r\\n        font-weight: 700;\\r\\n        color: #000b;\\r\\n    }\\r\\n\\r\\n    :global(.categoryBubble) {\\r\\n        position: absolute;\\r\\n        top: 6px;\\r\\n        left: 4px;\\r\\n        width: 12px;\\r\\n        height: 12px;\\r\\n        border-radius: 4px;\\r\\n        box-sizing: border-box;\\r\\n        border: 1px solid #0008;\\r\\n        transition: 0.3s cubic-bezier(0, 0, 0.3, 1);\\r\\n        z-index: 1;\\r\\n    }\\r\\n    :global(.blocklyTreeSelected .categoryBubble) {\\r\\n        top: 0;\\r\\n        left: 0;\\r\\n        width: 128px;\\r\\n        height: 24px;\\r\\n        border-radius: 0;\\r\\n        border-color: #0004;\\r\\n        border-left: none;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyFlyoutButtonBackground) {\\r\\n        fill: #0000 !important;\\r\\n        stroke: #575e75;\\r\\n        stroke-width: 2px;\\r\\n    }\\r\\n    :global(.blocklyFlyoutButton:hover .blocklyFlyoutButtonBackground) {\\r\\n        fill: #0001 !important;\\r\\n    }\\r\\n    :global(.blocklyFlyoutButton:active .blocklyFlyoutButtonBackground) {\\r\\n        fill: #0002 !important;\\r\\n    }\\r\\n    :global(.blocklyFlyoutButton .blocklyText) {\\r\\n        fill: #575e75 !important;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklyFlyoutButtonBackground) {\\r\\n        stroke: #b3bcdb;\\r\\n    }\\r\\n    :global(.dark .blocklyFlyoutButton:hover .blocklyFlyoutButtonBackground) {\\r\\n        fill: #fff1 !important;\\r\\n    }\\r\\n    :global(.dark .blocklyFlyoutButton:active .blocklyFlyoutButtonBackground) {\\r\\n        fill: #fff2 !important;\\r\\n    }\\r\\n    :global(.dark .blocklyFlyoutButton .blocklyText) {\\r\\n        fill: #b3bcdb !important;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyTreeSeparator) {\\r\\n        border: none;\\r\\n        width: calc(100% - 16px);\\r\\n        height: 6px;\\r\\n        margin: 8px;\\r\\n        box-sizing: border-box;\\r\\n        background: #8888;\\r\\n        border-radius: 6px;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyMainBackground) {\\r\\n        stroke: none;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklySvg), :global(.dark .blocklyMutatorBackground) {\\r\\n        background: #111;\\r\\n        fill: #111;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklyFlyoutBackground) {\\r\\n        fill: #222;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklyFlyoutLabelText) {\\r\\n        fill: #ccc !important;\\r\\n    }\\r\\n\\r\\n    :global(.dark .blocklyScrollbarHandle) {\\r\\n        fill: #777;\\r\\n        opacity: 0.4;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyText) {\\r\\n        fill: #000b !important;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyDropdownText), :global(.blocklyEditableText > image) {\\r\\n        filter: invert(1);\\r\\n        opacity: 0.9;\\r\\n        font-weight: 400 !important;\\r\\n    }\\r\\n\\r\\n    :global(.blocklyMenuItemContent) {\\r\\n        color: #000b !important;\\r\\n        font-weight: bold;\\r\\n    }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAiHI,oBAAM,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IACZ,CAEQ,wBAA0B,CAC9B,UAAU,CAAE,IAChB,CAEQ,uBAAyB,CAC7B,KAAK,CAAE,KAAK,CACZ,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,CACb,CACQ,oBAAsB,CAC1B,gBAAgB,CAAE,OAAO,CAAC,UAC9B,CAEQ,iBAAmB,CACvB,WAAW,CAAE,WAAW,CACxB,WAAW,CAAE,GAAG,CAChB,SAAS,CAAE,IAAI,CACf,WAAW,CAAE,IAAI,CACjB,UAAU,CAAE,IAAI,CAAC,aAAa,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,CAAC,CAC3C,OAAO,CAAE,CAAC,CACV,KAAK,CAAE,IACX,CACQ,uBAAyB,CAC7B,KAAK,CAAE,IACX,CACQ,sCAAwC,CAC5C,WAAW,CAAE,GAAG,CAChB,WAAW,CAAE,GAAG,CAChB,KAAK,CAAE,KACX,CAEQ,eAAiB,CACrB,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,IAAI,CAAE,GAAG,CACT,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,GAAG,CAClB,UAAU,CAAE,UAAU,CACtB,MAAM,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,CACvB,UAAU,CAAE,IAAI,CAAC,aAAa,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,CAAC,CAC3C,OAAO,CAAE,CACb,CACQ,oCAAsC,CAC1C,GAAG,CAAE,CAAC,CACN,IAAI,CAAE,CAAC,CACP,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,CAAC,CAChB,YAAY,CAAE,KAAK,CACnB,WAAW,CAAE,IACjB,CAEQ,8BAAgC,CACpC,IAAI,CAAE,KAAK,CAAC,UAAU,CACtB,MAAM,CAAE,OAAO,CACf,YAAY,CAAE,GAClB,CACQ,yDAA2D,CAC/D,IAAI,CAAE,KAAK,CAAC,UAChB,CACQ,0DAA4D,CAChE,IAAI,CAAE,KAAK,CAAC,UAChB,CACQ,iCAAmC,CACvC,IAAI,CAAE,OAAO,CAAC,UAClB,CAEQ,oCAAsC,CAC1C,MAAM,CAAE,OACZ,CACQ,+DAAiE,CACrE,IAAI,CAAE,KAAK,CAAC,UAChB,CACQ,gEAAkE,CACtE,IAAI,CAAE,KAAK,CAAC,UAChB,CACQ,uCAAyC,CAC7C,IAAI,CAAE,OAAO,CAAC,UAClB,CAEQ,qBAAuB,CAC3B,MAAM,CAAE,IAAI,CACZ,KAAK,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,IAAI,CAAC,CACxB,MAAM,CAAE,GAAG,CACX,MAAM,CAAE,GAAG,CACX,UAAU,CAAE,UAAU,CACtB,UAAU,CAAE,KAAK,CACjB,aAAa,CAAE,GACnB,CAEQ,sBAAwB,CAC5B,MAAM,CAAE,IACZ,CAEQ,iBAAkB,CAAU,+BAAiC,CACjE,UAAU,CAAE,IAAI,CAChB,IAAI,CAAE,IACV,CAEQ,8BAAgC,CACpC,IAAI,CAAE,IACV,CAEQ,6BAA+B,CACnC,IAAI,CAAE,IAAI,CAAC,UACf,CAEQ,6BAA+B,CACnC,IAAI,CAAE,IAAI,CACV,OAAO,CAAE,GACb,CAEQ,YAAc,CAClB,IAAI,CAAE,KAAK,CAAC,UAChB,CAEQ,oBAAqB,CAAU,4BAA8B,CACjE,MAAM,CAAE,OAAO,CAAC,CAAC,CACjB,OAAO,CAAE,GAAG,CACZ,WAAW,CAAE,GAAG,CAAC,UACrB,CAEQ,uBAAyB,CAC7B,KAAK,CAAE,KAAK,CAAC,UAAU,CACvB,WAAW,CAAE,IACjB"}`
};
const Component = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { config = {} } = $$props;
  let { locale } = $$props;
  let { workspace = void 0 } = $$props;
  let { transform = void 0 } = $$props;
  createEventDispatcher();
  function applyTransform() {
    if (workspace === void 0) return;
    const { scrollX, scrollY, scale } = transform;
    if (scrollX !== workspace.scrollX || scrollY !== workspace.scrollY || scale !== workspace.scale) {
      workspace.setScale(scale);
      workspace.scroll(scrollX, scrollY);
    }
  }
  if ($$props.config === void 0 && $$bindings.config && config !== void 0) $$bindings.config(config);
  if ($$props.locale === void 0 && $$bindings.locale && locale !== void 0) $$bindings.locale(locale);
  if ($$props.workspace === void 0 && $$bindings.workspace && workspace !== void 0) $$bindings.workspace(workspace);
  if ($$props.transform === void 0 && $$bindings.transform && transform !== void 0) $$bindings.transform(transform);
  $$result.css.add(css$e);
  {
    {
      applyTransform();
    }
  }
  {
    {
      if (workspace) {
        Blockly.svgResize(workspace);
      }
    }
  }
  return `    <div class="root svelte-1f9jjoc"></div>`;
});
const javascriptGenerator = gen.javascriptGenerator;
const oldBlockToCode = javascriptGenerator.blockToCode;
javascriptGenerator.blockToCode = function(block, opt_thisOnly = false, opt_forceTuple = false) {
  const out = oldBlockToCode.apply(this, [block, opt_thisOnly]);
  if (opt_forceTuple && !Array.isArray(out)) {
    return [out, 0];
  }
  return out;
};
javascriptGenerator.valueToCode = function(block, name, order = 0) {
  const code = (() => {
    if (isNaN(order)) {
      throw TypeError("Expecting valid order from block: " + block.type);
    }
    const targetBlock = block.getInputTargetBlock(name);
    if (!targetBlock && !block.getInput(name)) {
      throw ReferenceError(`Input "${name}" doesn't exist on "${block.type}"`);
    }
    if (!targetBlock) {
      return "";
    }
    const tuple = this.blockToCode(targetBlock, false, true);
    if (tuple === "") {
      return "";
    }
    if (!Array.isArray(tuple)) {
      throw TypeError(
        `Expecting tuple from value block: ${targetBlock.type} See developers.google.com/blockly/guides/create-custom-blocks/generating-code for more information`
      );
    }
    let code2 = tuple[0];
    const innerOrder = tuple[1];
    if (isNaN(innerOrder)) {
      throw TypeError(
        "Expecting valid order from value block: " + targetBlock.type
      );
    }
    if (!code2) {
      return "";
    }
    let parensNeeded = false;
    const outerOrderClass = Math.floor(order);
    const innerOrderClass = Math.floor(innerOrder);
    if (outerOrderClass <= innerOrderClass) {
      if (outerOrderClass === innerOrderClass && (outerOrderClass === 0 || outerOrderClass === 99)) ;
      else {
        parensNeeded = true;
        for (let i = 0; i < this.ORDER_OVERRIDES.length; i++) {
          if (this.ORDER_OVERRIDES[i][0] === order && this.ORDER_OVERRIDES[i][1] === innerOrder) {
            parensNeeded = false;
            break;
          }
        }
      }
    }
    if (parensNeeded) {
      code2 = "(" + code2 + ")";
    }
    return code2;
  })();
  const input = block.getInput(name);
  let parentType = input.connection.getCheck();
  let childType = input.connection.targetConnection && input.connection.targetConnection.getCheck();
  if (parentType && Array.isArray(parentType)) parentType = parentType[0];
  if (childType && Array.isArray(childType)) childType = childType[0];
  if (parentType !== childType) {
    switch (parentType) {
      case "String":
        return `String(${code})`;
      case "Number":
        return `Number(${code})`;
      case "Boolean":
        return `((value) => 
                    typeof value === 'string' && (value === 'true' || value === 'false') 
                        ? value === 'true' 
                        : Boolean(value))(${code})`;
      case "List":
        return `((value) => value && value.length ? value : [value])(${code})`;
      case "Vector":
        return `CapivaraModBuilder.Vector.from(${code})`;
    }
  }
  return code;
};
javascriptGenerator.workspaceToCode = function(workspace) {
  javascriptGenerator.init(workspace);
  const allBlocks = workspace.getTopBlocks(true).filter((v) => !v.previousConnection && !v.outputConnection);
  const orderedBlocks = allBlocks.sort((a, b) => b.order - a.order);
  let code = "";
  for (let block of orderedBlocks) {
    code += javascriptGenerator.blockToCode(block);
  }
  return code;
};
const util = {
  randomHex: (length) => {
    return [...Array(length)].map(() => Math.floor(Math.random() * 16).toString(16)).join("");
  },
  blockToName: (fields) => {
    return fields.map((field) => {
      switch (field.type) {
        case "label": {
          return field.text;
        }
        case "string": {
          return `[${field.text}]`;
        }
        case "number": {
          return `(${field.text})`;
        }
        case "boolean": {
          return `<${field.text}>`;
        }
      }
    }).join(" ");
  },
  blockToExtensionText: (fields) => {
    return fields.map((field) => {
      switch (field.type) {
        case "label": {
          return field.text;
        }
        case "string":
        case "number":
        case "boolean": {
          return `[${field.id}]`;
        }
      }
    }).join(" ");
  }
};
const start = `
if (!Scratch.extensions.unsandboxed) {
    alert("This extension needs to be unsandboxed to run!")
    return
}

const CapivaraModBuilder = {
    Broadcasts: new function() {
        this.raw_ = {};
        this.register = (name, blocks) => {
            this.raw_[name] = blocks;
        };
        this.execute = async (name) => {
            if (this.raw_[name]) {
                await this.raw_[name]();
            };
        };
    },

    Variables: new function() {
        this.raw_ = {};
        this.set = (name, value) => {
            this.raw_[name] = value;
        };
        this.get = (name) => {
            return this.raw_[name] ?? null;
        }
    },

    Vector: class {
        constructor(x, y) {
            this.x = x;
            this.y = y;
        }

        static from(v) {
            if (v instanceof CapivaraModBuilder.Vector) return v
            if (v instanceof Array) return new CapivaraModBuilder.Vector(Number(v[0]), Number(v[1]))
            if (v instanceof Object) return new CapivaraModBuilder.Vector(Number(v.x), Number(v.y))
            return new CapivaraModBuilder.Vector()
        }

        add(v) {
            return new Vector(this.x + v.x, this.y + v.y);
        }

        set(x, y) {
            return new Vector(x ?? this.x, y ?? this.y)
        }
    },

    Utils: {
        setList: (list, index, value) => {
            [...list][index] = value;
            return list;
        },
        lists_foreach: {
            index: [0],
            value: [null],
            depth: 0
        },
        countString: (x, y) => {
            return y.length == 0 ? 0 : x.split(y).length - 1
        }
    }
}
`;
class Compiler {
  /**
   * Generates JavaScript code from the provided workspace & info.
   * @param {import('blockly').Workspace} workspace 
   * @param {object} properties
   * @returns {string} Generated code.
   */
  compile(workspace, properties) {
    const code = javascriptGenerator.workspaceToCode(workspace);
    const headerCode = [
      `/*`,
      `   Created with CapivaraModBuilder`,
      `   https://capivaramod.github.io/capivaramodbuilder`,
      `*/`,
      `(async function (Scratch) {`,
      `const variables = {};`,
      ``,
      start
    ];
    const classRegistry = {
      top: [
        `class Extension {`
      ],
      extensionInfo: {},
      bottom: [
        `}`,
        ``,
        `let extension = new Extension();`,
        `// code compiled from extforge`
      ]
    };
    const footerCode = [
      `Scratch.extensions.register(extension);`,
      `})(Scratch);`
    ];
    classRegistry.extensionInfo.id = properties.id;
    classRegistry.extensionInfo.name = properties.name;
    classRegistry.extensionInfo.color1 = properties.color;
    classRegistry.extensionInfo.blocks = Object.entries(window.blocks ?? {}).map(([id2, block]) => {
      return {
        opcode: `block_${id2}`,
        text: util.blockToExtensionText(block.fields),
        blockType: block.type,
        arguments: Object.fromEntries(block.fields.filter((v) => v.type !== "label").map((v) => {
          switch (v.type) {
            case "string": {
              return [v.id, {
                type: "string",
                defaultValue: v.default
              }];
            }
            case "number": {
              return [v.id, {
                type: "number",
                defaultValue: Number(v.default) || 0
              }];
            }
            case "boolean": {
              return [v.id, {
                type: "Boolean"
              }];
            }
          }
        }))
      };
    });
    return [].concat(headerCode, classRegistry.top, [
      `getInfo() {`,
      `   return ${JSON.stringify(classRegistry.extensionInfo).substring(0, JSON.stringify(classRegistry.extensionInfo).length - 1)}}`,
      `}`
    ], Object.entries(window.blocks ?? {}).map(([id2, block]) => {
      let blockCode = javascriptGenerator.statementToCode(
        workspace.getTopBlocks().find((v) => v.type == "blocks_define" && v.blockId_ == id2),
        "BLOCKS"
      );
      return `async block_${id2}(args) { ${blockCode} }`;
    }), classRegistry.bottom, code, footerCode).join("\n");
  }
}
const Icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAADXUAAA11AFeZeUIAAANaElEQVR4Ac1bCWxc1RW99ixeZ8ZbbCeOHcdO4mwEh+IGB7KwNAEVWggVCaUQqrYgpKpUUKjUSpVAAaqkiIpS0aZQhYIoqkpLCCGFkISwJAGy2Tir4zXG+z7jmbFnPO65E//v//7/4/9nPA5c6ei/d99+57377rvvTcLY2Bh9AykVfaoErgayAI4PAn3ASeAzwA1MnVgA3yAsRl9eBgaAyWgIif8CVgJT6v+UCk+1cUX5JISfBnxANDSKzK8BOUBMY0nggl8zOdD+v4F1U+jHeZS9DeBvVPR1C8CK3u4Cblb2mn+U/qFWau6sop7BZvIHPJRqd1GOaw4VzlhGjtRcSkxIVBbhcB2wBviKI2ZpOgWQgE4UA4VACcCKTOp1CGEfUA78ApBp0NtJH9fsoFNNH9BwYEjmS4EkWyqV5K+gVUvvp9yMUkpI4GZkeg+h7wKjMscgEG8BWNDeLcDdwPVADsC/stBLxHXpYlc17Ty8hfo8xj9iki2Nbrn6Ubpi7nplXbyefwi8oWROFo6nAO5AQ08DZYCpASs75hsepB17H6LuwUYle9KwzZpM9934As3KXqTMdwyRFYCpWSBNSWUF0YadKPA68CawEIhq8Lze/SNu2v3F1qgGj3YoEPTT7s+3UnB0hKMSXYXAUili9OXpORUqQOE9wBXqSkJjo1jDXhoYaqfugUbyDQ8IWS7tPWPk9nXRmeYPTU17oYLxSHtfLTV3VUEvVEjJ/ANcD1RJjMm+UxHATFS8D+ApL1NgdJjOXfyITta/Q+2958mHX5cotq3WmZ5DN1f8nDJTS2jA30yHTr1Oze2n5bYuBcboYme1UgDMnqfKFDEaqwBYo/8HEAbfNdBA/zv6HDV28DKcOlUu+QGVzfxOuKJcVyllphXRi2/fp6m4x92s5mWqGZHisQpgGypkRRMmXsdnmvfTe8f+SB5/r8Se8jcnfYFQhz0xPbztqY03XmLMU2yJvBuZolgEwNvcA4Cs7Braj9LOI09BGQ2batRspsQEc+OAEWy2Sk2+aHcBnvrPAbLget0t9PaRLXEfPPc0FIp9YFzeDMkDMZMZeR4E5Hk5GgrSni+ehSbv1i1us9morGglzcxcSOlpLkpOzKEQBWg41E9er4d6PE1QlLXU3l1Po6PabTs0Jmxvum1MlRmNABxo7DFAnvqnm/ZRffvnun2YnbuQNlz3BLmSZ+umK5nDowOo5whVN7xLF1pO4Je/JAw2dKabohHAj9AZ3vrC5MW+vq/qRSkqfHOzi2jTmmcpxZYh8CNFkiwuWlSwPoyeoTr65PQrVFP3ISUnfXMEwIJ6SDmAmsb3ye3tUrLCYZvNTrdX/k4YPGvoLvd5aug8gvkTwr5eTHmZ88mRlI9TnfgbZKeV0vcrnqTVSxrJkZynqT/eDLH1yLVfgyTZvAwEh2Ho7NbNvWLRHZTnnLDNefCfXXiV9h9/SVjniYmJlJtVREvm3Ais0ywVFtLlILMCYOtDXvvNnSeos++Cpn9pKU66puxegV/XdZA+OLo9vE8rE0KhEJRfI/AyfVT9D1pcvJquXbyZeAZcTjKzDfJmfJPUKf5Fj9ftws6r3aKuWnAbpv6EEcYaf++xP2sGL9UlfQOBAFXV7qO/vftT+uTsdhoNxdeekNrR+5oRwAwULJYK+wNueGrYMSuS1Wqj8pJbBWZ9xyHq7msVeJNFAoEROnD8Fdpz4hkIjX0m009mBMAnPXn697lbw8dXddfmzionV0qhwK5q0NcTQiadyIlze6m240OdFO2s40xpyROzbryQfkadGs0IYJmyXGd/HfFRV01F8NUlTMiJAqEhqmuJ/VC078SLWAoThhAvvXPte3WXU7ajUHkO4K551P2LFDejBAWt1Ou+qFvXjIw5Av+r3moaHvELvGgivHReen8zlRVeC0einVp6qqmhNcIRX+sgNb3uzAhAOPJ2DzZpxsGnMLX2buk+pckXLaOzt5kYhoTZoSLuM89uQ0ViZgnIAuCpzx4cNdltyeRIY105Qe292m1yIjW+of6hNvXSuAstbDbTipEAbKhENn/ZB9fv0c4uR7qLbAlpQntdg5dPAHx/0DVQr2yflfYWQOyUMsd42EgAvP7lPGz/j0AIaspKKxZYo2N+8ngGBN50RkaCXtr12TPqe4RZaHOjUbvy4CJkzFby3bi00HN6ZDiFbOQN9BL7Bi8ntfacoWO1b6mb3KBmqONGAnApCwRHA8qoHHbY2Tk8QSMjIzjSGuqfiQImQlarlWbnlVFJQTnxOUKPzl48KB+lx9Mr9fIpeUa7gHAeZRtAj6wWIRuNwB3O+3a8iAe+cdVW3A/yRRNR+2ANvfbBI+TzDwlNsHN0JOijZHu6xGcLiU15reEynkNflFJx1ZcrN0MB6jeTzXSe8tJb5cFzoXznUirKWa4pH8Qpdcjfp+SzMpSloUyQwlEJQCpk9B2NsyvLatFOVIUHWO5OEJajx98jx8cDshmvTuD4tAhAcXTQazNqnt59oZ6OsVmSyJWqcaJM2NM6LU+LACwJbD7Ej9xD2ruGQPjJkNhGYqJVuf45kRWRV8wlxqZFAPaES8pKbCr2WCCo3X38QT07g2e7MOMjKj+pN9MiAJvFrj6dSe3F9NV5DULDw1qDTEcvGGrtqASgc+7WHZDVZo2rAJKSkoR2xrCr+XzasWWkzSSVK71TKKgTMRIAv82TKdtZJIeVgT5fozJKbLREMlaEjCYjzpR8Iacv2A1LUysAuzWFLNADCjJ8amIkAEGCrrQ8skLTqqmzr0FgJVkc6Ej8FGGmUz6Phdvx+oYED7PUeHqKaJKDb2iQGAmAD/WyBkpPziZHilbBdfc3w0sUlPpBVpwM1ecDOTHKAK/rPJd8GxcuzZcnepZmFjxDKtI3XRWZjATAWlR+kcC/Pq8zNXn9bnL72wX27BzBkyakRRNJTXGQ+rTZ0as/rhznHHXV+u4rRS4jAXDWGik//xr8NE1NbJR0e4TzOJXmX6POFlN8weyVuD0SlxM/iVET2wC5mfPU7Go1Qx03I4AvlYVyXMXKqBxW64GS/ErcCGfI6bEGrp5/u1DUO9JDX3WeF3gcSU1yYXYKypKPo1pJqUqaEcBJZZm88ONEbbEOPFZSki0xlSoXb1Syog4vm78W61++kQuXP9d2AKdNrQ0wJ3c52a2pyjbOIaI1IZU5ENaORJUBUZ4B8tk20zGbkm3aA9bZpkPhC1Bl8Yp5m6h4Fl8rRE95WcW0vvxxwdXObvKjZ9/Srax05gq17XEQGQ2dEmYEwFuhvB2m2B00wzVX0wm+MP30zA7hysySYKeN1/2BFpUY+iWE+koKrqR7bngeghb8MVTVvJPae8Qtlwvy9C+Z+W1lHfyDva1kRAqbEQDvb4ekChLgg+fzufISREo7Vf8xNXUflqLhr92aTneu2EqbbthChfkLIxpIFouFCuH42LD6t3T36ucpzS7u6ewE2Xdsu1C3FFlavE69PXcg7YCUPtnX7FNZdjO/AYRPGvw05vUDj+g+h0tNSae71jxFs7O+pRESX6j2e5uprfc03hb0Yy8PEb/5daZnUK6rjNLxXkAtWM5T3/Up7Tr8DLmHtAegFLuTfrzur6SyUp9FX3812cClNLMCsKMA33PJGqm+/Qv654FHda/JbFY7rbrybqqYdw/ZLYaeaakvwncMy7etr4YOnXmVzjYd1jV8uMDaZQ/g5fhmZVm2kVnx6BsLypwImxUAF7sV4HUVngUh/DLvwBVdVf8up+lShjOHKhbcSYuLbiBnMjtOw0V180rM4eAgnW87SCfr3qGmttPhWSKlqb8F2Yvp3hv/pD4A/QX5hNcs6nLKeDQCYOcir6tVUgXsf3tt/8MUyVkq5ePDUX52Cf7ssBRTHU9jMOVTLZeexwRDPnKPtFHvYCu1dNdQU3sVeX0eqWjEb46zmDat3UaZ6ez+l4mVdTnQJnMMAtEIgKuqAD4G5BPRwFAHvXHwMUMhcOF4EVujd63+vXrwvOXdD7waTTvRCoDr/g2wBZDnM//LY/fn2+hCK+8AvANND/EJc3npbVj3P6OUJKe6Ed4iHlQzjeKxCIC3zr8D9wGyEHhnqIY+2F+1nbzDgmvaqA+G6ZZEOxXlLqPrr3yQZmUtUhs8LPE9wAZg2LAyVYZYBMBV8K6wA9gEyEJAmDy+Hjpa+1/iZ3R94YvU2GdEMra4+QUraUXZRsrHszodlxdX/ibAP4bWQwKmEcUqAK6XXS9PAI+Ph/GZIL4dauw4TrVYFi3dXxK/Kda7V5woAUnCyGKrLj9zAS0sXEPzZlWSE/8Qi0Be8J8EtgG8/mOiqQhAanA9Ai8AmrOolGE0BCc2HlXyX+D4Gts/4glfn/HTetbi/Co8y1lIWekFMGjmwLXt0Pu15eoQeA/4NSAf1aXEaL/xEAC36QB+CTwMiDYsGHEiNsn3AluBg0DsawuFJYqXAKT6ePCbgZ8A/FxU0A+Ix0JdKMRmOGt5dtHFZeCoJ0zxFoBUL+uH5cD3gJvGw7LtgPhkxANsAfhX3gnsBmJScChnSNMlAHXDfH++BJgLlAJ8QGCwUNi7MQSw8+IscBpoBdgfOe30f8klyT1lJG8lAAAAAElFTkSuQmCC";
const css$d = {
  code: ".nav.svelte-zjuti2{position:fixed;left:0px;top:0px;width:100%;height:3rem;display:flex;flex-direction:row;align-items:center;z-index:100;background:linear-gradient(177.5deg, #9EC05B, #6B8E23)}.logo-margin.svelte-zjuti2{margin:0 6px;margin-left:10px}",
  map: '{"version":3,"file":"NavigationBar.svelte","sources":["NavigationBar.svelte"],"sourcesContent":["<script>\\r\\n    import Icon from \\"$lib/images/icon.png\\"\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"nav\\">\\r\\n    <img\\r\\n        src={Icon}\\r\\n        alt=\\"Logo\\"\\r\\n        class=\\"logo-margin\\"\\r\\n        style=\\"height: 40px;\\"\\r\\n    />\\r\\n    <slot />\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .nav {\\r\\n        position: fixed;\\r\\n        left: 0px;\\r\\n        top: 0px;\\r\\n        width: 100%;\\r\\n        height: 3rem;\\r\\n\\r\\n        display: flex;\\r\\n        flex-direction: row;\\r\\n        align-items: center;\\r\\n        z-index: 100;\\r\\n\\r\\n        background: linear-gradient(177.5deg, #9EC05B, #6B8E23);\\r\\n    }\\r\\n\\r\\n    .logo-margin {\\r\\n        margin: 0 6px;\\r\\n        margin-left: 10px;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAeI,kBAAK,CACD,QAAQ,CAAE,KAAK,CACf,IAAI,CAAE,GAAG,CACT,GAAG,CAAE,GAAG,CACR,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CAEZ,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,GAAG,CACnB,WAAW,CAAE,MAAM,CACnB,OAAO,CAAE,GAAG,CAEZ,UAAU,CAAE,gBAAgB,QAAQ,CAAC,CAAC,OAAO,CAAC,CAAC,OAAO,CAC1D,CAEA,0BAAa,CACT,MAAM,CAAE,CAAC,CAAC,GAAG,CACb,WAAW,CAAE,IACjB"}'
};
const NavigationBar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$d);
  return `<div class="nav svelte-zjuti2"><img${add_attribute("src", Icon, 0)} alt="Logo" class="logo-margin svelte-zjuti2" style="height: 40px;"> ${slots.default ? slots.default({}) : ``} </div>`;
});
const css$c = {
  code: "img.svelte-tl56j1{height:1.5rem;margin-right:0.5rem;opacity:0.8}b.svelte-tl56j1{opacity:0.8}b.svelte-tl56j1:empty{margin-left:-0.5rem}button.svelte-tl56j1{position:relative;height:100%;padding:0 0.75rem;display:flex;flex-direction:row;align-items:center;font-family:'Noto Sans', sans-serif;font-weight:bold;font-size:0.75rem;color:#000;background:transparent;cursor:pointer;border:0;transition:background 0.3s cubic-bezier(0, 0, 0.3, 1)}button.svelte-tl56j1:hover{background:#fff4\r\n    }",
  map: `{"version":3,"file":"Button.svelte","sources":["Button.svelte"],"sourcesContent":["<script>\\r\\n    import { createEventDispatcher } from \\"svelte\\";\\r\\n\\r\\n    import NavIconUnknown from \\"$lib/images/nav/unknown.svg\\";\\r\\n    /** @type {string?} */\\r\\n    export let icon = null\\r\\n\\r\\n    const dispatch = createEventDispatcher();\\r\\n\\r\\n    function event() {\\r\\n        dispatch(\\"click\\");\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<button on:click={event}>\\r\\n    {#if icon}\\r\\n        <img src={icon} alt=\\"Icon\\" />\\r\\n    {/if}\\r\\n    <b><slot /></b>\\r\\n</button>\\r\\n\\r\\n<style>\\r\\n    img {\\r\\n        height: 1.5rem;\\r\\n        margin-right: 0.5rem;\\r\\n        opacity: 0.8;\\r\\n    }\\r\\n\\r\\n    b {\\r\\n        opacity: 0.8;\\r\\n    }\\r\\n    b:empty {\\r\\n        margin-left: -0.5rem;\\r\\n    }\\r\\n\\r\\n    button {\\r\\n        position: relative;\\r\\n\\r\\n        height: 100%;\\r\\n        padding: 0 0.75rem;\\r\\n\\r\\n        display: flex;\\r\\n        flex-direction: row;\\r\\n        align-items: center;\\r\\n\\r\\n        font-family: 'Noto Sans', sans-serif;\\r\\n        font-weight: bold;\\r\\n        font-size: 0.75rem;\\r\\n        color: #000;\\r\\n        background: transparent;\\r\\n        cursor: pointer;\\r\\n        border: 0;\\r\\n        transition: background 0.3s cubic-bezier(0, 0, 0.3, 1);\\r\\n    }\\r\\n    button:hover {\\r\\n        background: #fff4\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAsBI,iBAAI,CACA,MAAM,CAAE,MAAM,CACd,YAAY,CAAE,MAAM,CACpB,OAAO,CAAE,GACb,CAEA,eAAE,CACE,OAAO,CAAE,GACb,CACA,eAAC,MAAO,CACJ,WAAW,CAAE,OACjB,CAEA,oBAAO,CACH,QAAQ,CAAE,QAAQ,CAElB,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,CAAC,CAAC,OAAO,CAElB,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,GAAG,CACnB,WAAW,CAAE,MAAM,CAEnB,WAAW,CAAE,WAAW,CAAC,CAAC,UAAU,CACpC,WAAW,CAAE,IAAI,CACjB,SAAS,CAAE,OAAO,CAClB,KAAK,CAAE,IAAI,CACX,UAAU,CAAE,WAAW,CACvB,MAAM,CAAE,OAAO,CACf,MAAM,CAAE,CAAC,CACT,UAAU,CAAE,UAAU,CAAC,IAAI,CAAC,aAAa,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,CACzD,CACA,oBAAM,MAAO,CACT,UAAU,CAAE,KAAK;AACzB,IAAI"}`
};
const Button = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { icon = null } = $$props;
  createEventDispatcher();
  if ($$props.icon === void 0 && $$bindings.icon && icon !== void 0) $$bindings.icon(icon);
  $$result.css.add(css$c);
  return `<button class="svelte-tl56j1">${icon ? `<img${add_attribute("src", icon, 0)} alt="Icon" class="svelte-tl56j1">` : ``} <b class="svelte-tl56j1">${slots.default ? slots.default({}) : ``}</b> </button>`;
});
const css$b = {
  code: ".divider.svelte-2hahoh{border-radius:6px;border:3px dashed rgba(0, 0, 0, 0.15);margin:0.85rem 0.5rem;height:calc(100% - 0.85rem)}",
  map: '{"version":3,"file":"Divider.svelte","sources":["Divider.svelte"],"sourcesContent":["<div class=\\"divider\\" />\\r\\n\\r\\n<style>\\r\\n    .divider {\\r\\n        border-radius: 6px;\\r\\n        border: 3px dashed rgba(0, 0, 0, 0.15);\\r\\n        margin: 0.85rem 0.5rem;\\r\\n        height: calc(100% - 0.85rem);\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAGI,sBAAS,CACL,aAAa,CAAE,GAAG,CAClB,MAAM,CAAE,GAAG,CAAC,MAAM,CAAC,KAAK,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,IAAI,CAAC,CACtC,MAAM,CAAE,OAAO,CAAC,MAAM,CACtB,MAAM,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,OAAO,CAC/B"}'
};
const Divider = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$b);
  return `<div class="divider svelte-2hahoh"></div>`;
});
const NavIconSave = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%208%208'%3e%3cpath%20d='M%201%200%20A%201%201%200%200%200%200%201%20L%200%207%20A%201%201%200%200%200%201%208%20L%207%208%20A%201%201%200%200%200%208%207%20L%208%202%20A%202%202%200%200%200%206%200%20L%201%200%20M%201.5%202.5%20A%200.5%200.5%200%200%201%201%202%20L%201%201%20A%200.5%200.5%200%200%201%201.5%200.5%20L%205.5%200.5%20A%200.5%200.5%200%200%201%206%201%20L%206%202%20A%200.5%200.5%200%200%201%205.5%202.5%20L%201.5%202.5%20M%202%207%20A%201%201%200%200%201%201%206%20L%201%204.5%20A%201%201%200%200%201%202%203.5%20L%206%203.5%20A%201%201%200%200%201%207%204.5%20L%207%206%20A%201%201%200%200%201%206%207%20L%202%207%20M%205%201%20A%200.5%200.5%200%200%200%205%202%20A%200.5%200.5%200%200%200%205%201'%20fill='%23000'/%3e%3c/svg%3e";
const NavIconLoad = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200.1%208%208'%3e%3cpath%20d='M%203%207%20A%201%201%20180%200%200%205%207%20L%205%203%20L%206%204%20A%200.5%200.5%20180%200%200%207.5%202.5%20L%206%201%20A%203%203%20180%200%200%202%201%20L%200.5%202.5%20A%201%201%20180%200%200%202%204%20L%203%203%20L%203%207'%20fill='%23000'/%3e%3c/svg%3e";
const NavIconExperiments = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='9.6427e-8%200.7%208%208'%3e%3cpath%20d='M%200.2%206.4%20A%201%201%200%200%200%201%208%20L%207%208%20A%201%201%200%200%200%207.8%206.4%20L%205.1%202.8%20L%205.1%201.4%20L%204.6%201.4%20L%204.6%203%20L%207.3%206.6%20L%200.7%206.6%20L%203.4%203%20L%203.4%201.4%20L%202.9%201.4%20L%202.9%202.8%20L%200.2%206.4%20M%206.2%204.6%20A%202%202%200%200%200%204%204.6%20A%202%202%200%200%201%201.8%204.6%20L%200.5%206.7%20L%207.5%206.7%20L%206.2%204.6'%20fill='%23000'/%3e%3c/svg%3e";
const NavIconDark = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%208%208'%3e%3cpath%20d='M%204%200%20A%201%201%200%200%200%204%208%20A%201%201%200%200%200%204%200%20M%204%207%20A%201%201%200%200%201%204%201%20Z'%20fill='%23000'/%3e%3c/svg%3e";
const css$a = {
  code: "div.svelte-agkcqx{display:flex;height:100%}.dark div.svelte-agkcqx{background:#111;color:#fff}",
  map: '{"version":3,"file":"TabManager.svelte","sources":["TabManager.svelte"],"sourcesContent":["<script>\\r\\n    let activeTab = 0;\\r\\n    let tabs = 0;\\r\\n\\r\\n    function handleTabClick(id) {\\r\\n        activeTab = id\\r\\n    }\\r\\n\\r\\n    function registerTab() {\\r\\n        tabs += 1\\r\\n        return tabs - 1\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<div><slot {activeTab} {tabs} {handleTabClick} {registerTab} /></div>\\r\\n\\r\\n<style>\\r\\n    div {\\r\\n        display: flex;\\r\\n        height: 100%;\\r\\n    }\\r\\n\\r\\n    :global(.dark) div {\\r\\n        background: #111;\\r\\n        color: #fff;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAiBI,iBAAI,CACA,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,IACZ,CAEQ,KAAM,CAAC,iBAAI,CACf,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACX"}'
};
const TabManager = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let activeTab = 0;
  let tabs = 0;
  function handleTabClick(id2) {
    activeTab = id2;
  }
  function registerTab() {
    tabs += 1;
    return tabs - 1;
  }
  $$result.css.add(css$a);
  return `<div class="svelte-agkcqx">${slots.default ? slots.default({
    activeTab,
    tabs,
    handleTabClick,
    registerTab
  }) : ``}</div>`;
});
const css$9 = {
  code: "div.svelte-1cswslp.svelte-1cswslp{position:relative;height:100%;flex:1}div.active.svelte-1cswslp.svelte-1cswslp{z-index:2}button.svelte-1cswslp.svelte-1cswslp{position:absolute;width:100%;height:2em;text-align:center;font-family:'Noto Sans', sans-serif;font-weight:bold;font-size:0.75rem;color:#000;background:#fff;cursor:pointer;border:0;border-bottom:4px solid #0002;box-sizing:border-box;transition:background 0.3s cubic-bezier(0, 0, 0.3, 1)}div.active.svelte-1cswslp button.svelte-1cswslp{background:#ddd}.dark button.svelte-1cswslp.svelte-1cswslp{background:#222;color:#fff}.dark div.active.svelte-1cswslp button.svelte-1cswslp{background:#444}.contents.svelte-1cswslp.svelte-1cswslp{width:100vw;height:calc(100% - 1.5em);position:absolute;display:block;bottom:0;overflow:auto}div.svelte-1cswslp:not(.active) .contents.svelte-1cswslp{display:none}",
  map: `{"version":3,"file":"Tab.svelte","sources":["Tab.svelte"],"sourcesContent":["<script>\\r\\n    export let title = 'Unknown';\\r\\n\\r\\n    export let activeTab = 0;\\r\\n    export let tabs;\\r\\n    export let handleTabClick; \\r\\n    export let registerTab;\\r\\n\\r\\n    let id = registerTab();\\r\\n\\r\\n    function handleClick() {\\r\\n        handleTabClick(id)\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<div class:active={id === activeTab}>\\r\\n    <button on:click={handleClick}>{title}</button>\\r\\n    <div class=\\"contents\\" style:left={\`calc(-\${id/tabs} * 100vw)\`}><slot /></div>\\r\\n</div>\\r\\n\\r\\n\\r\\n<style>\\r\\n    div {\\r\\n        position: relative;\\r\\n        height: 100%;\\r\\n        flex: 1;\\r\\n    }\\r\\n    div.active {\\r\\n        z-index: 2;\\r\\n    }\\r\\n\\r\\n    button {\\r\\n        position: absolute;\\r\\n\\r\\n        width: 100%;\\r\\n        height: 2em;\\r\\n\\r\\n        text-align: center;\\r\\n\\r\\n        font-family: 'Noto Sans', sans-serif;\\r\\n        font-weight: bold;\\r\\n        font-size: 0.75rem;\\r\\n        color: #000;\\r\\n        background: #fff;\\r\\n        cursor: pointer;\\r\\n        border: 0;\\r\\n        border-bottom: 4px solid #0002;\\r\\n        box-sizing: border-box;\\r\\n        transition: background 0.3s cubic-bezier(0, 0, 0.3, 1);\\r\\n    }\\r\\n    div.active button {\\r\\n        background: #ddd;\\r\\n    }\\r\\n\\r\\n    :global(.dark) button {\\r\\n        background: #222;\\r\\n        color: #fff;\\r\\n    }\\r\\n    :global(.dark) div.active button {\\r\\n        background: #444;\\r\\n    }\\r\\n\\r\\n    .contents {\\r\\n        width: 100vw;\\r\\n        height: calc(100% - 1.5em);\\r\\n        position: absolute;\\r\\n        display: block;\\r\\n        bottom: 0;\\r\\n        overflow: auto;\\r\\n    }\\r\\n    div:not(.active) .contents {\\r\\n        display: none;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAsBI,iCAAI,CACA,QAAQ,CAAE,QAAQ,CAClB,MAAM,CAAE,IAAI,CACZ,IAAI,CAAE,CACV,CACA,GAAG,qCAAQ,CACP,OAAO,CAAE,CACb,CAEA,oCAAO,CACH,QAAQ,CAAE,QAAQ,CAElB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,GAAG,CAEX,UAAU,CAAE,MAAM,CAElB,WAAW,CAAE,WAAW,CAAC,CAAC,UAAU,CACpC,WAAW,CAAE,IAAI,CACjB,SAAS,CAAE,OAAO,CAClB,KAAK,CAAE,IAAI,CACX,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,OAAO,CACf,MAAM,CAAE,CAAC,CACT,aAAa,CAAE,GAAG,CAAC,KAAK,CAAC,KAAK,CAC9B,UAAU,CAAE,UAAU,CACtB,UAAU,CAAE,UAAU,CAAC,IAAI,CAAC,aAAa,CAAC,CAAC,CAAC,CAAC,CAAC,CAAC,GAAG,CAAC,CAAC,CAAC,CACzD,CACA,GAAG,sBAAO,CAAC,qBAAO,CACd,UAAU,CAAE,IAChB,CAEQ,KAAM,CAAC,oCAAO,CAClB,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACX,CACQ,KAAM,CAAC,GAAG,sBAAO,CAAC,qBAAO,CAC7B,UAAU,CAAE,IAChB,CAEA,uCAAU,CACN,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,KAAK,CAAC,CAC1B,QAAQ,CAAE,QAAQ,CAClB,OAAO,CAAE,KAAK,CACd,MAAM,CAAE,CAAC,CACT,QAAQ,CAAE,IACd,CACA,kBAAG,KAAK,OAAO,CAAC,CAAC,wBAAU,CACvB,OAAO,CAAE,IACb"}`
};
const Tab = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { title = "Unknown" } = $$props;
  let { activeTab = 0 } = $$props;
  let { tabs } = $$props;
  let { handleTabClick } = $$props;
  let { registerTab } = $$props;
  let id2 = registerTab();
  if ($$props.title === void 0 && $$bindings.title && title !== void 0) $$bindings.title(title);
  if ($$props.activeTab === void 0 && $$bindings.activeTab && activeTab !== void 0) $$bindings.activeTab(activeTab);
  if ($$props.tabs === void 0 && $$bindings.tabs && tabs !== void 0) $$bindings.tabs(tabs);
  if ($$props.handleTabClick === void 0 && $$bindings.handleTabClick && handleTabClick !== void 0) $$bindings.handleTabClick(handleTabClick);
  if ($$props.registerTab === void 0 && $$bindings.registerTab && registerTab !== void 0) $$bindings.registerTab(registerTab);
  $$result.css.add(css$9);
  return `<div class="${["svelte-1cswslp", id2 === activeTab ? "active" : ""].join(" ").trim()}"><button class="svelte-1cswslp">${escape(title)}</button> <div class="contents svelte-1cswslp"${add_styles({ "left": `calc(-${id2 / tabs} * 100vw)` })}>${slots.default ? slots.default({}) : ``}</div> </div>`;
});
const ExitIcon = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%208%208'%3e%3cpath%20d='M%202%200.4%20A%201%201%2045%200%200%200.4%202%20L%202.4%204%20L%200.4%206%20A%201%201%2045%200%200%202%207.6%20L%204%205.6%20L%206%207.6%20A%201%201%2045%200%200%207.6%206%20L%205.6%204%20L%207.6%202%20A%201%201%2045%200%200%206%200.4%20L%204%202.5%20Z'%20fill='%23000'/%3e%3c/svg%3e";
const css$8 = {
  code: ".modal.svelte-1b8k0ty.svelte-1b8k0ty{position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:999;backdrop-filter:brightness(0.7) blur(.25vh)}.modal.svelte-1b8k0ty.svelte-1b8k0ty:not(.visible){display:none;z-index:-999}.inside.svelte-1b8k0ty.svelte-1b8k0ty{position:absolute;top:15%;left:15%;width:70%;height:70%;border-radius:1.5rem;background-color:#eee;overflow:hidden}.bar.svelte-1b8k0ty.svelte-1b8k0ty{height:3rem;display:flex;justify-content:center;align-items:center;background:linear-gradient(177.5deg, #fca, #faa)}.title.svelte-1b8k0ty.svelte-1b8k0ty{font-size:1.25rem;font-weight:bold;flex:calc(100% - 2em);text-align:center;opacity:0.8}.exit.svelte-1b8k0ty.svelte-1b8k0ty{flex:2em;margin-right:1em;width:2rem;aspect-ratio:1;border:none;padding:0;background-color:#0000;cursor:pointer;opacity:0.8}.exit.svelte-1b8k0ty img.svelte-1b8k0ty{aspect-ratio:1;padding-top:0.25em}.body.svelte-1b8k0ty.svelte-1b8k0ty{width:100%;height:calc(100% - 3em);padding:1rem;box-sizing:border-box;overflow:auto}.dark .body.svelte-1b8k0ty.svelte-1b8k0ty{background:#222;color:#fff}",
  map: '{"version":3,"file":"Modal.svelte","sources":["Modal.svelte"],"sourcesContent":["<script>\\r\\n    import { onMount } from \\"svelte\\";\\r\\n\\r\\n    import ExitIcon from \\"$lib/images/nav/exit.svg\\"\\r\\n\\r\\n    export let id = \\"unknown\\";\\r\\n    export let title = \\"Unknown\\";\\r\\n\\r\\n    let data = {\\r\\n        visible: false,\\r\\n        update: function () {data = data},\\r\\n        toggle: function () {data.visible = !data.visible; data.update()}\\r\\n    }\\r\\n    \\r\\n    onMount(() => {\\r\\n        if (!window.modals) window.modals = {}\\r\\n        window.modals[id] = data\\r\\n    })\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"modal\\" class:visible={data.visible}>\\r\\n    <div class=\\"inside\\">\\r\\n        <div class=\\"bar\\">\\r\\n            <span class=\\"title\\">{title}</span>\\r\\n            <button class=\\"exit\\" on:click={data.toggle}>\\r\\n                <img src={ExitIcon} alt=\\"\\" />\\r\\n            </button>\\r\\n        </div>\\r\\n        <div class=\\"body\\">\\r\\n            <slot {data} />\\r\\n        </div>\\r\\n    </div>\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .modal {\\r\\n        position: fixed;\\r\\n        top: 0;\\r\\n        left: 0;\\r\\n        width: 100vw;\\r\\n        height: 100vh;\\r\\n        z-index: 999;\\r\\n        backdrop-filter: brightness(0.7) blur(.25vh);\\r\\n    }\\r\\n    .modal:not(.visible) {\\r\\n        display: none;\\r\\n        z-index: -999;\\r\\n    }\\r\\n\\r\\n    .inside {\\r\\n        position: absolute;\\r\\n        top: 15%;\\r\\n        left: 15%;\\r\\n        width: 70%;\\r\\n        height: 70%;\\r\\n        border-radius: 1.5rem;\\r\\n        background-color: #eee;\\r\\n        overflow: hidden;\\r\\n    }\\r\\n\\r\\n    .bar {\\r\\n        height: 3rem;\\r\\n        display: flex;\\r\\n        justify-content: center;\\r\\n        align-items: center;\\r\\n        background: linear-gradient(177.5deg, #fca, #faa);\\r\\n    }\\r\\n    \\r\\n    .title {\\r\\n        font-size: 1.25rem;\\r\\n        font-weight: bold;\\r\\n        flex: calc(100% - 2em);\\r\\n        text-align: center;\\r\\n        opacity: 0.8;\\r\\n    }\\r\\n\\r\\n    .exit {\\r\\n        flex: 2em;\\r\\n        margin-right: 1em;\\r\\n        width: 2rem;\\r\\n        aspect-ratio: 1;\\r\\n        border: none;\\r\\n        padding: 0;\\r\\n        background-color: #0000;\\r\\n        cursor: pointer;\\r\\n        opacity: 0.8;\\r\\n    }\\r\\n    .exit img {\\r\\n        aspect-ratio: 1;\\r\\n        padding-top: 0.25em;\\r\\n    }\\r\\n\\r\\n    .body {\\r\\n        width: 100%;\\r\\n        height: calc(100% - 3em);\\r\\n        padding: 1rem;\\r\\n        box-sizing: border-box;\\r\\n        overflow: auto;\\r\\n    }\\r\\n\\r\\n    :global(.dark) .body {\\r\\n        background: #222;\\r\\n        color: #fff;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAmCI,oCAAO,CACH,QAAQ,CAAE,KAAK,CACf,GAAG,CAAE,CAAC,CACN,IAAI,CAAE,CAAC,CACP,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,KAAK,CACb,OAAO,CAAE,GAAG,CACZ,eAAe,CAAE,WAAW,GAAG,CAAC,CAAC,KAAK,KAAK,CAC/C,CACA,oCAAM,KAAK,QAAQ,CAAE,CACjB,OAAO,CAAE,IAAI,CACb,OAAO,CAAE,IACb,CAEA,qCAAQ,CACJ,QAAQ,CAAE,QAAQ,CAClB,GAAG,CAAE,GAAG,CACR,IAAI,CAAE,GAAG,CACT,KAAK,CAAE,GAAG,CACV,MAAM,CAAE,GAAG,CACX,aAAa,CAAE,MAAM,CACrB,gBAAgB,CAAE,IAAI,CACtB,QAAQ,CAAE,MACd,CAEA,kCAAK,CACD,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,UAAU,CAAE,gBAAgB,QAAQ,CAAC,CAAC,IAAI,CAAC,CAAC,IAAI,CACpD,CAEA,oCAAO,CACH,SAAS,CAAE,OAAO,CAClB,WAAW,CAAE,IAAI,CACjB,IAAI,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,GAAG,CAAC,CACtB,UAAU,CAAE,MAAM,CAClB,OAAO,CAAE,GACb,CAEA,mCAAM,CACF,IAAI,CAAE,GAAG,CACT,YAAY,CAAE,GAAG,CACjB,KAAK,CAAE,IAAI,CACX,YAAY,CAAE,CAAC,CACf,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,CAAC,CACV,gBAAgB,CAAE,KAAK,CACvB,MAAM,CAAE,OAAO,CACf,OAAO,CAAE,GACb,CACA,oBAAK,CAAC,kBAAI,CACN,YAAY,CAAE,CAAC,CACf,WAAW,CAAE,MACjB,CAEA,mCAAM,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,GAAG,CAAC,CACxB,OAAO,CAAE,IAAI,CACb,UAAU,CAAE,UAAU,CACtB,QAAQ,CAAE,IACd,CAEQ,KAAM,CAAC,mCAAM,CACjB,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IACX"}'
};
const Modal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { id: id2 = "unknown" } = $$props;
  let { title = "Unknown" } = $$props;
  let data = {
    visible: false,
    update() {
      data = data;
    },
    toggle() {
      data.visible = !data.visible;
      data.update();
    }
  };
  if ($$props.id === void 0 && $$bindings.id && id2 !== void 0) $$bindings.id(id2);
  if ($$props.title === void 0 && $$bindings.title && title !== void 0) $$bindings.title(title);
  $$result.css.add(css$8);
  return `<div class="${["modal svelte-1b8k0ty", data.visible ? "visible" : ""].join(" ").trim()}"><div class="inside svelte-1b8k0ty"><div class="bar svelte-1b8k0ty"><span class="title svelte-1b8k0ty">${escape(title)}</span> <button class="exit svelte-1b8k0ty" data-svelte-h="svelte-i6ivgn"><img${add_attribute("src", ExitIcon, 0)} alt="" class="svelte-1b8k0ty"></button></div> <div class="body svelte-1b8k0ty">${slots.default ? slots.default({ data }) : ``}</div></div> </div>`;
});
const translations = {
  en: {
    language: "Language",
    save: "Save",
    load: "Load",
    experiments: "Experiments",
    discord: "Discord",
    editor: "Editor",
    blocks: "Blocks",
    properties: "Properties",
    export: "Export",
    editBlock: "Edit Block",
    type: "Type",
    text: "Text",
    label: "Label",
    string: "String",
    number: "Number",
    boolean: "Boolean",
    defaultValue: "Default value",
    delete: "Delete",
    addField: "Add field",
    command: "Command",
    reporter: "Reporter",
    noBlocks: "no blocks yet!",
    createBlockConfirmation: "Are you sure you want to make a block?",
    deleteBlockConfirmation: "Are you sure you want to delete this block?",
    registerVariable: "Register Variable",
    variableName: "variable name",
    unknown: "Unknown",
    register: "Register",
    copy: "Copy",
    unsandboxed: "Make sure to run the extension unsandboxed.",
    id: "ID",
    color: "Color"
  },
  "pt-BR": {
    language: "Idioma",
    save: "Salvar",
    load: "Carregar",
    experiments: "Experimentos",
    discord: "Discord",
    editor: "Editor",
    blocks: "Blocos",
    properties: "Propriedades",
    export: "Exportar",
    editBlock: "Editar bloco",
    type: "Tipo",
    text: "Texto",
    label: "Rótulo",
    string: "Texto",
    number: "Número",
    boolean: "Booleano",
    defaultValue: "Valor padrão",
    delete: "Excluir",
    addField: "Adicionar campo",
    command: "Comando",
    reporter: "Repórter",
    noBlocks: "nenhum bloco ainda!",
    createBlockConfirmation: "Tem certeza de que deseja criar um bloco?",
    deleteBlockConfirmation: "Tem certeza de que deseja excluir este bloco?",
    registerVariable: "Registrar variável",
    variableName: "nome da variável",
    unknown: "Desconhecido",
    register: "Registrar",
    copy: "Copiar",
    unsandboxed: "Certifique-se de executar a extensão sem sandbox.",
    id: "ID",
    color: "Cor"
  },
  es: {
    language: "Idioma",
    save: "Guardar",
    load: "Cargar",
    experiments: "Experimentos",
    discord: "Discord",
    editor: "Editor",
    blocks: "Bloques",
    properties: "Propiedades",
    export: "Exportar",
    editBlock: "Editar bloque",
    type: "Tipo",
    text: "Texto",
    label: "Etiqueta",
    string: "Texto",
    number: "Número",
    boolean: "Booleano",
    defaultValue: "Valor predeterminado",
    delete: "Eliminar",
    addField: "Añadir campo",
    command: "Comando",
    reporter: "Reportero",
    noBlocks: "¡todavía no hay bloques!",
    createBlockConfirmation: "¿Seguro que quieres crear un bloque?",
    deleteBlockConfirmation: "¿Seguro que quieres eliminar este bloque?",
    registerVariable: "Registrar variable",
    variableName: "nombre de variable",
    unknown: "Desconocido",
    register: "Registrar",
    copy: "Copiar",
    unsandboxed: "Asegúrate de ejecutar la extensión sin sandbox.",
    id: "ID",
    color: "Color"
  }
};
const supportedLanguages = [
  { id: "en", label: "English" },
  { id: "pt-BR", label: "Português (Brasil)" },
  { id: "es", label: "Español" }
];
function browserLanguage() {
  if (typeof navigator === "undefined") return "en";
  const preferred = navigator.language.toLowerCase();
  if (preferred.startsWith("pt")) return "pt-BR";
  if (preferred.startsWith("es")) return "es";
  return "en";
}
let currentLanguage = browserLanguage();
const language = writable(currentLanguage);
function getLanguage() {
  return currentLanguage;
}
function t(key, currentLanguage2 = "en") {
  return translations[currentLanguage2]?.[key] || translations.en[key] || key;
}
const blockWords = {
  "pt-BR": {
    move: "mova",
    steps: "passos",
    turn: "gire",
    left: "esquerda",
    right: "direita",
    degrees: "graus",
    go: "vá",
    to: "para",
    x: "x",
    y: "y",
    glide: "deslize",
    secs: "segundos",
    point: "aponte",
    towards: "em direção a",
    change: "mude",
    by: "por",
    set: "defina",
    position: "posição",
    direction: "direção",
    say: "diga",
    think: "pense",
    switch: "mude",
    costume: "fantasia",
    backdrop: "cenário",
    next: "próximo",
    size: "tamanho",
    effect: "efeito",
    show: "mostre",
    hide: "esconda",
    layer: "camada",
    when: "quando",
    extension: "extensão",
    loaded: "carregada",
    new: "nova",
    thread: "thread",
    broadcast: "transmita",
    and: "e",
    wait: "espere",
    until: "até",
    repeat: "repita",
    while: "enquanto",
    return: "retorne",
    true: "verdadeiro",
    false: "falso",
    random: "aleatório",
    pick: "escolha",
    log: "log",
    contains: "contém",
    item: "item",
    list: "lista",
    create: "crie",
    empty: "vazia",
    join: "junte",
    with: "com",
    delimiter: "delimitador",
    length: "comprimento",
    substring: "subtexto",
    replace: "substitua",
    in: "em",
    console: "console",
    error: "erro",
    parse: "analise",
    json: "json",
    fetch: "busque",
    method: "método",
    headers: "cabeçalhos",
    body: "corpo",
    current: "atual",
    username: "nome de usuário",
    mouse: "mouse",
    touching: "tocando",
    color: "cor",
    distance: "distância",
    ask: "pergunte",
    answer: "resposta",
    timer: "cronômetro",
    if: "se",
    then: "então",
    else: "senão",
    seconds: "segundos",
    next: "próximo",
    frame: "quadro",
    do: "faça",
    inline: "em linha",
    broadcasted: "transmitido",
    green: "verde",
    flag: "bandeira",
    clicked: "clicado",
    this: "este",
    sprite: "ator",
    switches: "muda",
    start: "início",
    clone: "clone",
    play: "toque",
    note: "nota",
    for: "por",
    beats: "batidas",
    stop: "pare",
    instrument: "instrumento",
    tempo: "tempo",
    volume: "volume",
    all: "todos",
    sounds: "sons",
    output: "saída",
    devices: "dispositivos",
    send: "envie",
    midi: "midi",
    off: "desligado",
    channel: "canal",
    received: "recebida",
    message: "mensagem",
    velocity: "velocidade",
    rotation: "rotação",
    style: "estilo",
    xor: "ou exclusivo",
    not: "não",
    eval: "avalie",
    try: "tente",
    catch: "capture",
    typeof: "tipo de",
    get: "obtenha",
    global: "global",
    split: "divida",
    times: "vezes",
    amount: "quantidade",
    of: "de",
    each: "cada",
    value: "valor",
    is: "é",
    key: "tecla",
    pressed: "pressionada",
    sprite: "ator",
    switches: "muda",
    invisible: "invisível",
    loudness: "volume",
    draggable: "arrastável",
    reset: "reinicie",
    days: "dias",
    since: "desde",
    project: "projeto",
    running: "executando",
    enabled: "ativado",
    rate: "taxa",
    before: "antes",
    tick: "ciclo",
    mode: "modo",
    set: "defina",
    use: "use",
    with: "com",
    delimiter: "delimitador",
    to: "para",
    string: "texto"
  },
  es: {
    move: "mueve",
    steps: "pasos",
    turn: "gira",
    left: "izquierda",
    right: "derecha",
    degrees: "grados",
    go: "ve",
    to: "a",
    x: "x",
    y: "y",
    glide: "desliza",
    secs: "segundos",
    point: "apunta",
    towards: "hacia",
    change: "cambia",
    by: "en",
    set: "fija",
    position: "posición",
    direction: "dirección",
    say: "di",
    think: "piensa",
    switch: "cambia",
    costume: "disfraz",
    backdrop: "fondo",
    next: "siguiente",
    size: "tamaño",
    effect: "efecto",
    show: "muestra",
    hide: "oculta",
    layer: "capa",
    when: "cuando",
    extension: "extensión",
    loaded: "cargada",
    new: "nuevo",
    thread: "hilo",
    broadcast: "envía",
    and: "y",
    wait: "espera",
    until: "hasta",
    repeat: "repite",
    while: "mientras",
    return: "devuelve",
    true: "verdadero",
    false: "falso",
    random: "aleatorio",
    pick: "elige",
    log: "registro",
    contains: "contiene",
    item: "elemento",
    list: "lista",
    create: "crea",
    empty: "vacía",
    join: "une",
    with: "con",
    delimiter: "delimitador",
    length: "longitud",
    substring: "subcadena",
    replace: "reemplaza",
    in: "en",
    console: "consola",
    error: "error",
    parse: "analiza",
    json: "json",
    fetch: "obtén",
    method: "método",
    headers: "encabezados",
    body: "cuerpo",
    current: "actual",
    username: "usuario",
    mouse: "ratón",
    touching: "tocando",
    color: "color",
    distance: "distancia",
    ask: "pregunta",
    answer: "respuesta",
    timer: "temporizador",
    if: "si",
    then: "entonces",
    else: "si no",
    seconds: "segundos",
    next: "siguiente",
    frame: "marco",
    do: "haz",
    inline: "en línea",
    broadcasted: "transmitido",
    green: "verde",
    flag: "bandera",
    clicked: "pulsado",
    this: "este",
    sprite: "objeto",
    switches: "cambia",
    start: "inicio",
    clone: "clon",
    play: "reproduce",
    note: "nota",
    for: "por",
    beats: "pulsos",
    stop: "detén",
    instrument: "instrumento",
    tempo: "tempo",
    volume: "volumen",
    all: "todos",
    sounds: "sonidos",
    output: "salida",
    devices: "dispositivos",
    send: "envía",
    midi: "midi",
    off: "apagado",
    channel: "canal",
    received: "recibido",
    message: "mensaje",
    velocity: "velocidad",
    rotation: "rotación",
    style: "estilo",
    xor: "o exclusivo",
    not: "no",
    eval: "evalúa",
    try: "intenta",
    catch: "captura",
    typeof: "tipo de",
    get: "obtén",
    global: "global",
    split: "divide",
    times: "veces",
    amount: "cantidad",
    of: "de",
    each: "cada",
    value: "valor",
    is: "está",
    key: "tecla",
    pressed: "pulsada",
    invisible: "invisible",
    loudness: "volumen",
    draggable: "arrastrable",
    reset: "reinicia",
    days: "días",
    since: "desde",
    project: "proyecto",
    running: "ejecutándose",
    enabled: "activado",
    rate: "tasa",
    before: "antes",
    tick: "ciclo",
    mode: "modo",
    use: "usa",
    string: "texto"
  }
};
function translateBlockText(text, currentLanguage2) {
  if (currentLanguage2 === "en" || typeof text !== "string") return text;
  return text.replace(/[A-Za-z]+/g, (word) => {
    const translated = blockWords[currentLanguage2]?.[word.toLowerCase()];
    return translated || word;
  });
}
function translateBlockJson(jsonData, currentLanguage2 = "en") {
  const localized = { ...jsonData };
  for (let index = 0; localized[`message${index}`]; index++) {
    localized[`message${index}`] = translateBlockText(
      localized[`message${index}`],
      currentLanguage2
    );
  }
  return localized;
}
function translateToolbox(xml, currentLanguage2 = "en") {
  const categories = {
    "pt-BR": {
      Motion: "Movimento",
      Looks: "Aparência",
      Events: "Eventos",
      Control: "Controle",
      Math: "Matemática",
      Strings: "Textos",
      Vectors: "Vetores",
      Sensors: "Sensores",
      Variables: "Variáveis",
      Lists: "Listas",
      Blocks: "Blocos",
      Runtime: "Execução",
      Script: "Script",
      Music: "Música",
      Generic: "Genérico",
      Lambdas: "Lambdas",
      Sprites: "Sprites",
      Sound: "Som",
      Clones: "Clones",
      Targets: "Alvos",
      Browser: "Navegador"
    },
    es: {
      Motion: "Movimiento",
      Looks: "Apariencia",
      Events: "Eventos",
      Control: "Control",
      Math: "Matemáticas",
      Strings: "Textos",
      Vectors: "Vectores",
      Sensors: "Sensores",
      Variables: "Variables",
      Lists: "Listas",
      Blocks: "Bloques",
      Runtime: "Ejecución",
      Script: "Script",
      Music: "Música",
      Generic: "Genérico",
      Lambdas: "Lambdas",
      Sprites: "Sprites",
      Sound: "Sonido",
      Clones: "Clones",
      Targets: "Objetivos",
      Browser: "Navegador"
    }
  }[currentLanguage2] || {};
  return xml.replace(/(<category\b[^>]*\bname=")([^"]+)(")/g, (match, start2, name, end) => {
    return `${start2}${categories[name] || name}${end}`;
  });
}
let id$2 = "experiments";
const ExperimentsModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  $$unsubscribe_language();
  return `${validate_component(Modal, "Modal").$$render($$result, { id: id$2, title: t("experiments", $language) }, {}, {
    default: ({ data }) => {
      return `todo: make this aaa`;
    }
  })}`;
});
const css$7 = {
  code: '.main.svelte-1nc24j{display:flex;justify-content:center;align-items:center;flex-direction:column;width:100%;min-height:100%}.btn.svelte-1nc24j{display:block;background:linear-gradient(177.5deg, #fa7, #f87);box-sizing:border-box;font-size:1.5rem;border:#0004 solid 0.2rem;border-radius:0.5rem;font-family:"Noto Sans";font-weight:bold;padding:0.2rem 0.5rem;margin:0.5rem}',
  map: '{"version":3,"file":"CreateVariableModal.svelte","sources":["CreateVariableModal.svelte"],"sourcesContent":["<script>\\r\\n    import Blockly from \\"blockly/core\\"\\r\\n    import Modal from \\"./Modal.svelte\\";\\r\\n    import { language, t } from \\"$lib/i18n\\";\\r\\n\\r\\n    let varName = \\"my variable\\"\\r\\n    let varType = \\"null\\"\\r\\n\\r\\n    function register(data) {\\r\\n        window.variables[varName] = {\\r\\n            type: varType === \\"null\\" ? null : varType\\r\\n        }\\r\\n\\r\\n        data.toggle()\\r\\n\\r\\n        varName = \\"my variable\\"\\r\\n        varType = \\"null\\"\\r\\n        window.workspace.refreshToolboxSelection()\\r\\n    }\\r\\n\\r\\n    let id = \\"createVariable\\"\\r\\n<\/script>\\r\\n\\r\\n<Modal id={id} title={t(\\"registerVariable\\", $language)} let:data>\\r\\n    <div class=\\"main\\">\\r\\n        <input type=\\"text\\" placeholder={t(\\"variableName\\", $language)} bind:value={varName}>\\r\\n        <select bind:value={varType}>\\r\\n            <option value=\\"null\\">{t(\\"unknown\\", $language)}</option>\\r\\n            <option value=\\"String\\">String</option>\\r\\n            <option value=\\"Number\\">Number</option>\\r\\n            <option value=\\"Boolean\\">Boolean</option>\\r\\n            <option value=\\"List\\">List</option>\\r\\n            <option value=\\"Vector\\">Vector</option>\\r\\n        </select>\\r\\n        <button class=\\"btn\\" on:click={() => {register(data)}}>{t(\\"register\\", $language)}</button>\\r\\n    </div>\\r\\n</Modal>\\r\\n\\r\\n<style>\\r\\n    .main {\\r\\n        display: flex;\\r\\n        justify-content: center;\\r\\n        align-items: center;\\r\\n        flex-direction: column;\\r\\n        width: 100%;\\r\\n        min-height: 100%;\\r\\n    }\\r\\n\\r\\n    .btn {\\r\\n        display: block;\\r\\n        background: linear-gradient(177.5deg, #fa7, #f87);\\r\\n        box-sizing: border-box;\\r\\n        font-size: 1.5rem;\\r\\n        border: #0004 solid 0.2rem;\\r\\n        border-radius: 0.5rem;\\r\\n        font-family: \\"Noto Sans\\";\\r\\n        font-weight: bold;\\r\\n        padding: 0.2rem 0.5rem;\\r\\n        margin: 0.5rem;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAuCI,mBAAM,CACF,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAAM,CACvB,WAAW,CAAE,MAAM,CACnB,cAAc,CAAE,MAAM,CACtB,KAAK,CAAE,IAAI,CACX,UAAU,CAAE,IAChB,CAEA,kBAAK,CACD,OAAO,CAAE,KAAK,CACd,UAAU,CAAE,gBAAgB,QAAQ,CAAC,CAAC,IAAI,CAAC,CAAC,IAAI,CAAC,CACjD,UAAU,CAAE,UAAU,CACtB,SAAS,CAAE,MAAM,CACjB,MAAM,CAAE,KAAK,CAAC,KAAK,CAAC,MAAM,CAC1B,aAAa,CAAE,MAAM,CACrB,WAAW,CAAE,WAAW,CACxB,WAAW,CAAE,IAAI,CACjB,OAAO,CAAE,MAAM,CAAC,MAAM,CACtB,MAAM,CAAE,MACZ"}'
};
let id$1 = "createVariable";
const CreateVariableModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  let varName = "my variable";
  $$result.css.add(css$7);
  $$unsubscribe_language();
  return `${validate_component(Modal, "Modal").$$render(
    $$result,
    {
      id: id$1,
      title: t("registerVariable", $language)
    },
    {},
    {
      default: ({ data }) => {
        return `<div class="main svelte-1nc24j"><input type="text"${add_attribute("placeholder", t("variableName", $language), 0)}${add_attribute("value", varName, 0)}> <select><option value="null">${escape(t("unknown", $language))}</option><option value="String" data-svelte-h="svelte-c0tl5a">String</option><option value="Number" data-svelte-h="svelte-vv1yq6">Number</option><option value="Boolean" data-svelte-h="svelte-179isni">Boolean</option><option value="List" data-svelte-h="svelte-z35k9a">List</option><option value="Vector" data-svelte-h="svelte-1k8ovq6">Vector</option></select> <button class="btn svelte-1nc24j">${escape(t("register", $language))}</button></div>`;
      }
    }
  )}`;
});
const css$6 = {
  code: ".main.svelte-1te837h.svelte-1te837h.svelte-1te837h{display:flex;flex-direction:column;height:100%;gap:8px}.preview.svelte-1te837h.svelte-1te837h.svelte-1te837h{flex:1}.fields.svelte-1te837h.svelte-1te837h.svelte-1te837h{flex:2;overflow-y:scroll\r\n    }.fields.svelte-1te837h table.svelte-1te837h.svelte-1te837h{width:100%}.fields.svelte-1te837h tr.svelte-1te837h>.svelte-1te837h:nth-child(1){width:20%}.fields.svelte-1te837h tr.svelte-1te837h>.svelte-1te837h:nth-child(2){width:30%}.fields.svelte-1te837h tr.svelte-1te837h>.svelte-1te837h:nth-child(4){float:right}.svelte-1te837h.svelte-1te837h.svelte-1te837h:is(input, select):only-child{width:100%;box-sizing:border-box}",
  map: '{"version":3,"file":"EditBlockModal.svelte","sources":["EditBlockModal.svelte"],"sourcesContent":["<script>\\r\\n    import Modal from \\"./Modal.svelte\\";\\r\\n    import util from \\"../../resources/util\\";\\r\\n\\r\\n    let id = \\"editblock\\";\\r\\n\\r\\n    import Blockly from \\"blockly/core\\";\\r\\n\\r\\n    import En from \\"blockly/msg/en\\";\\r\\n    import PtBr from \\"blockly/msg/pt-br\\";\\r\\n    import Es from \\"blockly/msg/es\\";\\r\\n    import \\"blockly/blocks\\";\\r\\n    import \\"blockly/javascript\\";\\r\\n\\r\\n    import BlocklyComponent from \\"$lib/svelte-blockly\\";\\r\\n    import { onMount } from \\"svelte\\";\\r\\n    import { language, t } from \\"$lib/i18n\\";\\r\\n    /** @type {Blockly.WorkspaceSvg} */\\r\\n    let workspace;\\r\\n\\r\\n    $: locale = {\\r\\n        rtl: false,\\r\\n        msg: { en: En, \\"pt-BR\\": PtBr, es: Es }[$language],\\r\\n    };\\r\\n\\r\\n    const config = {\\r\\n        scrollbars: false,\\r\\n        readOnly: true,\\r\\n        renderer: \\"custom_renderer\\",\\r\\n        zoom: {\\r\\n            controls: false,\\r\\n            wheel: true,\\r\\n            startScale: 0.8,\\r\\n            maxScale: 2,\\r\\n            minScale: 0.5,\\r\\n            scaleSpeed: 1.1,\\r\\n        },\\r\\n    };\\r\\n\\r\\n    function updateBlocks(data) {\\r\\n        if (!previewBlock || !workspace) return;\\r\\n        previewBlock.blockId_ = data.blockId\\r\\n        previewBlock.updateShape_()\\r\\n        previewBlock.render();\\r\\n\\r\\n        //refresh workspace\\r\\n        try {\\r\\n            let workspaceG = window.workspace\\r\\n            let xml = Blockly.Xml.workspaceToDom(workspaceG);\\r\\n            workspaceG.clear();\\r\\n            Blockly.Xml.domToWorkspace(xml, workspaceG);\\r\\n            workspaceG.refreshToolboxSelection();\\r\\n        } catch (error) {\\r\\n            console.warn(\\"Unable to refresh the workspace after editing a block.\\", error);\\r\\n        }\\r\\n\\r\\n        requestAnimationFrame(() => {\\r\\n            Blockly.svgResize(workspace);\\r\\n            workspace.centerOnBlock(previewBlock.id);\\r\\n        });\\r\\n    }\\r\\n\\r\\n    function saveBlock(data) {\\r\\n        data.toggle()\\r\\n        window.blocks[data.blockId] = data.tempBlock\\r\\n        updateBlocks(data)\\r\\n    }\\r\\n\\r\\n    let previewBlock\\r\\n\\r\\n    onMount(() => {\\r\\n        previewBlock = workspace.newBlock(\\"blocks_execute\\");\\r\\n        previewBlock.initSvg();\\r\\n        previewBlock.render();\\r\\n\\r\\n        const old = window.modals[id].update\\r\\n        window.modals[id].update = function() {\\r\\n            old.call(this)\\r\\n            requestAnimationFrame(() => {\\r\\n                requestAnimationFrame(() => updateBlocks(window.modals[id]));\\r\\n            });\\r\\n        }\\r\\n\\r\\n        addEventListener(\\"resize\\", () => {\\r\\n            if (workspace && previewBlock) {\\r\\n                Blockly.svgResize(workspace);\\r\\n                workspace.centerOnBlock(previewBlock.id);\\r\\n            }\\r\\n        })\\r\\n    });\\r\\n<\/script>\\r\\n\\r\\n<Modal {id} title={t(\\"editBlock\\", $language)} let:data>\\r\\n    <div class=\\"main\\">\\r\\n        <div class=\\"preview\\">\\r\\n            <BlocklyComponent {config} locale={locale} bind:workspace />\\r\\n        </div>\\r\\n        <div class=\\"fields\\">\\r\\n            <table class=\\"fields\\">\\r\\n                <tr>\\r\\n                    <th>{t(\\"type\\", $language)}</th>\\r\\n                    <th>{t(\\"text\\", $language)}</th>\\r\\n                    <th><!-- options --></th>\\r\\n                    <th><!-- buttons --></th>\\r\\n                </tr>\\r\\n                {#each Object.keys(data.tempBlock ? data.tempBlock.fields : {}) as i}\\r\\n                    <tr>\\r\\n                        <td>\\r\\n                            <select value={data.tempBlock.fields[i].type} on:change={(e) => {\\r\\n                                data.tempBlock.fields[i].type = e.target.value\\r\\n                                data.update()\\r\\n                                updateBlocks(data)\\r\\n                            }}>\\r\\n                                <option value=\\"label\\">{t(\\"label\\", $language)}</option>\\r\\n                                <option value=\\"string\\">{t(\\"string\\", $language)}</option>\\r\\n                                <option value=\\"number\\">{t(\\"number\\", $language)}</option>\\r\\n                                <option value=\\"boolean\\">{t(\\"boolean\\", $language)}</option>\\r\\n                            </select>\\r\\n                        </td>\\r\\n                        <td>\\r\\n                            <input type=\\"text\\" value={data.tempBlock.fields[i].text} on:change={(e) => {\\r\\n                                data.tempBlock.fields[i].text = e.target.value\\r\\n                                data.update()\\r\\n                                updateBlocks(data)\\r\\n                            }} />\\r\\n                        </td>\\r\\n                        <td>\\r\\n                            {#if data.tempBlock.fields[i].type == \\"string\\"}\\r\\n                                <input type=\\"text\\" value={data.tempBlock.fields[i].default ?? \\"\\"} placeholder={t(\\"defaultValue\\", $language)} on:change={(e) => {\\r\\n                                    data.tempBlock.fields[i].default = e.target.value\\r\\n                                    data.update()\\r\\n                                    updateBlocks(data)\\r\\n                                }} />\\r\\n                            {:else if data.tempBlock.fields[i].type == \\"number\\"}\\r\\n                                <input type=\\"number\\" value={data.tempBlock.fields[i].default ?? \\"\\"} placeholder={t(\\"defaultValue\\", $language)} on:change={(e) => {\\r\\n                                    data.tempBlock.fields[i].default = e.target.value\\r\\n                                    data.update()\\r\\n                                    updateBlocks(data)\\r\\n                                }} />\\r\\n                            {/if}\\r\\n                        </td>\\r\\n                        <td>\\r\\n                            <button on:click={() => {\\r\\n                                data.tempBlock.fields.splice(i, 1)\\r\\n                                data.update()\\r\\n                                updateBlocks(data)\\r\\n                            }}>{t(\\"delete\\", $language)}</button>\\r\\n                        </td>\\r\\n                    </tr>\\r\\n                {/each}\\r\\n            </table>\\r\\n        </div>\\r\\n        <div class=\\"bottom\\">\\r\\n            <!--<button on:click={() => saveBlock(data)}>Save</button>-->\\r\\n            <button on:click={() => {\\r\\n                data.tempBlock.fields.push({\\r\\n                    type: \\"label\\",\\r\\n                    text: \\"text\\",\\r\\n                    id: util.randomHex(16)\\r\\n                })\\r\\n                data.update()\\r\\n                updateBlocks(data)\\r\\n            }}>{t(\\"addField\\", $language)}</button>\\r\\n            <select value={(data.tempBlock ?? {}).type} on:change={(e) => {\\r\\n                data.tempBlock.type = e.target.value\\r\\n                data.update()\\r\\n                updateBlocks(data)\\r\\n            }}>\\r\\n                <option value=\\"command\\">{t(\\"command\\", $language)}</option>\\r\\n                <option value=\\"reporter\\">{t(\\"reporter\\", $language)}</option>\\r\\n                <option value=\\"Boolean\\">{t(\\"boolean\\", $language)}</option>\\r\\n            </select>\\r\\n        </div>\\r\\n    </div>\\r\\n</Modal>\\r\\n\\r\\n<style>\\r\\n    .main {\\r\\n        display: flex;\\r\\n        flex-direction: column;\\r\\n        height: 100%;\\r\\n        gap: 8px;\\r\\n    }\\r\\n\\r\\n    .preview {\\r\\n        flex: 1;\\r\\n    }\\r\\n\\r\\n    .fields {\\r\\n        flex: 2;\\r\\n        overflow-y: scroll\\r\\n    }\\r\\n\\r\\n    .fields table {\\r\\n        width: 100%;\\r\\n    }\\r\\n\\r\\n    .fields tr > *:nth-child(1) {\\r\\n        width: 20%;\\r\\n    }\\r\\n    .fields tr > *:nth-child(2) {\\r\\n        width: 30%;\\r\\n    }\\r\\n    .fields tr > *:nth-child(4) {\\r\\n        float: right;\\r\\n    }\\r\\n\\r\\n    :is(input, select):only-child {\\r\\n        width: 100%;\\r\\n        box-sizing: border-box;\\r\\n    }\\r\\n\\r\\n    .bottom {\\r\\n\\r\\n    }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAiLI,kDAAM,CACF,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,GACT,CAEA,qDAAS,CACL,IAAI,CAAE,CACV,CAEA,oDAAQ,CACJ,IAAI,CAAE,CAAC,CACP,UAAU,CAAE,MAAM;AAC1B,IAAI,CAEA,sBAAO,CAAC,mCAAM,CACV,KAAK,CAAE,IACX,CAEA,sBAAO,CAAC,iBAAE,CAAG,eAAC,WAAW,CAAC,CAAE,CACxB,KAAK,CAAE,GACX,CACA,sBAAO,CAAC,iBAAE,CAAG,eAAC,WAAW,CAAC,CAAE,CACxB,KAAK,CAAE,GACX,CACA,sBAAO,CAAC,iBAAE,CAAG,eAAC,WAAW,CAAC,CAAE,CACxB,KAAK,CAAE,KACX,8CAEA,IAAI,KAAK,EAAE,MAAM,CAAC,WAAY,CAC1B,KAAK,CAAE,IAAI,CACX,UAAU,CAAE,UAChB"}'
};
let id = "editblock";
const EditBlockModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let locale;
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  let workspace;
  const config = {
    scrollbars: false,
    readOnly: true,
    renderer: "custom_renderer",
    zoom: {
      controls: false,
      wheel: true,
      startScale: 0.8,
      maxScale: 2,
      minScale: 0.5,
      scaleSpeed: 1.1
    }
  };
  $$result.css.add(css$6);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    locale = {
      rtl: false,
      msg: { en: En, "pt-BR": PtBr, es: Es }[$language]
    };
    $$rendered = `${validate_component(Modal, "Modal").$$render($$result, { id, title: t("editBlock", $language) }, {}, {
      default: ({ data }) => {
        return `<div class="main svelte-1te837h"><div class="preview svelte-1te837h">${validate_component(Component, "BlocklyComponent").$$render(
          $$result,
          { config, locale, workspace },
          {
            workspace: ($$value) => {
              workspace = $$value;
              $$settled = false;
            }
          },
          {}
        )}</div> <div class="fields svelte-1te837h"><table class="fields svelte-1te837h"><tr class="svelte-1te837h"><th class="svelte-1te837h">${escape(t("type", $language))}</th> <th class="svelte-1te837h">${escape(t("text", $language))}</th> <th class="svelte-1te837h" data-svelte-h="svelte-1ykfjux"></th> <th class="svelte-1te837h" data-svelte-h="svelte-aj1czm"></th></tr> ${each(Object.keys(data.tempBlock ? data.tempBlock.fields : {}), (i) => {
          return `<tr class="svelte-1te837h"><td class="svelte-1te837h"><select${add_attribute("value", data.tempBlock.fields[i].type, 0)} class="svelte-1te837h"><option value="label" class="svelte-1te837h">${escape(t("label", $language))}</option><option value="string" class="svelte-1te837h">${escape(t("string", $language))}</option><option value="number" class="svelte-1te837h">${escape(t("number", $language))}</option><option value="boolean" class="svelte-1te837h">${escape(t("boolean", $language))}</option></select></td> <td class="svelte-1te837h"><input type="text"${add_attribute("value", data.tempBlock.fields[i].text, 0)} class="svelte-1te837h"></td> <td class="svelte-1te837h">${data.tempBlock.fields[i].type == "string" ? `<input type="text"${add_attribute("value", data.tempBlock.fields[i].default ?? "", 0)}${add_attribute("placeholder", t("defaultValue", $language), 0)} class="svelte-1te837h">` : `${data.tempBlock.fields[i].type == "number" ? `<input type="number"${add_attribute("value", data.tempBlock.fields[i].default ?? "", 0)}${add_attribute("placeholder", t("defaultValue", $language), 0)} class="svelte-1te837h">` : ``}`}</td> <td class="svelte-1te837h"><button class="svelte-1te837h">${escape(t("delete", $language))}</button></td> </tr>`;
        })}</table></div> <div class="bottom svelte-1te837h"> <button class="svelte-1te837h">${escape(t("addField", $language))}</button> <select${add_attribute("value", (data.tempBlock ?? {}).type, 0)} class="svelte-1te837h"><option value="command" class="svelte-1te837h">${escape(t("command", $language))}</option><option value="reporter" class="svelte-1te837h">${escape(t("reporter", $language))}</option><option value="Boolean" class="svelte-1te837h">${escape(t("boolean", $language))}</option></select></div></div>`;
      }
    })}`;
  } while (!$$settled);
  $$unsubscribe_language();
  return $$rendered;
});
const css$5 = {
  code: '.outer.svelte-2ihhmt{background-color:#333;width:100%;height:100%;padding:8px;box-sizing:border-box;color:#eee}.inner.svelte-2ihhmt{display:block;background-color:#222;width:100%;height:100%;padding:4px;margin:0;box-sizing:border-box;border-radius:8px;overflow:auto;font-family:"JetBrains Mono";font-size:12px}',
  map: '{"version":3,"file":"CodePreview.svelte","sources":["CodePreview.svelte"],"sourcesContent":["<script>\\r\\n    import beautify from \\"js-beautify\\";\\r\\n    import Prism from \\"prismjs\\";\\r\\n\\r\\n    export let code;\\r\\n\\r\\n    function formatCode(x) {\\r\\n        x = beautify.js(x, {\\r\\n            indent_size: 4,\\r\\n            space_in_empty_paren: true,\\r\\n        });\\r\\n\\r\\n        x = Prism.highlight(x, Prism.languages.javascript);\\r\\n\\r\\n        return x;\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<head>\\r\\n    <link rel=\\"stylesheet\\" href=\\"https://cdnjs.cloudflare.com/ajax/libs/prism/1.22.0/themes/prism-tomorrow.min.css\\" />\\r\\n</head>\\r\\n\\r\\n<div class=\\"outer\\">\\r\\n    <pre class=\\"inner\\">{@html formatCode(code)}</pre>\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .outer {\\r\\n        background-color: #333;\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n        padding: 8px;\\r\\n        box-sizing: border-box;\\r\\n        color: #eee;\\r\\n    }\\r\\n\\r\\n    .inner {\\r\\n        display: block;\\r\\n        background-color: #222;\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n        padding: 4px;\\r\\n        margin: 0;\\r\\n        box-sizing: border-box;\\r\\n        border-radius: 8px;\\r\\n        overflow: auto;\\r\\n        font-family: \\"JetBrains Mono\\";\\r\\n        font-size: 12px;\\r\\n    }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AA2BI,oBAAO,CACH,gBAAgB,CAAE,IAAI,CACtB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,GAAG,CACZ,UAAU,CAAE,UAAU,CACtB,KAAK,CAAE,IACX,CAEA,oBAAO,CACH,OAAO,CAAE,KAAK,CACd,gBAAgB,CAAE,IAAI,CACtB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,OAAO,CAAE,GAAG,CACZ,MAAM,CAAE,CAAC,CACT,UAAU,CAAE,UAAU,CACtB,aAAa,CAAE,GAAG,CAClB,QAAQ,CAAE,IAAI,CACd,WAAW,CAAE,gBAAgB,CAC7B,SAAS,CAAE,IACf"}'
};
const CodePreview = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { code } = $$props;
  function formatCode(x) {
    x = beautify.js(x, {
      indent_size: 4,
      space_in_empty_paren: true
    });
    x = Prism.highlight(x, Prism.languages.javascript);
    return x;
  }
  if ($$props.code === void 0 && $$bindings.code && code !== void 0) $$bindings.code(code);
  $$result.css.add(css$5);
  return `<head data-svelte-h="svelte-1gpg2ks"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.22.0/themes/prism-tomorrow.min.css"></head> <div class="outer svelte-2ihhmt"><pre class="inner svelte-2ihhmt"><!-- HTML_TAG_START -->${formatCode(code)}<!-- HTML_TAG_END --></pre> </div>`;
});
const css$4 = {
  code: ".vert.svelte-g3hw76{display:flex;flex-direction:column;align-items:center}.horiz.svelte-g3hw76{display:flex;flex-direction:row;align-items:center}.equal.svelte-g3hw76{flex:1;overflow:hidden}.root.svelte-g3hw76{width:100%;height:100%;justify-content:center}.inner.svelte-g3hw76{width:30em}.bubble.svelte-g3hw76{width:8em;aspect-ratio:1;box-sizing:border-box;border:.5em solid #0004;border-radius:100%}.name.svelte-g3hw76{font-size:1.2em;font-weight:500;background-color:#0002;padding:0.1em 0.3em;border-radius:0.2em;margin-top:0.5em;max-width:100%;box-sizing:border-box;outline:none}.dark .name.svelte-g3hw76{background-color:#fff2}",
  map: '{"version":3,"file":"PropertiesPicker.svelte","sources":["PropertiesPicker.svelte"],"sourcesContent":["<script>\\r\\n    import { createEventDispatcher } from \\"svelte\\";\\r\\n    import { language, t } from \\"$lib/i18n\\";\\r\\n    const dispatch = createEventDispatcher()\\r\\n\\r\\n    export let properties = {\\r\\n        name: \\"Extension\\",\\r\\n        id: \\"extensionID\\",\\r\\n        color: \\"#0fbd8c\\"\\r\\n    }\\r\\n\\r\\n    function update() {\\r\\n        dispatch(\\"update\\")\\r\\n    }\\r\\n\\r\\n    function validateName() {\\r\\n        if (properties.name == \\"\\") properties.name = \\"Extension\\"\\r\\n        if (properties.name.length > 20) properties.name = properties.name.substring(0, 20)\\r\\n        properties.name = properties.name.replace(\\"\\\\n\\", \\" \\")\\r\\n        update()\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"root vert\\">\\r\\n    <div class=\\"inner horiz\\">\\r\\n        <div class=\\"vert equal\\">\\r\\n            <div class=\\"bubble\\" style:background={properties.color} />\\r\\n            <span class=\\"name\\" contenteditable=\\"plaintext-only\\" bind:innerText={properties.name} on:blur={validateName}></span>\\r\\n        </div>\\r\\n        <div class=\\"vert equal\\">\\r\\n            <span>{t(\\"id\\", $language)}: <input type=\\"text\\" placeholder=\\"extensionID\\" maxlength=\\"20\\" bind:value={properties.id} on:blur={update}></span>\\r\\n            <span>{t(\\"color\\", $language)}: <input type=\\"color\\" bind:value={properties.color} on:blur={update}></span>\\r\\n        </div>\\r\\n    </div>\\r\\n    <slot {properties} />\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .vert {\\r\\n        display: flex;\\r\\n        flex-direction: column;\\r\\n        align-items: center;\\r\\n    }\\r\\n    .horiz {\\r\\n        display: flex;\\r\\n        flex-direction: row;\\r\\n        align-items: center;\\r\\n    }\\r\\n    .equal {\\r\\n        flex: 1;\\r\\n        overflow: hidden;\\r\\n    }\\r\\n\\r\\n    .root {\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n        justify-content: center;\\r\\n    }\\r\\n    .inner {\\r\\n        width: 30em;\\r\\n    }\\r\\n\\r\\n    .bubble {\\r\\n        width: 8em;\\r\\n        aspect-ratio: 1;\\r\\n        box-sizing: border-box;\\r\\n        border: .5em solid #0004;\\r\\n        border-radius: 100%;\\r\\n    }\\r\\n\\r\\n    .name {\\r\\n        font-size: 1.2em;\\r\\n        font-weight: 500;\\r\\n        background-color: #0002;\\r\\n        padding: 0.1em 0.3em;\\r\\n        border-radius: 0.2em;\\r\\n        margin-top: 0.5em;\\r\\n        max-width: 100%;\\r\\n        box-sizing: border-box;\\r\\n        outline: none;\\r\\n    }\\r\\n    :global(.dark) .name {\\r\\n        background-color: #fff2;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAsCI,mBAAM,CACF,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MACjB,CACA,oBAAO,CACH,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,GAAG,CACnB,WAAW,CAAE,MACjB,CACA,oBAAO,CACH,IAAI,CAAE,CAAC,CACP,QAAQ,CAAE,MACd,CAEA,mBAAM,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,eAAe,CAAE,MACrB,CACA,oBAAO,CACH,KAAK,CAAE,IACX,CAEA,qBAAQ,CACJ,KAAK,CAAE,GAAG,CACV,YAAY,CAAE,CAAC,CACf,UAAU,CAAE,UAAU,CACtB,MAAM,CAAE,IAAI,CAAC,KAAK,CAAC,KAAK,CACxB,aAAa,CAAE,IACnB,CAEA,mBAAM,CACF,SAAS,CAAE,KAAK,CAChB,WAAW,CAAE,GAAG,CAChB,gBAAgB,CAAE,KAAK,CACvB,OAAO,CAAE,KAAK,CAAC,KAAK,CACpB,aAAa,CAAE,KAAK,CACpB,UAAU,CAAE,KAAK,CACjB,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,UAAU,CACtB,OAAO,CAAE,IACb,CACQ,KAAM,CAAC,mBAAM,CACjB,gBAAgB,CAAE,KACtB"}'
};
const PropertiesPicker = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  createEventDispatcher();
  let { properties = {
    name: "Extension",
    id: "extensionID",
    color: "#0fbd8c"
  } } = $$props;
  if ($$props.properties === void 0 && $$bindings.properties && properties !== void 0) $$bindings.properties(properties);
  $$result.css.add(css$4);
  $$unsubscribe_language();
  return `<div class="root vert svelte-g3hw76"><div class="inner horiz svelte-g3hw76"><div class="vert equal svelte-g3hw76"><div class="bubble svelte-g3hw76"${add_styles({ "background": properties.color })}></div> <span class="name svelte-g3hw76" contenteditable="plaintext-only">${/* @__PURE__ */ (($$value) => $$value === void 0 ? `` : $$value)(properties.name)}</span></div> <div class="vert equal svelte-g3hw76"><span>${escape(t("id", $language))}: <input type="text" placeholder="extensionID" maxlength="20"${add_attribute("value", properties.id, 0)}></span> <span>${escape(t("color", $language))}: <input type="color"${add_attribute("value", properties.color, 0)}></span></div></div> ${slots.default ? slots.default({ properties }) : ``} </div>`;
});
const css$3 = {
  code: ".vert.svelte-pqhzeu{display:flex;flex-direction:column;align-items:center}.horiz.svelte-pqhzeu{display:flex;flex-direction:row;align-items:center}.root.svelte-pqhzeu{width:100%;height:100%;justify-content:center}.inner.svelte-pqhzeu{width:50%;gap:1em}.code.svelte-pqhzeu{width:100%;height:480px}",
  map: `{"version":3,"file":"ExportMenu.svelte","sources":["ExportMenu.svelte"],"sourcesContent":["<script>\\r\\n    import beautify from \\"js-beautify\\";\\r\\n    import CodePreview from \\"$lib/CodePreview/CodePreview.svelte\\";\\r\\n    import { language, t } from \\"$lib/i18n\\";\\r\\n\\r\\n    export let code\\r\\n\\r\\n    function copyCode() {\\r\\n        navigator.clipboard.writeText(beautify.js(code, {\\r\\n            indent_size: 4,\\r\\n            space_in_empty_paren: true,\\r\\n        }))\\r\\n    }\\r\\n\\r\\n    function testCode() {\\r\\n        window.open(\\r\\n            \\"https://studio.penguinmod.com/editor?extension=\\" +\\r\\n            encodeURIComponent(\\"data:text/plain;base64,\\" + btoa(code)), '_blank'\\r\\n        ).focus();\\r\\n    }\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"root horiz\\">\\r\\n    <div class=\\"inner vert\\">\\r\\n        <div class=\\"code\\">\\r\\n            <CodePreview {code} />\\r\\n        </div>\\r\\n        <div class=\\"horiz\\">\\r\\n            <button on:click={copyCode}>{t(\\"copy\\", $language)}</button>\\r\\n            <!--<button on:click={testCode}>Test</button>-->\\r\\n        </div>\\r\\n        <b style:color=\\"red\\">{t(\\"unsandboxed\\", $language)}</b>\\r\\n    </div>\\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .vert {\\r\\n        display: flex;\\r\\n        flex-direction: column;\\r\\n        align-items: center;\\r\\n    }\\r\\n    .horiz {\\r\\n        display: flex;\\r\\n        flex-direction: row;\\r\\n        align-items: center;\\r\\n    }\\r\\n\\r\\n    .root {\\r\\n        width: 100%;\\r\\n        height: 100%;\\r\\n        justify-content: center;\\r\\n    }\\r\\n    .inner {\\r\\n        width: 50%;\\r\\n        gap: 1em;\\r\\n    }\\r\\n\\r\\n    .code {\\r\\n        width: 100%;\\r\\n        height: 480px;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AAoCI,mBAAM,CACF,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MACjB,CACA,oBAAO,CACH,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,GAAG,CACnB,WAAW,CAAE,MACjB,CAEA,mBAAM,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,IAAI,CACZ,eAAe,CAAE,MACrB,CACA,oBAAO,CACH,KAAK,CAAE,GAAG,CACV,GAAG,CAAE,GACT,CAEA,mBAAM,CACF,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,KACZ"}`
};
const ExportMenu = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  let { code } = $$props;
  if ($$props.code === void 0 && $$bindings.code && code !== void 0) $$bindings.code(code);
  $$result.css.add(css$3);
  $$unsubscribe_language();
  return `<div class="root horiz svelte-pqhzeu"><div class="inner vert svelte-pqhzeu"><div class="code svelte-pqhzeu">${validate_component(CodePreview, "CodePreview").$$render($$result, { code }, {}, {})}</div> <div class="horiz svelte-pqhzeu"><button>${escape(t("copy", $language))}</button> </div> <b${add_styles({ "color": `red` })}>${escape(t("unsandboxed", $language))}</b></div> </div>`;
});
const Plus = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%204%204'%3e%3cpath%20d='M%201.2%201.5%20l%20-0.9%200%20q%20-0.3%200%20-0.3%200.3%20l%200%200.4%20q%200%200.3%200.3%200.3%20l%200.9%20-0%20q%200.3%200%200.3%200.3%20l%200%200.9%20q%200%200.3%200.3%200.3%20l%200.4%200%20q%200.3%200%200.3%20-0.3%20l%200%20-0.9%20q%200%20-0.3%200.3%20-0.3%20l%200.9%200%20q%200.3%200%200.3%20-0.3%20l%200%20-0.4%20q%200%20-0.3%20-0.3%20-0.3%20l%20-0.9%200%20q%20-0.3%200%20-0.3%20-0.3%20l%200%20-0.9%20q%200%20-0.3%20-0.3%20-0.3%20l%20-0.4%200%20q%20-0.3%200%20-0.3%200.3%20l%200%200.9%20q%200%200.3%20-0.3%200.3%20Z'%20fill='%23000'/%3e%3c/svg%3e";
const css$2 = {
  code: "button.svelte-11rqwhs{appearance:none;border:none;background:linear-gradient(#2bf, #49f);width:100%;font-size:4em;padding:0;border-radius:0.2em;cursor:pointer;display:flex;justify-content:flex-end}button.svelte-11rqwhs:active{filter:brightness(0.8)}button.svelte-11rqwhs:focus-visible{outline:none}img.svelte-11rqwhs{opacity:0.8;width:0.7em;padding:0.1em}",
  map: `{"version":3,"file":"CreateButton.svelte","sources":["CreateButton.svelte"],"sourcesContent":["<script>\\r\\n    import Plus from '$lib/images/nav/plus.svg'\\r\\n<\/script>\\r\\n\\r\\n<button on:click>\\r\\n    <img src={Plus} alt=\\"\\" />\\r\\n</button>\\r\\n\\r\\n<style>\\r\\n    button {\\r\\n        appearance: none;\\r\\n        border: none;\\r\\n        background: linear-gradient(#2bf, #49f);\\r\\n        width: 100%;\\r\\n        font-size: 4em;\\r\\n        padding: 0;\\r\\n        border-radius: 0.2em;\\r\\n        cursor: pointer;\\r\\n        display: flex;\\r\\n        justify-content: flex-end;\\r\\n    }\\r\\n    button:active {\\r\\n        filter: brightness(0.8);\\r\\n    }\\r\\n    button:focus-visible {\\r\\n        outline: none;\\r\\n    }\\r\\n\\r\\n    img {\\r\\n        opacity: 0.8;\\r\\n        width: 0.7em;\\r\\n        padding: 0.1em;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AASI,qBAAO,CACH,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,gBAAgB,IAAI,CAAC,CAAC,IAAI,CAAC,CACvC,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,GAAG,CACd,OAAO,CAAE,CAAC,CACV,aAAa,CAAE,KAAK,CACpB,MAAM,CAAE,OAAO,CACf,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,QACrB,CACA,qBAAM,OAAQ,CACV,MAAM,CAAE,WAAW,GAAG,CAC1B,CACA,qBAAM,cAAe,CACjB,OAAO,CAAE,IACb,CAEA,kBAAI,CACA,OAAO,CAAE,GAAG,CACZ,KAAK,CAAE,KAAK,CACZ,OAAO,CAAE,KACb"}`
};
const CreateButton = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css$2);
  return `<button class="svelte-11rqwhs" data-svelte-h="svelte-br9lzk"><img${add_attribute("src", Plus, 0)} alt="" class="svelte-11rqwhs"> </button>`;
});
const css$1 = {
  code: ".main.svelte-1db10zy.svelte-1db10zy{padding:16px;display:flex;width:min(calc(100vw - 32px), 1024px);flex-direction:column;align-items:center;margin:auto;gap:0.5em}.block.svelte-1db10zy.svelte-1db10zy{background:#8884;width:100%;height:4em;display:flex;align-items:center;justify-content:space-between;border-radius:0.8em;box-sizing:border-box;padding:8px}.block.svelte-1db10zy button.svelte-1db10zy{appearance:none;border:none;background:#4bf;width:100%;font-size:1rem;padding:0.4rem 1rem;border-radius:0.2em;cursor:pointer;display:flex;justify-content:flex-end;font-weight:bold}.buttons-block.svelte-1db10zy.svelte-1db10zy{display:flex;gap:0.5em;flex-direction:row}",
  map: '{"version":3,"file":"BlocksMenu.svelte","sources":["BlocksMenu.svelte"],"sourcesContent":["<script>\\r\\n    import util from \\"../../resources/util\\";\\r\\n    import CreateButton from \\"./CreateButton.svelte\\";\\r\\n    import Blockly from \\"blockly/core\\";\\r\\n    import { language, t } from \\"$lib/i18n\\";\\r\\n\\r\\n    function updateBlocks() {\\r\\n        blocks = window.blocks\\r\\n        window.blocks = blocks\\r\\n\\r\\n        //refresh workspace\\r\\n        try {\\r\\n            let workspace = window.workspace\\r\\n            let xml = Blockly.Xml.workspaceToDom(workspace);\\r\\n            workspace.clear();\\r\\n            Blockly.Xml.domToWorkspace(xml, workspace);\\r\\n            this.refreshToolboxSelection();\\r\\n        } catch {}\\r\\n    }\\r\\n\\r\\n    function createBlock() {\\r\\n        if (!confirm(t(\\"createBlockConfirmation\\", $language))) return\\r\\n\\r\\n        let id = util.randomHex(16)\\r\\n        let block = {\\r\\n            type: \\"command\\",\\r\\n            fields: [\\r\\n                {\\r\\n                    type: \\"label\\",\\r\\n                    text: \\"block\\",\\r\\n                    id: util.randomHex(16)\\r\\n                }\\r\\n            ]\\r\\n        }\\r\\n        window.blocks[id] = block\\r\\n\\r\\n        let workspace = window.workspace\\r\\n        /** @type {Blockly.BlockSvg} */\\r\\n        let defineBlock = workspace.newBlock(\\"blocks_define\\")\\r\\n        defineBlock.setDeletable(false)\\r\\n        defineBlock.blockId_ = id\\r\\n        defineBlock.updateShape_()\\r\\n        defineBlock.initSvg()\\r\\n        defineBlock.render()\\r\\n\\r\\n        updateBlocks()\\r\\n    }\\r\\n\\r\\n    function deleteBlock(id) {\\r\\n        if (!confirm(t(\\"deleteBlockConfirmation\\", $language))) return\\r\\n\\r\\n        let workspace = window.workspace\\r\\n        let block = workspace.getAllBlocks().find(b => b.blockId_ === id)\\r\\n        if (block) {\\r\\n            block.dispose()\\r\\n        }\\r\\n        delete window.blocks[id]\\r\\n\\r\\n        updateBlocks()\\r\\n    }\\r\\n    function editBlock(id) {\\r\\n        window.modals[\\"editblock\\"].blockId = id\\r\\n        window.modals[\\"editblock\\"].tempBlock = window.blocks[id]\\r\\n        window.modals[\\"editblock\\"].toggle()\\r\\n    }\\r\\n\\r\\n    setInterval(() => {\\r\\n        if (!globalThis.window) return\\r\\n        blocks = window.blocks\\r\\n        window.blocks = blocks\\r\\n    }, 1000)\\r\\n\\r\\n    let blocks = {}\\r\\n<\/script>\\r\\n\\r\\n<div class=\\"main\\">\\r\\n    <CreateButton on:click={createBlock} />\\r\\n    {#each Object.entries(blocks) as [id, block]}\\r\\n        <div class=\\"block\\">\\r\\n            <span class=\\"name\\">{util.blockToName(block.fields)}</span>\\r\\n            <div class=\\"buttons-block\\">\\r\\n                <button class=\\"edit\\" on:click={() => editBlock(id)}>{t(\\"editBlock\\", $language)}</button>\\r\\n                <button class=\\"delete\\" on:click={() => deleteBlock(id)}>{t(\\"delete\\", $language)}</button>\\r\\n            </div>\\r\\n        </div>\\r\\n    {:else}\\r\\n        <p>{t(\\"noBlocks\\", $language)}</p>\\r\\n    {/each}    \\r\\n</div>\\r\\n\\r\\n<style>\\r\\n    .main {\\r\\n        padding: 16px;\\r\\n        display: flex;\\r\\n        width: min(calc(100vw - 32px), 1024px);\\r\\n        flex-direction: column;\\r\\n        align-items: center;\\r\\n        margin: auto;\\r\\n        gap: 0.5em;\\r\\n    }\\r\\n\\r\\n    .block {\\r\\n        background: #8884;\\r\\n        width: 100%;\\r\\n        height: 4em;\\r\\n        display: flex;\\r\\n        align-items: center;\\r\\n        justify-content: space-between;\\r\\n        border-radius: 0.8em;\\r\\n        box-sizing: border-box;\\r\\n        padding: 8px;\\r\\n    }\\r\\n\\r\\n    .block button {\\r\\n        appearance: none;\\r\\n        border: none;\\r\\n        background: #4bf;\\r\\n        width: 100%;\\r\\n        font-size: 1rem;\\r\\n        padding: 0.4rem 1rem;\\r\\n        border-radius: 0.2em;\\r\\n        cursor: pointer;\\r\\n        display: flex;\\r\\n        justify-content: flex-end;\\r\\n        font-weight: bold;\\r\\n    }\\r\\n    .buttons-block {\\r\\n        display: flex;\\r\\n        gap: 0.5em;\\r\\n        flex-direction: row;\\r\\n    }\\r\\n</style>"],"names":[],"mappings":"AA2FI,mCAAM,CACF,OAAO,CAAE,IAAI,CACb,OAAO,CAAE,IAAI,CACb,KAAK,CAAE,IAAI,KAAK,KAAK,CAAC,CAAC,CAAC,IAAI,CAAC,CAAC,CAAC,MAAM,CAAC,CACtC,cAAc,CAAE,MAAM,CACtB,WAAW,CAAE,MAAM,CACnB,MAAM,CAAE,IAAI,CACZ,GAAG,CAAE,KACT,CAEA,oCAAO,CACH,UAAU,CAAE,KAAK,CACjB,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,GAAG,CACX,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,eAAe,CAAE,aAAa,CAC9B,aAAa,CAAE,KAAK,CACpB,UAAU,CAAE,UAAU,CACtB,OAAO,CAAE,GACb,CAEA,qBAAM,CAAC,qBAAO,CACV,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,IAAI,CACZ,UAAU,CAAE,IAAI,CAChB,KAAK,CAAE,IAAI,CACX,SAAS,CAAE,IAAI,CACf,OAAO,CAAE,MAAM,CAAC,IAAI,CACpB,aAAa,CAAE,KAAK,CACpB,MAAM,CAAE,OAAO,CACf,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,QAAQ,CACzB,WAAW,CAAE,IACjB,CACA,4CAAe,CACX,OAAO,CAAE,IAAI,CACb,GAAG,CAAE,KAAK,CACV,cAAc,CAAE,GACpB"}'
};
const BlocksMenu = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  setInterval(
    () => {
      if (!globalThis.window) return;
      blocks2 = window.blocks;
      window.blocks = blocks2;
    },
    1e3
  );
  let blocks2 = {};
  $$result.css.add(css$1);
  $$unsubscribe_language();
  return `<div class="main svelte-1db10zy">${validate_component(CreateButton, "CreateButton").$$render($$result, {}, {}, {})} ${Object.entries(blocks2).length ? each(Object.entries(blocks2), ([id2, block]) => {
    return `<div class="block svelte-1db10zy"><span class="name">${escape(util.blockToName(block.fields))}</span> <div class="buttons-block svelte-1db10zy"><button class="edit svelte-1db10zy">${escape(t("editBlock", $language))}</button> <button class="delete svelte-1db10zy">${escape(t("delete", $language))}</button></div> </div>`;
  }) : `<p>${escape(t("noBlocks", $language))}</p>`} </div>`;
});
Blockly.Block.prototype.getField = function(name) {
  if (typeof name !== "string") {
    throw new TypeError(
      "Block.prototype.getField expects a string with the field name but received " + (name === void 0 ? "nothing" : name + " of type " + typeof name) + " instead"
    );
  }
  for (let i = 0, input; input = this.inputList[i]; i++) {
    if (input.fieldName === name && input.getTargetBlockType() === input.getConnectedBlock().type) {
      return input.getTargetField();
    }
    for (let j = 0, field; field = input.fieldRow[j]; j++) {
      if (field.name === name) {
        return field;
      }
    }
  }
  return null;
};
Blockly.Block.prototype.getFieldInput = function(name) {
  for (let i = 0, input; input = this.inputList[i]; i++) {
    if (input.fieldName === name) {
      return input;
    }
  }
  return null;
};
Blockly.Input.prototype.getTargetField = function() {
  if (!this.fieldName) return null;
  return this.connection.targetConnection.sourceBlock_.inputList[0].fieldRow[0];
};
Blockly.Input.prototype.getConnectedBlock = function() {
  return this.connection.targetConnection.sourceBlock_;
};
Blockly.Input.prototype.getTargetBlockType = function() {
  if (!this.fieldName) return null;
  return `${this.getSourceBlock()}_${this.fieldName}`;
};
const convertArgToBlock = (arg, color, name, block) => {
  if (!arg.acceptsBlocks) return arg;
  switch (arg.type) {
    case "field_angle":
    case "field_input":
    case "field_number":
    case "field_dropdown": {
      color = "#fff";
      const newBlockName = `${name}_${arg.name}`;
      Blockly.Blocks[newBlockName] = {
        init: function() {
          this.jsonInit({
            message0: "%1",
            args0: [arg],
            output: arg.check,
            inputsInline: true,
            colour: color
          });
        }
      };
      javascriptGenerator[newBlockName] = (block2) => {
        const value = block2.getFieldValue(arg.name);
        return [JSON.stringify(value), javascriptGenerator.ORDER_NONE];
      };
      const oldInit = block.init;
      block.init = function() {
        oldInit.apply(this);
        const input = this.getInput(arg.name);
        input.fieldName = arg.name;
        const newBlock = this.workspace.newBlock(newBlockName);
        const blockConnection = newBlock.outputConnection;
        newBlock.setShadow(true);
        newBlock.initSvg();
        newBlock.render();
        blockConnection.connect(input.connection);
      };
      return {
        type: "input_value",
        name: arg.name,
        check: arg.check
      };
    }
    default:
      return arg;
  }
};
function registerBlock(blockName, jsonData, compileFunction, language2 = getLanguage()) {
  const localizedJsonData = translateBlockJson(
    JSON.parse(JSON.stringify(jsonData)),
    language2
  );
  localizedJsonData.type = blockName;
  const blockObject = {
    init: function() {
      this.jsonInit(localizedJsonData);
    },
    order: localizedJsonData.order || 0,
    //custom block ordering system
    isDual: function() {
      return this.outputConnection && (this.previousConnection || this.nextConnection);
    }
  };
  for (let message = 0; localizedJsonData[`message${message}`]; message++) {
    if (localizedJsonData[`args${message}`]) {
      const args = localizedJsonData[`args${message}`];
      for (let idx = 0, arg; arg = args[idx]; idx++)
        args[idx] = convertArgToBlock(arg, localizedJsonData.colour, blockName, blockObject);
    }
  }
  Blockly.Blocks[blockName] = blockObject;
  javascriptGenerator[blockName] = compileFunction;
}
function registerMutator(mutatorName, ...args) {
  Blockly.Extensions.unregister(mutatorName);
  Blockly.Extensions.registerMutator(mutatorName, ...args);
}
const categoryPrefix$e = "generic_";
const categoryColor$e = "#fff";
function register$f() {
  registerBlock(`${categoryPrefix$e}number`, {
    message0: "%1",
    args0: [
      {
        "type": "field_number",
        "name": "NUMBER",
        "value": 0
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$e
  }, (block) => {
    const NUMBER = block.getFieldValue("NUMBER");
    const code = `Number(${NUMBER})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$e}text`, {
    message0: "%1",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "text": ""
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$e
  }, (block) => {
    const TEXT = block.getFieldValue("TEXT");
    const code = `String(${JSON.stringify(TEXT)})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$e}any`, {
    message0: "%1",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "text": ""
      }
    ],
    output: ["String", "Number"],
    inputsInline: true,
    colour: categoryColor$e
  }, (block) => {
    const TEXT = block.getFieldValue("TEXT");
    const code = `String(${JSON.stringify(TEXT)})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$e}boolean`, {
    message0: "%1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "STATE",
        "options": [
          ["true", "true"],
          ["false", "false"],
          ["random", "Boolean(Math.round(Math.random()))"]
        ]
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$e
  }, (block) => {
    const code = block.getFieldValue("STATE");
    return [code, 0];
  });
}
const categoryPrefix$d = "events_";
const categoryColor$d = "#fc6";
const TARGET$3 = `(Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage))`;
function register$e() {
  registerBlock(`${categoryPrefix$d}loaded`, {
    message0: "when extension loaded %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    colour: categoryColor$d
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(async () => { ${BLOCKS} })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}thread`, {
    message0: "new thread %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$d
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(async () => { ${BLOCKS} })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}regbroadcast`, {
    message0: "when %1 broadcasted %2 %3",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "text": "broadcast1",
        "acceptsBlocks": true,
        "check": "String"
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 2,
    colour: categoryColor$d
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `CapivaraModBuilder.Broadcasts.register(${NAME}, (async () => { ${BLOCKS} })());`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}broadcast`, {
    message0: "broadcast %1",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "text": "broadcast1",
        "acceptsBlocks": true,
        "check": "String"
      }
    ],
    inputsInline: true,
    previousStatement: null,
    nextStatement: null,
    colour: categoryColor$d
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `CapivaraModBuilder.Broadcasts.execute(${NAME});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}broadcastw`, {
    message0: "broadcast %1 and wait",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "text": "broadcast1",
        "acceptsBlocks": true,
        "check": "String"
      }
    ],
    inputsInline: true,
    previousStatement: null,
    nextStatement: null,
    colour: categoryColor$d
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `await CapivaraModBuilder.Broadcasts.execute(${NAME});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whenflagclicked`, {
    message0: "when green flag clicked %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.on('PROJECT_RUN_START', (async () => { ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whenkeypressed`, {
    message0: "when %1 key pressed %2 %3",
    args0: [
      {
        "type": "field_input",
        "name": "KEY",
        "text": "space",
        "check": "String",
        "acceptsBlocks": true
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const KEY = javascriptGenerator.valueToCode(block, "KEY");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.runtime.on('KEY_PRESSED', (async (key) => { if (key !== ${KEY}) return; ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whenspriteclicked`, {
    message0: "when this sprite clicked %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(() => { const t = ${TARGET$3}; Scratch.vm.runtime.on('targetWasClicked', (async (clicked) => { if (clicked !== t) return; ${BLOCKS} })); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whenbackdropswitches`, {
    message0: "when backdrop switches to %1 %2 %3",
    args0: [
      {
        "type": "field_input",
        "name": "BACKDROP",
        "text": "backdrop1",
        "check": "String",
        "acceptsBlocks": true
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const BACKDROP = javascriptGenerator.valueToCode(block, "BACKDROP");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.runtime.on('EVENT_STAGE_SWITCH_BACKDROP', (async (backdrop) => { if (!backdrop || backdrop.name !== ${BACKDROP}) return; ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whengreaterthan`, {
    message0: "when %1 > %2 %3",
    args0: [
      {
        "type": "field_dropdown",
        "name": "TYPE",
        "options": [
          ["timer", "timer"],
          ["loudness", "loudness"]
        ]
      },
      {
        "type": "field_number",
        "name": "VALUE",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const TYPE = block.getFieldValue("TYPE");
    const VALUE = javascriptGenerator.valueToCode(block, "VALUE");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const getter = TYPE === "timer" ? `Scratch.vm.runtime.ioDevices.clock.projectTimer()` : `(Scratch.vm.runtime.audioEngine && Scratch.vm.runtime.audioEngine.getLoudness ? Scratch.vm.runtime.audioEngine.getLoudness() : -1)`;
    const code = `(() => { let fired = false; Scratch.vm.runtime.on('BEFORE_EXECUTE', (async () => { const over = ${getter} > ${VALUE}; if (over && !fired) { fired = true; ${BLOCKS} } else if (!over) { fired = false; } })); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$d}whenclonestarts`, {
    message0: "when I start as a clone %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$d
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(() => { const t = ${TARGET$3}; Scratch.vm.runtime.on('targetWasCreated', (async (newTarget, original) => { if (original !== t) return; ${BLOCKS} })); })();`;
    return `${code}
`;
  });
}
const categoryPrefix$c = "motion_";
const categoryColor$c = "#4c97ff";
const TARGET$2 = `(Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage))`;
const MOUSE_POINT = `[Scratch.vm.runtime.ioDevices.mouse.getScratchX(), Scratch.vm.runtime.ioDevices.mouse.getScratchY()]`;
const RANDOM_POINT = `[Math.round(Scratch.vm.runtime.stageWidth * (Math.random() - 0.5)), Math.round(Scratch.vm.runtime.stageHeight * (Math.random() - 0.5))]`;
function pointFor(choice) {
  return choice === "mouse" ? MOUSE_POINT : RANDOM_POINT;
}
function numberField$2(name, value) {
  return {
    "type": "field_number",
    "name": name,
    "check": "Number",
    "value": value,
    "acceptsBlocks": true
  };
}
function targetDropdown(options) {
  return {
    "type": "field_dropdown",
    "name": "TARGET",
    "options": options
  };
}
function register$d() {
  registerBlock(`${categoryPrefix$c}move`, {
    message0: "move %1 steps",
    args0: [numberField$2("STEPS", 10)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const STEPS = javascriptGenerator.valueToCode(block, "STEPS");
    const code = `(() => { const t = ${TARGET$2}; const r = (90 - t.direction) * Math.PI / 180; t.setXY(t.x + ${STEPS} * Math.cos(r), t.y + ${STEPS} * Math.sin(r)); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}turnright`, {
    message0: "turn right %1 degrees",
    args0: [numberField$2("DEGREES", 15)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const DEGREES = javascriptGenerator.valueToCode(block, "DEGREES");
    const code = `(() => { const t = ${TARGET$2}; t.setDirection(t.direction + ${DEGREES}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}turnleft`, {
    message0: "turn left %1 degrees",
    args0: [numberField$2("DEGREES", 15)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const DEGREES = javascriptGenerator.valueToCode(block, "DEGREES");
    const code = `(() => { const t = ${TARGET$2}; t.setDirection(t.direction - ${DEGREES}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}goto`, {
    message0: "go to x: %1 y: %2",
    args0: [numberField$2("X", 0), numberField$2("Y", 0)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `${TARGET$2}.setXY(${X}, ${Y});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}gototarget`, {
    message0: "go to %1",
    args0: [
      targetDropdown([
        ["random position", "random"],
        ["mouse pointer", "mouse"]
      ])
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const TARGET_CHOICE = block.getFieldValue("TARGET");
    const code = `(() => { const p = ${pointFor(TARGET_CHOICE)}; ${TARGET$2}.setXY(p[0], p[1]); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}glide`, {
    message0: "glide %1 secs to x: %2 y: %3",
    args0: [numberField$2("SECS", 1), numberField$2("X", 0), numberField$2("Y", 0)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const SECS = javascriptGenerator.valueToCode(block, "SECS");
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `await new Promise(done => { const t = ${TARGET$2}; const sx = t.x; const sy = t.y; const ex = ${X}; const ey = ${Y}; const dur = ${SECS} * 1000; const start = performance.now(); const step = () => { const f = dur > 0 ? Math.min((performance.now() - start) / dur, 1) : 1; t.setXY(sx + (ex - sx) * f, sy + (ey - sy) * f); if (f < 1) { requestAnimationFrame(step); } else { done(); } }; step(); });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}glidetarget`, {
    message0: "glide %1 secs to %2",
    args0: [
      numberField$2("SECS", 1),
      targetDropdown([
        ["random position", "random"],
        ["mouse pointer", "mouse"]
      ])
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const SECS = javascriptGenerator.valueToCode(block, "SECS");
    const TARGET_CHOICE = block.getFieldValue("TARGET");
    const code = `await new Promise(done => { const t = ${TARGET$2}; const p = ${pointFor(TARGET_CHOICE)}; const sx = t.x; const sy = t.y; const dur = ${SECS} * 1000; const start = performance.now(); const step = () => { const f = dur > 0 ? Math.min((performance.now() - start) / dur, 1) : 1; t.setXY(sx + (p[0] - sx) * f, sy + (p[1] - sy) * f); if (f < 1) { requestAnimationFrame(step); } else { done(); } }; step(); });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}pointdirection`, {
    message0: "point in direction %1",
    args0: [numberField$2("DIRECTION", 90)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const DIRECTION = javascriptGenerator.valueToCode(block, "DIRECTION");
    const code = `${TARGET$2}.setDirection(${DIRECTION});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}pointtowards`, {
    message0: "point towards %1",
    args0: [
      targetDropdown([
        ["mouse pointer", "mouse"],
        ["random direction", "random"]
      ])
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const TARGET_CHOICE = block.getFieldValue("TARGET");
    let code;
    if (TARGET_CHOICE === "mouse") {
      code = `(() => { const t = ${TARGET$2}; const p = ${MOUSE_POINT}; t.setDirection(90 - Math.atan2(p[1] - t.y, p[0] - t.x) * 180 / Math.PI); })();`;
    } else {
      code = `${TARGET$2}.setDirection(Math.round(Math.random() * 360) - 180);`;
    }
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}changex`, {
    message0: "change x by %1",
    args0: [numberField$2("DX", 10)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const DX = javascriptGenerator.valueToCode(block, "DX");
    const code = `(() => { const t = ${TARGET$2}; t.setXY(t.x + ${DX}, t.y); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}setx`, {
    message0: "set x to %1",
    args0: [numberField$2("X", 0)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const code = `(() => { const t = ${TARGET$2}; t.setXY(${X}, t.y); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}changey`, {
    message0: "change y by %1",
    args0: [numberField$2("DY", 10)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const DY = javascriptGenerator.valueToCode(block, "DY");
    const code = `(() => { const t = ${TARGET$2}; t.setXY(t.x, t.y + ${DY}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}sety`, {
    message0: "set y to %1",
    args0: [numberField$2("Y", 0)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(() => { const t = ${TARGET$2}; t.setXY(t.x, ${Y}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}bounce`, {
    message0: "if on edge, bounce",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const code = `(() => { const t = ${TARGET$2}; const rt = Scratch.vm.runtime; const b = t.getBounds(); if (!b) return; const dl = Math.max(0, rt.stageWidth / 2 + b.left); const dt = Math.max(0, rt.stageHeight / 2 - b.top); const dr = Math.max(0, rt.stageWidth / 2 - b.right); const db = Math.max(0, rt.stageHeight / 2 + b.bottom); const m = Math.min(dl, dt, dr, db); if (m > 0) return; const r = (90 - t.direction) * Math.PI / 180; let dx = Math.cos(r); let dy = -Math.sin(r); if (m === dl) { dx = Math.max(0.2, Math.abs(dx)); } else if (m === dt) { dy = Math.max(0.2, Math.abs(dy)); } else if (m === dr) { dx = -Math.max(0.2, Math.abs(dx)); } else { dy = -Math.max(0.2, Math.abs(dy)); } t.setDirection(Math.atan2(dy, dx) * 180 / Math.PI + 90); t.keepInFence(t.x, t.y); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}rotationstyle`, {
    message0: "set rotation style %1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "STYLE",
        "options": [
          ["left-right", "left-right"],
          ["don't rotate", "don't rotate"],
          ["all around", "all around"]
        ]
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const STYLE = block.getFieldValue("STYLE");
    const code = `${TARGET$2}.setRotationStyle(${JSON.stringify(STYLE)});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$c}xposition`, {
    message0: "x position",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const code = `Number(${TARGET$2}.x.toFixed(2))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$c}yposition`, {
    message0: "y position",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const code = `Number(${TARGET$2}.y.toFixed(2))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$c}direction`, {
    message0: "direction",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$c
  }, (block) => {
    const code = `${TARGET$2}.direction`;
    return [`${code}`, 0];
  });
}
const categoryPrefix$b = "looks_";
const categoryColor$b = "#9966ff";
const TARGET$1 = `(Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage))`;
const STAGE = `Scratch.vm.runtime.getTargetForStage()`;
const LOOKS = `Scratch.vm.runtime.ext_scratch3_looks`;
const effects = [
  ["color", "color"],
  ["fisheye", "fisheye"],
  ["whirl", "whirl"],
  ["pixelate", "pixelate"],
  ["mosaic", "mosaic"],
  ["brightness", "brightness"],
  ["ghost", "ghost"]
];
function numberField$1(name, value) {
  return {
    "type": "field_number",
    "name": name,
    "check": "Number",
    "value": value,
    "acceptsBlocks": true
  };
}
function textField$2(name, text) {
  return {
    "type": "field_input",
    "name": name,
    "check": null,
    "text": text,
    "acceptsBlocks": true
  };
}
function register$c() {
  registerBlock(`${categoryPrefix$b}say`, {
    message0: "say %1",
    args0: [textField$2("MESSAGE", "Hello!")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const MESSAGE = javascriptGenerator.valueToCode(block, "MESSAGE");
    const code = `${LOOKS}.say({ MESSAGE: ${MESSAGE} }, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}sayfor`, {
    message0: "say %1 for %2 seconds",
    args0: [textField$2("MESSAGE", "Hello!"), numberField$1("SECS", 2)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const MESSAGE = javascriptGenerator.valueToCode(block, "MESSAGE");
    const SECS = javascriptGenerator.valueToCode(block, "SECS");
    const code = `await ${LOOKS}.sayforsecs({ MESSAGE: ${MESSAGE}, SECS: ${SECS} }, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}think`, {
    message0: "think %1",
    args0: [textField$2("MESSAGE", "Hmm...")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const MESSAGE = javascriptGenerator.valueToCode(block, "MESSAGE");
    const code = `${LOOKS}.think({ MESSAGE: ${MESSAGE} }, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}thinkfor`, {
    message0: "think %1 for %2 seconds",
    args0: [textField$2("MESSAGE", "Hmm..."), numberField$1("SECS", 2)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const MESSAGE = javascriptGenerator.valueToCode(block, "MESSAGE");
    const SECS = javascriptGenerator.valueToCode(block, "SECS");
    const code = `await ${LOOKS}.thinkforsecs({ MESSAGE: ${MESSAGE}, SECS: ${SECS} }, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}switchcostume`, {
    message0: "switch costume to %1",
    args0: [textField$2("COSTUME", "costume1")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const COSTUME = javascriptGenerator.valueToCode(block, "COSTUME");
    const code = `${LOOKS}.switchCostume({ COSTUME: ${COSTUME} }, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}nextcostume`, {
    message0: "next costume",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `${LOOKS}.nextCostume({}, { target: ${TARGET$1} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}switchbackdrop`, {
    message0: "switch backdrop to %1",
    args0: [textField$2("BACKDROP", "backdrop1")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const BACKDROP = javascriptGenerator.valueToCode(block, "BACKDROP");
    const code = `${LOOKS}.switchBackdrop({ BACKDROP: ${BACKDROP} }, { target: ${STAGE} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}nextbackdrop`, {
    message0: "next backdrop",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `${LOOKS}.nextBackdrop({}, { target: ${STAGE} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}changesize`, {
    message0: "change size by %1",
    args0: [numberField$1("CHANGE", 10)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const CHANGE = javascriptGenerator.valueToCode(block, "CHANGE");
    const code = `(() => { const t = ${TARGET$1}; t.setSize(t.size + ${CHANGE}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}setsize`, {
    message0: "set size to %1 %%",
    args0: [numberField$1("SIZE", 100)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const SIZE = javascriptGenerator.valueToCode(block, "SIZE");
    const code = `${TARGET$1}.setSize(${SIZE});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}changeeffect`, {
    message0: "change %1 effect by %2",
    args0: [
      {
        "type": "field_dropdown",
        "name": "EFFECT",
        "options": effects
      },
      numberField$1("CHANGE", 25)
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const EFFECT = block.getFieldValue("EFFECT");
    const CHANGE = javascriptGenerator.valueToCode(block, "CHANGE");
    const code = `(() => { const t = ${TARGET$1}; t.setEffect("${EFFECT}", (t.effects["${EFFECT}"] || 0) + ${CHANGE}); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}seteffect`, {
    message0: "set %1 effect to %2",
    args0: [
      {
        "type": "field_dropdown",
        "name": "EFFECT",
        "options": effects
      },
      numberField$1("VALUE", 0)
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const EFFECT = block.getFieldValue("EFFECT");
    const VALUE = javascriptGenerator.valueToCode(block, "VALUE");
    const code = `${TARGET$1}.setEffect("${EFFECT}", ${VALUE});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}cleareffects`, {
    message0: "clear graphic effects",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `${TARGET$1}.clearEffects();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}show`, {
    message0: "show",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `${TARGET$1}.setVisible(true);`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}hide`, {
    message0: "hide",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `${TARGET$1}.setVisible(false);`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}gotolayer`, {
    message0: "go to %1 layer",
    args0: [
      {
        "type": "field_dropdown",
        "name": "LAYER",
        "options": [
          ["front", "goToFront"],
          ["back", "goToBack"]
        ]
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const LAYER = block.getFieldValue("LAYER");
    const code = `${TARGET$1}.${LAYER}();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}golayers`, {
    message0: "go %1 %2 layers",
    args0: [
      {
        "type": "field_dropdown",
        "name": "DIRECTION",
        "options": [
          ["forward", "goForwardLayers"],
          ["backward", "goBackwardLayers"]
        ]
      },
      numberField$1("NUM", 1)
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const DIRECTION = block.getFieldValue("DIRECTION");
    const NUM = javascriptGenerator.valueToCode(block, "NUM");
    const code = `${TARGET$1}.${DIRECTION}(${NUM});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$b}costumenumber`, {
    message0: "costume number",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `(${TARGET$1}.currentCostume + 1)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$b}costumename`, {
    message0: "costume name",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `(() => { const t = ${TARGET$1}; return t.getCostumes()[t.currentCostume].name; })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$b}backdropnumber`, {
    message0: "backdrop number",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `(${STAGE}.currentCostume + 1)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$b}backdropname`, {
    message0: "backdrop name",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `(() => { const s = ${STAGE}; return s.getCostumes()[s.currentCostume].name; })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$b}size`, {
    message0: "size",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$b
  }, (block) => {
    const code = `Math.round(${TARGET$1}.size)`;
    return [`${code}`, 0];
  });
}
const categoryPrefix$a = "control_";
const categoryColor$a = "#fb6";
function register$b() {
  registerBlock(`${categoryPrefix$a}if`, {
    message0: "if %1 then %2 %3",
    args0: [
      {
        "type": "input_value",
        "name": "BOOL0",
        "check": "Boolean"
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS0"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a,
    mutator: `${categoryPrefix$a}if_mutator`
  }, (block) => {
    const BOOL0 = javascriptGenerator.valueToCode(block, "BOOL0") || "false";
    const BLOCKS0 = javascriptGenerator.statementToCode(block, "BLOCKS0");
    let code = `if (${BOOL0}) { ${BLOCKS0} }`;
    for (let i = 1; block.getInput(`BOOL${i}`); i++) {
      const BOOLx = javascriptGenerator.valueToCode(block, `BOOL${i}`) || "false";
      const BLOCKSx = javascriptGenerator.statementToCode(block, `BLOCKS${i}`);
      code += ` else if (${BOOLx}) { ${BLOCKSx} }`;
    }
    if (block.getInput("ELSE")) {
      const ELSE = javascriptGenerator.statementToCode(block, "ELSE");
      code += ` else { ${ELSE} }`;
    }
    code += ";";
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}if_mutator_if`, {
    message0: "if",
    args0: [],
    nextStatement: null,
    inputsInline: true,
    enableContextMenu: false,
    colour: categoryColor$a
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$a}if_mutator_elseif`, {
    message0: "else if",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$a}if_mutator_else`, {
    message0: "else",
    args0: [],
    previousStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$a}wait`, {
    message0: "wait %1 seconds",
    args0: [
      {
        "type": "field_number",
        "name": "TIME",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const TIME = javascriptGenerator.valueToCode(block, "TIME");
    const code = `await new Promise(resolve => setTimeout(() => resolve(), ${TIME} * 1000));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}waitF`, {
    message0: "wait until next frame",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const v = "temp_" + util.randomHex(24);
    const code = `await new Promise(${v} => { requestAnimationFrame(() => { ${v}() }) })`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}waitU`, {
    message0: "wait until %1",
    args0: [
      {
        "type": "input_value",
        "name": "BOOL",
        "check": "Boolean"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    javascriptGenerator.valueToCode(block, "BOOL");
    const v1 = "temp_" + util.randomHex(24);
    const v2 = "temp_" + util.randomHex(24);
    const code = `await new Promise(${v1} => {let ${v2} = () => false ? ${v1}() : requestAnimationFrame(${v2}); ${v2}()})`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}while`, {
    message0: "while %1 do %2 %3",
    args0: [
      {
        "type": "input_value",
        "name": "BOOL",
        "check": "Boolean"
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const BOOL = javascriptGenerator.valueToCode(block, "BOOL") || "false";
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `while (${BOOL}) { ${BLOCKS} };`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}repeat`, {
    message0: "repeat %1 %2 %3",
    args0: [
      {
        "type": "field_number",
        "name": "AMT",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const AMT = javascriptGenerator.valueToCode(block, "AMT");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const varName = "temp_" + util.randomHex(24);
    const code = `for (var ${varName} = 0; ${varName} < ${AMT}; ${varName}++) { ${BLOCKS} };`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}return`, {
    message0: "return %1",
    args0: [
      {
        "type": "field_input",
        "name": "OUTPUT",
        "check": null,
        "text": "",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const OUTPUT = javascriptGenerator.valueToCode(block, "OUTPUT");
    const code = `return ${OUTPUT};`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$a}inline`, {
    message0: "inline %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    output: null,
    inputsInline: true,
    colour: categoryColor$a
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(async () => { ${BLOCKS} return null; })();`;
    return [`${code}`, 0];
  });
  const control_if_mutator = {
    elseifCount_: 0,
    elseCount_: 0,
    mutationToDom: function() {
      if (!this.elseifCount_ && !this.elseCount_) {
        return null;
      }
      const container = Blockly.utils.xml.createElement("mutation");
      if (this.elseifCount_) {
        container.setAttribute("elseif", String(this.elseifCount_));
      }
      if (this.elseCount_) {
        container.setAttribute("else", "1");
      }
      return container;
    },
    domToMutation: function(xmlElement) {
      this.elseifCount_ = parseInt(xmlElement.getAttribute("elseif"));
      this.elseCount_ = parseInt(xmlElement.getAttribute("else"));
      this.rebuildShape_();
    },
    decompose: function(workspace) {
      const containerBlock = workspace.newBlock(`${categoryPrefix$a}if_mutator_if`);
      containerBlock.initSvg();
      let connection = containerBlock.nextConnection;
      for (let i = 1; i <= this.elseifCount_; i++) {
        const elseifBlock = workspace.newBlock(`${categoryPrefix$a}if_mutator_elseif`);
        elseifBlock.initSvg();
        connection.connect(elseifBlock.previousConnection);
        connection = elseifBlock.nextConnection;
      }
      if (this.elseCount_) {
        const elseBlock = workspace.newBlock(`${categoryPrefix$a}if_mutator_else`);
        elseBlock.initSvg();
        connection.connect(elseBlock.previousConnection);
      }
      return containerBlock;
    },
    compose: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      this.elseifCount_ = 0;
      this.elseCount_ = 0;
      const valueConnections = [null];
      const statementConnections = [null];
      let elseStatementConnection = null;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        switch (clauseBlock.type) {
          case `${categoryPrefix$a}if_mutator_elseif`:
            this.elseifCount_++;
            valueConnections.push(clauseBlock.valueConnection_);
            statementConnections.push(clauseBlock.statementConnection_);
            break;
          case `${categoryPrefix$a}if_mutator_else`:
            this.elseCount_++;
            elseStatementConnection = clauseBlock.statementConnection_;
            break;
        }
        clauseBlock = clauseBlock.getNextBlock();
      }
      this.updateShape_();
      this.reconnectChildBlocks_(valueConnections, statementConnections, elseStatementConnection);
    },
    saveConnections: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      let i = 1;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        switch (clauseBlock.type) {
          case `${categoryPrefix$a}if_mutator_elseif`:
            const inputBool = this.getInput(`BOOL${i}`);
            const inputStatement = this.getInput(`BLOCKS${i}`);
            clauseBlock.valueConnection_ = inputBool && inputBool.connection.targetConnection;
            clauseBlock.statementConnection_ = inputStatement && inputStatement.connection.targetConnection;
            i++;
            break;
          case `${categoryPrefix$a}if_mutator_else`:
            const elseStatement = this.getInput("ELSE");
            clauseBlock.statementConnection_ = elseStatement && elseStatement.connection.targetConnection;
            break;
        }
        clauseBlock = clauseBlock.getNextBlock();
      }
    },
    rebuildShape_: function() {
      const valueConnections = [null];
      const statementConnections = [null];
      let elseStatementConnection = null;
      if (this.getInput("ELSE")) {
        elseStatementConnection = this.getInput("ELSE").connection.targetConnection;
      }
      for (let i = 1; this.getInput(`BOOL${i}`); i++) {
        valueConnections.push(this.getInput(`BOOL${i}`).connection.targetConnection);
        statementConnections.push(this.getInput(`BLOCKS${i}`).connection.targetConnection);
      }
      this.updateShape_();
      this.reconnectChildBlocks_(
        valueConnections,
        statementConnections,
        elseStatementConnection
      );
    },
    updateShape_: function() {
      if (this.getInput("ELSE")) {
        this.removeInput("ELSE");
        this.removeInput("DUMMYELSE");
      }
      for (let i = 1; this.getInput(`BOOL${i}`); i++) {
        this.removeInput(`BOOL${i}`);
        this.removeInput(`BLOCKS${i}`);
        this.removeInput(`DUMMY${i}`);
      }
      for (let i = 1; i <= this.elseifCount_; i++) {
        this.appendValueInput(`BOOL${i}`).setCheck("Boolean").appendField(translateBlockText("else if", getLanguage()));
        this.appendDummyInput(`DUMMY${i}`).appendField(translateBlockText("then", getLanguage()));
        this.appendStatementInput(`BLOCKS${i}`);
      }
      if (this.elseCount_) {
        this.appendDummyInput("DUMMYELSE").appendField(translateBlockText("else", getLanguage()));
        this.appendStatementInput("ELSE");
      }
    },
    reconnectChildBlocks_: function(valueConnections, statementConnections, elseStatementConnection) {
      for (let i = 1; i <= this.elseifCount_; i++) {
        Blockly.Mutator.reconnect(valueConnections[i], this, `BOOL${i}`);
        Blockly.Mutator.reconnect(statementConnections[i], this, `BLOCKS${i}`);
      }
      if (elseStatementConnection) {
        Blockly.Mutator.reconnect(elseStatementConnection, this, `ELSE`);
      }
    }
  };
  registerMutator(
    `${categoryPrefix$a}if_mutator`,
    control_if_mutator,
    null,
    [`${categoryPrefix$a}if_mutator_elseif`, `${categoryPrefix$a}if_mutator_else`]
  );
}
const categoryPrefix$9 = "math_";
const categoryColor$9 = "#6d6";
function register$a() {
  registerBlock(`${categoryPrefix$9}number`, {
    message0: "%1",
    args0: [
      {
        "type": "field_number",
        "name": "INPUT",
        "check": null,
        "text": "1",
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `Scratch.Cast.toNumber(${INPUT})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}boolean`, {
    message0: "%1",
    args0: [
      {
        "type": "input_value",
        "name": "INPUT"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT") || "false";
    const code = `Scratch.Cast.toBoolean(${INPUT})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}add`, {
    message0: "%1 + %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} + ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}sub`, {
    message0: "%1 - %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} - ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}mul`, {
    message0: "%1 × %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} * ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}div`, {
    message0: "%1 ÷ %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} / ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}pow`, {
    message0: "%1 ^ %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} ** ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}mod`, {
    message0: "%1 % %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} % ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}log`, {
    message0: "log %1 %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(Math.log(${Y}) / Math.log(${X}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}const`, {
    message0: "%1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "CHOICE",
        "options": [
          ["pi", "Math.PI"],
          ["e", "Math.E"],
          ["tau", "Math.PI * 2"],
          ["phi", "(1 + Math.sqrt(5)) / 2"]
        ]
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const CHOICE = block.getFieldValue("CHOICE");
    const code = `${CHOICE}`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}true`, {
    message0: "true",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const code = `true`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}false`, {
    message0: "false",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const code = `false`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}randombool`, {
    message0: "random",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const code = `(Math.random() > .5)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}and`, {
    message0: "%1 and %2",
    args0: [
      {
        "type": "input_value",
        "name": "X",
        "check": "Boolean"
      },
      {
        "type": "input_value",
        "name": "Y",
        "check": "Boolean"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X") || "false";
    const Y = javascriptGenerator.valueToCode(block, "Y") || "false";
    const code = `(${X} && ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}xor`, {
    message0: "%1 xor %2",
    args0: [
      {
        "type": "input_value",
        "name": "X",
        "check": "Boolean"
      },
      {
        "type": "input_value",
        "name": "Y",
        "check": "Boolean"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X") || "false";
    const Y = javascriptGenerator.valueToCode(block, "Y") || "false";
    const code = `(${X} != ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}or`, {
    message0: "%1 or %2",
    args0: [
      {
        "type": "input_value",
        "name": "X",
        "check": "Boolean"
      },
      {
        "type": "input_value",
        "name": "Y",
        "check": "Boolean"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X") || "false";
    const Y = javascriptGenerator.valueToCode(block, "Y") || "false";
    const code = `(${X} || ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}not`, {
    message0: "not %1",
    args0: [
      {
        "type": "input_value",
        "name": "BOOL",
        "check": "Boolean"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const BOOL = javascriptGenerator.valueToCode(block, "BOOL") || "false";
    const code = `(!${BOOL})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}equals`, {
    message0: "%1 = %2",
    args0: [
      {
        "type": "field_input",
        "name": "X",
        "check": null,
        "text": "foo",
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "Y",
        "check": null,
        "text": "bar",
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} == ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}gte`, {
    message0: "%1 >= %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} >= ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}gt`, {
    message0: "%1 > %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} > ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}lt`, {
    message0: "%1 < %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} < ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}lte`, {
    message0: "%1 <= %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `(${X} <= ${Y})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$9}random`, {
    message0: "pick random %1 to %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$9
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `vm.runtime.ext_scratch3_operators._random(${X}, ${Y})`;
    return [`${code}`, 0];
  });
}
const categoryPrefix$8 = "strings_";
const categoryColor$8 = "#6db";
function register$9() {
  registerBlock(`${categoryPrefix$8}string`, {
    message0: "%1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": null,
        "text": "apple",
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `Scratch.Cast.toString(${INPUT})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}join`, {
    message0: "",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$8,
    mutator: `${categoryPrefix$8}join_mutator`
  }, (block) => {
    let strings = [];
    for (let i = 0; block.getInput(`ITEM${i}`); i++) {
      const INPUT = javascriptGenerator.valueToCode(block, `ITEM${i}`);
      strings.push(INPUT);
    }
    const code = `String.prototype.concat(${strings.join(", ")})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}join_mutator_join`, {
    message0: "join",
    args0: [],
    nextStatement: null,
    inputsInline: true,
    enableContextMenu: false,
    colour: categoryColor$8
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$8}join_mutator_item`, {
    message0: "item",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$8}repeat`, {
    message0: "repeat %1 %2 times",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "check": "String",
        "text": "apple",
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "REPEAT",
        "check": "Number",
        "value": 10,
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const REPEAT = javascriptGenerator.valueToCode(block, "REPEAT");
    const code = `(${TEXT}.repeat(${REPEAT}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}split`, {
    message0: "split %1 with delimiter %2",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "check": "String",
        "text": "a,b,c",
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "DELIMIT",
        "check": "String",
        "text": ",",
        "acceptsBlocks": true
      }
    ],
    output: "List",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const DELIMIT = javascriptGenerator.valueToCode(block, "DELIMIT");
    const code = `(${TEXT}.split(${DELIMIT}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}length`, {
    message0: "length of %1",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "check": "String",
        "text": "apple",
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `(${TEXT}.length)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}substring`, {
    message0: "substring %1 to %2 of %3",
    args0: [
      {
        "type": "field_number",
        "name": "FROM",
        "check": "Number",
        "value": 1,
        "min": 1,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "TO",
        "check": "Number",
        "value": 3,
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "TEXT",
        "check": "String",
        "text": "apple",
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$8,
    extensions: [`${categoryPrefix$8}substring_extension`]
  }, (block) => {
    const FROM = javascriptGenerator.valueToCode(block, "FROM");
    const TO = javascriptGenerator.valueToCode(block, "TO");
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `(${TEXT}.substring(${FROM}, ${TO}))`;
    return [`${code}`, 0];
  });
  Blockly.Extensions.unregister(`${categoryPrefix$8}substring_extension`);
  Blockly.Extensions.register(`${categoryPrefix$8}substring_extension`, function() {
    this.setOnChange(function() {
      const FROM = this.getFieldInput("FROM").getTargetField();
      const TO = this.getFieldInput("TO").getTargetField();
      if (!TO) return;
      if (!FROM) {
        TO.setMin(1);
        if (1 > TO.getValue()) TO.setValue(1);
        return;
      }
      TO.setMin(FROM.getValue());
      if (FROM.getValue() > TO.getValue()) TO.setValue(FROM.getValue());
    });
  });
  registerBlock(`${categoryPrefix$8}contains`, {
    message0: "%1 %2 %3",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT1",
        "check": "String",
        "text": "apple",
        "acceptsBlocks": true
      },
      {
        "type": "field_dropdown",
        "name": "CHOICE",
        "options": [
          ["contains", "includes"],
          ["starts with", "startsWith"],
          ["ends with", "endsWith"]
        ]
      },
      {
        "type": "field_input",
        "name": "TEXT2",
        "check": "String",
        "text": "a",
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const TEXT1 = javascriptGenerator.valueToCode(block, "TEXT1");
    const CHOICE = block.getFieldValue("CHOICE");
    const TEXT2 = javascriptGenerator.valueToCode(block, "TEXT2");
    const code = `(${TEXT1}.${CHOICE}(${TEXT2}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}log`, {
    message0: "log %1",
    args0: [
      {
        "type": "field_input",
        "name": "TEXT",
        "check": null,
        "text": "hello world",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `console.log(${TEXT});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$8}amountof`, {
    message0: "amount of %1 in %2",
    args0: [
      {
        "type": "field_input",
        "name": "NEEDLE",
        "check": "String",
        "text": "p",
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "HAYSTACK",
        "check": "String",
        "text": "apple",
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const NEEDLE = javascriptGenerator.valueToCode(block, "NEEDLE");
    const HAYSTACK = javascriptGenerator.valueToCode(block, "HAYSTACK");
    const code = `CapivaraModBuilder.Utils.countString(${HAYSTACK}, ${NEEDLE})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$8}replace`, {
    message0: "replace %1 in %2 with %3",
    args0: [
      {
        "type": "field_input",
        "name": "X",
        "check": "String",
        "text": "foo",
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "Y",
        "check": "String",
        "text": "bar",
        "acceptsBlocks": true
      },
      {
        "type": "field_input",
        "name": "Z",
        "check": "String",
        "text": "baz",
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$8
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const Z = javascriptGenerator.valueToCode(block, "Z");
    const code = `(${Y}).replaceAll(${X}, ${Z})`;
    return [`${code}`, 0];
  });
  const strings_join_mutator = {
    items_: 0,
    mutationToDom: function() {
      const container = Blockly.utils.xml.createElement("mutation");
      container.setAttribute("items", String(this.items_));
      return container;
    },
    domToMutation: function(xmlElement) {
      this.items_ = parseInt(xmlElement.getAttribute("items"));
      this.updateShape_();
    },
    decompose: function(workspace) {
      const containerBlock = workspace.newBlock(`${categoryPrefix$8}join_mutator_join`);
      containerBlock.initSvg();
      let connection = containerBlock.nextConnection;
      for (let i = 0; i < this.items_; i++) {
        const itemBlock = workspace.newBlock(`${categoryPrefix$8}join_mutator_item`);
        itemBlock.initSvg();
        connection.connect(itemBlock.previousConnection);
        connection = itemBlock.nextConnection;
      }
      return containerBlock;
    },
    compose: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      const connections = [];
      const oldItems = this.items_;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        connections.push(clauseBlock.valueConnection_);
        clauseBlock = clauseBlock.getNextBlock();
      }
      for (let i = 0; i < this.items_; i++) {
        const connection = this.getInput(`ITEM${i}`).connection.targetConnection;
        if (connection && !connection.sourceBlock_.isShadow() && connections.indexOf(connection) === -1) {
          connection.disconnect();
        }
      }
      this.items_ = connections.length;
      this.updateShape_();
      for (let i = 0; i < this.items_; i++) {
        if (connections[i] && oldItems !== this.items_) {
          const connection = this.getInput(`ITEM${i}`).connection.targetConnection;
          const block = connection.sourceBlock_;
          connection.disconnect();
          block.dispose(true);
        }
        Blockly.Mutator.reconnect(connections[i], this, `ITEM${i}`);
      }
    },
    saveConnections: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      let i = 0;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        const input = this.getInput(`ITEM${i}`);
        clauseBlock.valueConnection_ = input && input.connection.targetConnection && input.connection.targetConnection.sourceBlock_ && !input.connection.targetConnection.sourceBlock_.isShadow() && input.connection.targetConnection;
        i++;
        clauseBlock = clauseBlock.getNextBlock();
      }
    },
    updateShape_: function() {
      if (this.items_ > 0 && this.getInput("EMPTY")) {
        this.removeInput("EMPTY");
      } else if (this.items_ == 0 && !this.getInput("EMPTY")) {
        this.appendDummyInput("EMPTY").appendField(translateBlockText("empty string", getLanguage()));
      }
      for (let i = 0; i < this.items_; i++) {
        if (!this.getInput(`ITEM${i}`)) {
          const input = this.appendValueInput(`ITEM${i}`).setAlign(Blockly.ALIGN_RIGHT);
          input.setCheck("String");
          const inputInside = this.workspace.newBlock("generic_text");
          inputInside.setShadow(true);
          inputInside.initSvg();
          inputInside.render();
          inputInside.outputConnection.connect(input.connection);
          if (i === 0) {
            input.appendField(translateBlockText("join", getLanguage()));
          }
        }
      }
      for (let i = this.items_; this.getInput(`ITEM${i}`); i++) {
        this.removeInput(`ITEM${i}`);
      }
    }
  };
  registerMutator(
    `${categoryPrefix$8}join_mutator`,
    strings_join_mutator,
    null,
    [`${categoryPrefix$8}join_mutator_item`]
  );
}
const categoryPrefix$7 = "vector_";
const categoryColor$7 = "#6cd";
function register$8() {
  registerBlock(`${categoryPrefix$7}create`, {
    message0: "vector x: %1 y: %2",
    args0: [
      {
        "type": "field_number",
        "name": "X",
        "check": "Number",
        "value": 0,
        "acceptsBlocks": true
      },
      {
        "type": "field_number",
        "name": "Y",
        "check": "Number",
        "value": 0,
        "acceptsBlocks": true
      }
    ],
    output: "Vector",
    inputsInline: true,
    colour: categoryColor$7
  }, (block) => {
    const X = javascriptGenerator.valueToCode(block, "X");
    const Y = javascriptGenerator.valueToCode(block, "Y");
    const code = `new CapivaraModBuilder.Vector(${X}, ${Y})`;
    return code;
  });
  registerBlock(`${categoryPrefix$7}x`, {
    message0: "%1 x",
    args0: [
      {
        "type": "input_value",
        "name": "VEC",
        "check": "Vector"
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$7
  }, (block) => {
    const VEC = javascriptGenerator.valueToCode(block, "VEC");
    const code = `(${VEC}).x`;
    return code;
  });
  registerBlock(`${categoryPrefix$7}y`, {
    message0: "%1 y",
    args0: [
      {
        "type": "input_value",
        "name": "VEC",
        "check": "Vector"
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$7
  }, (block) => {
    const VEC = javascriptGenerator.valueToCode(block, "VEC");
    const code = `(${VEC}).y`;
    return code;
  });
}
const categoryPrefix$6 = "inputs_";
const categoryColor$6 = "#69d";
const TARGET = `(Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage))`;
let keys = [
  "any",
  "space",
  "shift",
  "up arrow",
  "down arrow",
  "left arrow",
  "right arrow",
  ["plus", "+"],
  ["minus", "-"],
  ["equals", "="],
  ["underscore", "_"],
  ["colon", ":"],
  ["semicolon", ";"],
  ["period", "."],
  ["comma", ","],
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "0"
].map((v) => typeof v == "string" ? [v, v] : v);
function register$7() {
  registerBlock(`${categoryPrefix$6}keypress`, {
    message0: "is key %1 pressed?",
    args0: [
      {
        "type": "field_dropdown",
        "name": "KEY",
        "options": keys,
        "check": "String",
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const KEY = javascriptGenerator.valueToCode(block, "KEY");
    const code = `Scratch.vm.runtime.ioDevices.keyboard.getKeyIsDown(${KEY})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}keyspressed`, {
    message0: "keys pressed",
    args0: [],
    output: "List",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.keyboard.getAllKeysPressed()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}mousex`, {
    message0: "mouse x",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.mouse.getScratchX()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}mousey`, {
    message0: "mouse y",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.mouse.getScratchY()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}moused`, {
    message0: "mouse down",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.mouse.getIsDown()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}touching`, {
    message0: "touching %1 ?",
    args0: [
      {
        "type": "field_dropdown",
        "name": "OBJECT",
        "options": [
          ["mouse pointer", "_mouse_"],
          ["edge", "_edge_"]
        ]
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const OBJECT = block.getFieldValue("OBJECT");
    const code = `${TARGET}.isTouchingObject("${OBJECT}")`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}touchingsprite`, {
    message0: "touching sprite %1 ?",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "check": "String",
        "text": "Sprite1",
        "acceptsBlocks": true
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `${TARGET}.isTouchingObject(${NAME})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}touchingcolor`, {
    message0: "touching color %1 ?",
    args0: [
      {
        "type": "field_colour",
        "name": "COLOR",
        "colour": "#ff0000"
      }
    ],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const COLOR = block.getFieldValue("COLOR");
    const code = `${TARGET}.isTouchingColor(Scratch.Cast.toRgbColorList(${JSON.stringify(COLOR)}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}distancemouse`, {
    message0: "distance to mouse pointer",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `(() => { const t = ${TARGET}; const m = Scratch.vm.runtime.ioDevices.mouse; return Math.sqrt(Math.pow(t.x - m.getScratchX(), 2) + Math.pow(t.y - m.getScratchY(), 2)); })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}distancesprite`, {
    message0: "distance to sprite %1",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "check": "String",
        "text": "Sprite1",
        "acceptsBlocks": true
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `(() => { const t = ${TARGET}; const o = Scratch.vm.runtime.getSpriteTargetByName(${NAME}); if (!o) return 10000; return Math.sqrt(Math.pow(t.x - o.x, 2) + Math.pow(t.y - o.y, 2)); })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}ask`, {
    message0: "ask %1 and wait",
    args0: [
      {
        "type": "field_input",
        "name": "QUESTION",
        "check": "String",
        "text": "What's your name?",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const QUESTION = javascriptGenerator.valueToCode(block, "QUESTION");
    const code = `await Scratch.vm.runtime.ext_scratch3_sensing.askAndWait({ QUESTION: ${QUESTION} }, { target: ${TARGET} });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$6}answer`, {
    message0: "answer",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ext_scratch3_sensing.getAnswer()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}timer`, {
    message0: "timer",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.clock.projectTimer()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}resettimer`, {
    message0: "reset timer",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.clock.resetProjectTimer();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$6}current`, {
    message0: "current %1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "UNIT",
        "options": [
          ["year", "new Date().getFullYear()"],
          ["month", "(new Date().getMonth() + 1)"],
          ["date", "new Date().getDate()"],
          ["day of week", "(new Date().getDay() + 1)"],
          ["hour", "new Date().getHours()"],
          ["minute", "new Date().getMinutes()"],
          ["second", "new Date().getSeconds()"]
        ]
      }
    ],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = block.getFieldValue("UNIT");
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}dayssince2000`, {
    message0: "days since 2000",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `(() => { const start = new Date(2000, 0, 1); const today = new Date(); const dst = today.getTimezoneOffset() - start.getTimezoneOffset(); let ms = today.valueOf() - start.valueOf(); ms += (today.getTimezoneOffset() - dst) * 60 * 1000; return ms / 86400000; })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}username`, {
    message0: "username",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.userData.getUsername()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}loudness`, {
    message0: "loudness",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `(Scratch.vm.runtime.audioEngine && Scratch.vm.runtime.audioEngine.getLoudness ? Scratch.vm.runtime.audioEngine.getLoudness() : -1)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$6}setdrag`, {
    message0: "set drag mode %1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "MODE",
        "options": [
          ["draggable", "true"],
          ["not draggable", "false"]
        ]
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const MODE = block.getFieldValue("MODE");
    const code = `${TARGET}.setDraggable(${MODE});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$6}draggable`, {
    message0: "draggable?",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$6
  }, (block) => {
    const code = `Boolean(${TARGET}.draggable)`;
    return [`${code}`, 0];
  });
}
const categoryPrefix$5 = "variables_";
const categoryColor$5 = "#f96";
function getVariables() {
  if (!(window && window.variables && Object.keys(window.variables).length > 0)) return [["", ""]];
  return Object.entries(window.variables).map((v) => [v[0], v[0]]);
}
function register$6() {
  registerBlock(`${categoryPrefix$5}get`, {
    message0: "%1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "NAME",
        "options": getVariables
      }
    ],
    output: null,
    inputsInline: true,
    colour: categoryColor$5,
    extensions: [`${categoryPrefix$5}get_extension`]
  }, (block) => {
    const NAME = block.getFieldValue("NAME");
    const code = `CapivaraModBuilder.Variables.get("${NAME}")`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$5}set`, {
    message0: "set %1 to %2",
    args0: [
      {
        "type": "field_dropdown",
        "name": "NAME",
        "options": getVariables
      },
      {
        "type": "input_value",
        "name": "INPUT"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$5,
    extensions: [`${categoryPrefix$5}set_extension`]
  }, (block) => {
    const NAME = block.getFieldValue("NAME");
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT") || "null";
    const code = `CapivaraModBuilder.Variables.set("${NAME}", ${INPUT})`;
    return `${code}
`;
  });
  Blockly.Extensions.unregister(`${categoryPrefix$5}get_extension`);
  Blockly.Extensions.register(`${categoryPrefix$5}get_extension`, function() {
    this.setOnChange(function() {
      const NAME = this.getField("NAME");
      const variable = window && window.variables && window.variables[NAME.getValue()];
      if (!variable) {
        this.setOutput(true, null);
      } else {
        this.setOutput(true, variable.type);
      }
    });
  });
  Blockly.Extensions.unregister(`${categoryPrefix$5}set_extension`);
  Blockly.Extensions.register(`${categoryPrefix$5}set_extension`, function() {
    this.setOnChange(function() {
      const NAME = this.getField("NAME");
      const variable = window && window.variables && window.variables[NAME.getValue()];
      const type = variable ? variable.type : null;
      this.getInput("INPUT").setCheck(type);
    });
  });
}
const categoryPrefix$4 = "lists_";
const categoryColor$4 = "#f76";
function register$5() {
  registerBlock(`${categoryPrefix$4}create`, {
    message0: "",
    args0: [],
    inputsInline: false,
    output: "List",
    colour: categoryColor$4,
    mutator: `${categoryPrefix$4}create_mutator`
  }, (block) => {
    let code = "[";
    for (let i = 0; block.getInput(`ITEM${i}`); i++) {
      const ITEM = javascriptGenerator.valueToCode(block, `ITEM${i}`) || "null";
      code += `${ITEM}${block.getInput(`ITEM${i + 1}`) ? ", " : ""}`;
    }
    code += "]";
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}create_mutator_list`, {
    message0: "list",
    args0: [],
    nextStatement: null,
    inputsInline: true,
    enableContextMenu: false,
    colour: categoryColor$4
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$4}create_mutator_item`, {
    message0: "item",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$4
  }, (block) => {
  });
  registerBlock(`${categoryPrefix$4}get`, {
    message0: "get item %1 of %2",
    args0: [
      {
        "type": "field_number",
        "name": "INDEX",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      }
    ],
    inputsInline: true,
    output: null,
    colour: categoryColor$4
  }, (block) => {
    const INDEX = javascriptGenerator.valueToCode(block, "INDEX");
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `(${INPUT}[${INDEX}-1])`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}index`, {
    message0: "index of %1 in %2",
    args0: [
      {
        "type": "field_input",
        "name": "VALUE",
        "check": null,
        "value": "",
        "acceptsBlocks": true
      },
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      }
    ],
    inputsInline: true,
    output: "Number",
    colour: categoryColor$4
  }, (block) => {
    const VALUE = javascriptGenerator.valueToCode(block, "VALUE");
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `(${INPUT}.indexOf(${VALUE})+1)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}contains`, {
    message0: "%1 contains %2",
    args0: [
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      },
      {
        "type": "field_input",
        "name": "VALUE",
        "check": null,
        "value": "",
        "acceptsBlocks": true
      }
    ],
    inputsInline: true,
    output: "Boolean",
    colour: categoryColor$4
  }, (block) => {
    const VALUE = javascriptGenerator.valueToCode(block, "VALUE");
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `(${INPUT}.includes(${VALUE}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}set`, {
    message0: "set item %1 of %2 to %3",
    args0: [
      {
        "type": "field_number",
        "name": "INDEX",
        "check": "Number",
        "value": 1,
        "acceptsBlocks": true
      },
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      },
      {
        "type": "field_input",
        "name": "TEXT",
        "check": null,
        "text": "",
        "acceptsBlocks": true
      }
    ],
    inputsInline: true,
    output: "List",
    colour: categoryColor$4
  }, (block) => {
    const INDEX = javascriptGenerator.valueToCode(block, "INDEX");
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `CapivaraModBuilder.Utils.setList(${INPUT}, ${INDEX}-1, ${TEXT})`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}length`, {
    message0: "length of %1",
    args0: [
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      }
    ],
    inputsInline: true,
    output: "Number",
    colour: categoryColor$4
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `(${INPUT}.length)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}join`, {
    message0: "join %1 with delimiter %2",
    args0: [
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "List"
      },
      {
        "type": "field_input",
        "name": "TEXT",
        "check": "String",
        "text": ",",
        "acceptsBlocks": true
      }
    ],
    inputsInline: true,
    output: "String",
    colour: categoryColor$4
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `(${INPUT}.join(${TEXT}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}concat`, {
    message0: "concat %1 with %2",
    args0: [
      {
        "type": "input_value",
        "name": "LIST1",
        "check": "List"
      },
      {
        "type": "input_value",
        "name": "LIST2",
        "check": "List"
      }
    ],
    inputsInline: true,
    output: "List",
    colour: categoryColor$4
  }, (block) => {
    const LIST1 = javascriptGenerator.valueToCode(block, "LIST1");
    const LIST2 = javascriptGenerator.valueToCode(block, "LIST2");
    const code = `(${LIST1}.concat(${LIST2}))`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}foreach`, {
    message0: "for each %1 %2 in %3 %4 %5",
    args0: [
      {
        "type": "input_value",
        "name": "INDEX"
      },
      {
        "type": "input_value",
        "name": "VALUE"
      },
      {
        "type": "input_value",
        "name": "LIST",
        "check": "List"
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$4
  }, (block) => {
    const LIST = javascriptGenerator.valueToCode(block, "LIST");
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const varlistname = "temp_" + util.randomHex(24);
    const varindexname = "temp_" + util.randomHex(24);
    const vardepthname = "temp_" + util.randomHex(24);
    const code = `var ${varlistname} = ${LIST};
        CapivaraModBuilder.Utils.lists_foreach.depth += 1;
        var ${vardepthname} = CapivaraModBuilder.Utils.lists_foreach.depth;
        for (var ${varindexname} in ${varlistname}) {
            CapivaraModBuilder.Utils.lists_foreach.index[${vardepthname}] = ${varindexname};
            CapivaraModBuilder.Utils.lists_foreach.value[${vardepthname}] = ${varlistname}[${varindexname}];
            ${BLOCKS}
        };
        CapivaraModBuilder.Utils.lists_foreach.depth -= 1;
        `;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$4}foreachindex`, {
    message0: "index",
    args0: [],
    output: "Number",
    inputsInline: true,
    canDragDuplicate: true,
    colour: categoryColor$4
  }, (block) => {
    const code = `CapivaraModBuilder.Utils.lists_foreach.index[CapivaraModBuilder.Utils.lists_foreach.depth]`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$4}foreachvalue`, {
    message0: "value",
    args0: [],
    output: null,
    inputsInline: true,
    canDragDuplicate: true,
    colour: categoryColor$4
  }, (block) => {
    const code = `CapivaraModBuilder.Utils.lists_foreach.value[CapivaraModBuilder.Utils.lists_foreach.depth]`;
    return [`${code}`, 0];
  });
  const lists_create_mutator = {
    items_: 0,
    mutationToDom: function() {
      const container = Blockly.utils.xml.createElement("mutation");
      container.setAttribute("items", String(this.items_));
      return container;
    },
    domToMutation: function(xmlElement) {
      this.items_ = parseInt(xmlElement.getAttribute("items"));
      this.updateShape_();
    },
    decompose: function(workspace) {
      const containerBlock = workspace.newBlock(`${categoryPrefix$4}create_mutator_list`);
      containerBlock.initSvg();
      let connection = containerBlock.nextConnection;
      for (let i = 0; i < this.items_; i++) {
        const itemBlock = workspace.newBlock(`${categoryPrefix$4}create_mutator_item`);
        itemBlock.initSvg();
        connection.connect(itemBlock.previousConnection);
        connection = itemBlock.nextConnection;
      }
      return containerBlock;
    },
    compose: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      const connections = [];
      const oldItems = this.items_;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        connections.push(clauseBlock.valueConnection_);
        clauseBlock = clauseBlock.getNextBlock();
      }
      for (let i = 0; i < this.items_; i++) {
        const connection = this.getInput(`ITEM${i}`).connection.targetConnection;
        if (connection && !connection.sourceBlock_.isShadow() && connections.indexOf(connection) === -1) {
          connection.disconnect();
        }
      }
      this.items_ = connections.length;
      this.updateShape_();
      for (let i = 0; i < this.items_; i++) {
        if (connections[i] && oldItems !== this.items_) {
          const connection = this.getInput(`ITEM${i}`).connection.targetConnection;
          const block = connection.sourceBlock_;
          connection.disconnect();
          block.dispose(true);
        }
        Blockly.Mutator.reconnect(connections[i], this, `ITEM${i}`);
      }
    },
    saveConnections: function(containerBlock) {
      let clauseBlock = containerBlock.nextConnection.targetBlock();
      let i = 0;
      while (clauseBlock) {
        if (clauseBlock.isInsertionMarker()) {
          clauseBlock = clauseBlock.getNextBlock();
          continue;
        }
        const input = this.getInput(`ITEM${i}`);
        clauseBlock.valueConnection_ = input && input.connection.targetConnection && input.connection.targetConnection.sourceBlock_ && !input.connection.targetConnection.sourceBlock_.isShadow() && input.connection.targetConnection;
        i++;
        clauseBlock = clauseBlock.getNextBlock();
      }
    },
    updateShape_: function() {
      if (this.items_ > 0 && this.getInput("EMPTY")) {
        this.removeInput("EMPTY");
      } else if (this.items_ == 0 && !this.getInput("EMPTY")) {
        this.appendDummyInput("EMPTY").appendField(translateBlockText("create empty list", getLanguage()));
      }
      for (let i = 0; i < this.items_; i++) {
        if (!this.getInput(`ITEM${i}`)) {
          const input = this.appendValueInput(`ITEM${i}`).setAlign(Blockly.ALIGN_RIGHT);
          const inputInside = this.workspace.newBlock("generic_any");
          inputInside.setShadow(true);
          inputInside.initSvg();
          inputInside.render();
          inputInside.outputConnection.connect(input.connection);
          if (i === 0) {
            input.appendField(translateBlockText("create list with", getLanguage()));
          }
        }
      }
      for (let i = this.items_; this.getInput(`ITEM${i}`); i++) {
        this.removeInput(`ITEM${i}`);
      }
    }
  };
  registerMutator(
    `${categoryPrefix$4}create_mutator`,
    lists_create_mutator,
    null,
    [`${categoryPrefix$4}create_mutator_item`]
  );
}
const categoryPrefix$3 = "blocks_";
const categoryColor$3 = "#b6f";
function clearDynamicInputs(block) {
  for (let i = 0; ; i++) {
    const inputName = `INPUT${i}`;
    const input = block.getInput(inputName);
    if (!input) break;
    const target = input.connection && input.connection.targetBlock();
    if (target && target.isShadow()) {
      target.dispose(false);
    }
    block.removeInput(inputName, true);
  }
}
function register$4() {
  registerBlock(`${categoryPrefix$3}define`, {
    message0: "%1",
    args0: [
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    colour: categoryColor$3,
    mutator: `${categoryPrefix$3}define_mutator`
  }, (block) => {
    return "";
  });
  const defineMutator = {
    blockId_: "",
    mutationToDom: function() {
      var container = Blockly.utils.xml.createElement("mutation");
      container.setAttribute("blockId", this.blockId_);
      return container;
    },
    domToMutation: function(xmlElement) {
      this.blockId_ = xmlElement.getAttribute("blockId") ?? "";
      this.updateShape_();
    },
    updateShape_: function() {
      clearDynamicInputs(this);
      let block = window.blocks[this.blockId_];
      if (!block) return;
      let i = 0;
      for (let field of block.fields) {
        switch (field.type) {
          case "label":
            this.appendDummyInput(`INPUT${i}`).appendField(field.text);
            break;
          case "string":
          case "number":
          case "boolean":
            var input = this.appendValueInput(`INPUT${i}`);
            let reporter = this.workspace.newBlock(`${categoryPrefix$3}input`);
            reporter.blockId_ = this.blockId_;
            reporter.fieldId_ = field.id;
            reporter.setShadow(true);
            reporter.updateShape_();
            reporter.initSvg();
            reporter.render();
            reporter.outputConnection.connect(input.connection);
            break;
        }
        this.moveInputBefore(`INPUT${i}`, `BLOCKS`);
        i++;
      }
    }
  };
  registerMutator(
    `${categoryPrefix$3}define_mutator`,
    defineMutator
  );
  registerBlock(`${categoryPrefix$3}input`, {
    message0: "",
    output: null,
    inputsInline: true,
    canDragDuplicate: true,
    colour: categoryColor$3,
    mutator: `${categoryPrefix$3}input_mutator`
  }, (block) => {
    let root = block.getRootBlock();
    if (!(root.type == `${categoryPrefix$3}define` && root.blockId_ == block.blockId_)) {
      return `null`;
    }
    return `args["${block.fieldId_}"]`;
  });
  const inputMutator = {
    blockId_: "",
    fieldId_: "",
    mutationToDom: function() {
      var container = Blockly.utils.xml.createElement("mutation");
      container.setAttribute("blockId", this.blockId_);
      container.setAttribute("fieldId", this.fieldId_);
      return container;
    },
    domToMutation: function(xmlElement) {
      this.blockId_ = xmlElement.getAttribute("blockId") ?? "";
      this.fieldId_ = xmlElement.getAttribute("fieldId") ?? "";
      this.updateShape_();
    },
    updateShape_: function() {
      let text = "";
      let block;
      let field;
      try {
        block = window.blocks[this.blockId_];
        field = block.fields.find((v) => v.id == this.fieldId_);
        text = field.text;
      } catch {
      }
      this.removeInput("TEXT", true);
      this.appendDummyInput("TEXT").appendField(text);
      if (field) {
        switch (field.type) {
          case "string":
            this.setOutput(true, "String");
            break;
          case "number":
            this.setOutput(true, "Number");
            break;
          case "boolean":
            this.setOutput(true, "Boolean");
            break;
          default:
            this.setOutput(true, null);
        }
      } else {
        this.setOutput(true, null);
      }
    }
  };
  registerMutator(
    `${categoryPrefix$3}input_mutator`,
    inputMutator
  );
  registerBlock(`${categoryPrefix$3}execute`, {
    message0: "",
    inputsInline: true,
    colour: categoryColor$3,
    mutator: `${categoryPrefix$3}execute_mutator`
  }, (block) => {
    let b = window.blocks[block.blockId_];
    if (!b) return "()";
    let object = [];
    for (let i = 0; block.getInput(`INPUT${i}`); i++) {
      let field = b.fields[i];
      if (field.type !== "label") {
        object.push(`"${field.id}": ${javascriptGenerator.valueToCode(block, `INPUT${i}`)}`);
      }
    }
    return `await extension["block_${block.blockId_}"]({${object.join(", ")}})`;
  });
  const executeMutator = {
    blockId_: "",
    mutationToDom: function() {
      var container = Blockly.utils.xml.createElement("mutation");
      container.setAttribute("blockId", this.blockId_);
      return container;
    },
    domToMutation: function(xmlElement) {
      this.blockId_ = xmlElement.getAttribute("blockId") ?? "";
      this.updateShape_();
    },
    updateShape_: function() {
      clearDynamicInputs(this);
      let block = window.blocks[this.blockId_];
      if (!block) return;
      this.setOutput(false);
      this.setPreviousStatement(false);
      this.setNextStatement(false);
      switch (block.type) {
        case "command": {
          this.setPreviousStatement(true, null);
          this.setNextStatement(true, null);
          break;
        }
        case "reporter": {
          this.setOutput(true, ["String", "Number", "Boolean"]);
          break;
        }
        case "Boolean": {
          this.setOutput(true, "Boolean");
          break;
        }
      }
      let i = 0;
      for (let field of block.fields) {
        switch (field.type) {
          case "label":
            this.appendDummyInput(`INPUT${i}`).appendField(field.text);
            break;
          case "string":
            var input = this.appendValueInput(`INPUT${i}`);
            input.setCheck("String");
            var inputInside = this.workspace.newBlock("generic_text");
            inputInside.setFieldValue(field.default, "TEXT");
            inputInside.setShadow(true);
            inputInside.initSvg();
            inputInside.render();
            inputInside.outputConnection.connect(input.connection);
            break;
          case "number":
            var input = this.appendValueInput(`INPUT${i}`);
            input.setCheck("Number");
            var inputInside = this.workspace.newBlock("generic_number");
            inputInside.setFieldValue(Number(field.default) || 0, "NUMBER");
            inputInside.setShadow(true);
            inputInside.initSvg();
            inputInside.render();
            inputInside.outputConnection.connect(input.connection);
            break;
          case "boolean":
            var input = this.appendValueInput(`INPUT${i}`);
            input.setCheck("Boolean");
            break;
        }
        i++;
      }
    }
  };
  registerMutator(
    `${categoryPrefix$3}execute_mutator`,
    executeMutator
  );
  registerBlock(`${categoryPrefix$3}return`, {
    message0: "return %1",
    args0: [
      {
        "type": "field_input",
        "name": "X",
        "check": null,
        "text": "0",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    inputsInline: true,
    colour: categoryColor$3
  }, (block) => {
    let X = javascriptGenerator.valueToCode(block, "X");
    return `return (${X})`;
  });
}
const categoryPrefix$2 = "runtime_";
const categoryColor$2 = "#aaa";
function register$3() {
  registerBlock(`${categoryPrefix$2}start`, {
    message0: "start project",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `Scratch.vm.greenFlag();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}stop`, {
    message0: "stop project",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `Scratch.vm.stopAll();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}running`, {
    message0: "project running?",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `(Scratch.vm.runtime.threads.length > 0)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$2}onstart`, {
    message0: "when project started %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$2
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.on('PROJECT_RUN_START', (async () => { ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}onstop`, {
    message0: "when project stopped %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$2
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.on('PROJECT_RUN_STOP', (async () => { ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}beforetick`, {
    message0: "before project tick %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$2
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.on('BEFORE_EXECUTE', (async () => { ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}aftertick`, {
    message0: "after project tick %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor$2
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `Scratch.vm.on('AFTER_EXECUTE', (async () => { ${BLOCKS} }));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}turboget`, {
    message0: "turbo mode enabled?",
    args0: [],
    output: "Boolean",
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `Scratch.vm.runtime.turboMode`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$2}turboset`, {
    message0: "set turbo mode to %1",
    args0: [
      {
        "type": "input_value",
        "name": "INPUT",
        "check": "Boolean"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `Scratch.vm.runtime.turboMode = ${INPUT};`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}frameget`, {
    message0: "frame rate",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `Scratch.vm.runtime.frameLoop.framerate`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$2}frameset`, {
    message0: "set frame rate to %1",
    args0: [
      {
        "type": "field_number",
        "name": "INPUT",
        "check": "Number",
        "value": 30,
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `Scratch.vm.runtime.frameLoop.setFramerate(${INPUT});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$2}timer`, {
    message0: "project timer",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    const code = `Scratch.vm.runtime.ioDevices.clock.projectTimer()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix$2}broadcast`, {
    message0: "broadcast project %1",
    args0: [
      {
        "type": "field_input",
        "name": "NAME",
        "text": "broadcast1",
        "acceptsBlocks": true,
        "check": "String"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$2
  }, (block) => {
    let NAME = javascriptGenerator.valueToCode(block, "NAME");
    return `Scratch.vm.runtime.startHats("event_whenbroadcastreceived", {BROADCAST_OPTION: ${NAME}})`;
  });
}
const categoryPrefix$1 = "script_";
const categoryColor$1 = "#9d5";
function textField$1(name, text) {
  return {
    "type": "field_input",
    "name": name,
    "check": "String",
    "text": text,
    "acceptsBlocks": true
  };
}
function register$2() {
  registerBlock(`${categoryPrefix$1}evalb`, {
    message0: "eval %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": "String",
        "text": 'alert("hi")',
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `eval(${INPUT})`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$1}evalv`, {
    message0: "eval %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": "String",
        "text": "Math.random()",
        "acceptsBlocks": true
      }
    ],
    output: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `eval(${INPUT})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}fetch`, {
    message0: "fetch %1",
    args0: [textField$1("URL", "https://example.com")],
    output: "String",
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const URL = javascriptGenerator.valueToCode(block, "URL");
    const code = `(await (await fetch(${URL})).text())`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}fetchjson`, {
    message0: "fetch json %1",
    args0: [textField$1("URL", "https://example.com/data.json")],
    output: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const URL = javascriptGenerator.valueToCode(block, "URL");
    const code = `(await (await fetch(${URL})).json())`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}fetchadvanced`, {
    message0: "fetch %1 method %2 headers %3 body %4",
    args0: [
      textField$1("URL", "https://example.com"),
      {
        "type": "field_dropdown",
        "name": "METHOD",
        "options": [
          ["GET", "GET"],
          ["POST", "POST"],
          ["PUT", "PUT"],
          ["PATCH", "PATCH"],
          ["DELETE", "DELETE"]
        ]
      },
      textField$1("HEADERS", "{}"),
      textField$1("BODY", "")
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const URL = javascriptGenerator.valueToCode(block, "URL");
    const METHOD = block.getFieldValue("METHOD");
    const HEADERS = javascriptGenerator.valueToCode(block, "HEADERS");
    const BODY = javascriptGenerator.valueToCode(block, "BODY");
    const code = `(await (await fetch(${URL}, { method: "${METHOD}", headers: JSON.parse(${HEADERS} || "{}"), body: ${BODY} ? ${BODY} : undefined })).text())`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}jsonparse`, {
    message0: "parse json %1",
    args0: [textField$1("TEXT", '{"a":1}')],
    output: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const TEXT = javascriptGenerator.valueToCode(block, "TEXT");
    const code = `JSON.parse(${TEXT})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}jsonstringify`, {
    message0: "to json %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": null,
        "text": "",
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `JSON.stringify(${INPUT})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}consolelog`, {
    message0: "console log %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": null,
        "text": "hello",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `console.log(${INPUT});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$1}consoleerror`, {
    message0: "console error %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": null,
        "text": "something went wrong",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `console.error(${INPUT});`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$1}trycatch`, {
    message0: "try %1 %2 catch %3 %4",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "TRY"
      },
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "CATCH"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const TRY = javascriptGenerator.statementToCode(block, "TRY");
    const CATCH = javascriptGenerator.statementToCode(block, "CATCH");
    const varName = "err_" + util.randomHex(24);
    const code = `try { ${TRY} } catch (${varName}) { CapivaraModBuilder.Utils.lastError = ${varName}; ${CATCH} }`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix$1}lasterror`, {
    message0: "last error message",
    args0: [],
    output: "String",
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const code = `(CapivaraModBuilder.Utils.lastError ? CapivaraModBuilder.Utils.lastError.message : "")`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}typeof`, {
    message0: "typeof %1",
    args0: [
      {
        "type": "field_input",
        "name": "INPUT",
        "check": null,
        "text": "",
        "acceptsBlocks": true
      }
    ],
    output: "String",
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const INPUT = javascriptGenerator.valueToCode(block, "INPUT");
    const code = `typeof (${INPUT})`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}globalget`, {
    message0: "get global %1",
    args0: [textField$1("NAME", "myGlobal")],
    output: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `window[${NAME}]`;
    return [code, 0];
  });
  registerBlock(`${categoryPrefix$1}globalset`, {
    message0: "set global %1 to %2",
    args0: [
      textField$1("NAME", "myGlobal"),
      {
        "type": "field_input",
        "name": "VALUE",
        "check": null,
        "text": "",
        "acceptsBlocks": true
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor$1
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const VALUE = javascriptGenerator.valueToCode(block, "VALUE");
    const code = `window[${NAME}] = ${VALUE};`;
    return `${code}
`;
  });
}
const categoryPrefix = "music_";
const categoryColor = "#ae29d6";
const SYNTH = `(window.__capivaraSynth || (window.__capivaraSynth = { ctx: new (window.AudioContext || window.webkitAudioContext)(), waveform: "sine", volume: 1, tempo: 60, voices: {}, midiAccess: null, midiOutput: null, noteToFreq: n => 440 * Math.pow(2, (n - 69) / 12) }))`;
const MIDI = `${SYNTH}`;
function numberField(name, value) {
  return {
    "type": "field_number",
    "name": name,
    "check": "Number",
    "value": value,
    "acceptsBlocks": true
  };
}
function textField(name, text) {
  return {
    "type": "field_input",
    "name": name,
    "check": "String",
    "text": text,
    "acceptsBlocks": true
  };
}
function register$1() {
  registerBlock(`${categoryPrefix}playnote`, {
    message0: "play note %1 for %2 beats",
    args0: [numberField("NOTE", 60), numberField("BEATS", 1)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NOTE = javascriptGenerator.valueToCode(block, "NOTE");
    const BEATS = javascriptGenerator.valueToCode(block, "BEATS");
    const code = `await (() => { const s = ${SYNTH}; const dur = ${BEATS} * (60 / s.tempo); const osc = s.ctx.createOscillator(); const gain = s.ctx.createGain(); osc.type = s.waveform; osc.frequency.value = s.noteToFreq(${NOTE}); gain.gain.value = s.volume; osc.connect(gain); gain.connect(s.ctx.destination); osc.start(); gain.gain.setTargetAtTime(0, s.ctx.currentTime + dur * 0.9, 0.05); osc.stop(s.ctx.currentTime + dur); return new Promise(done => setTimeout(done, dur * 1000)); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}playnotenowait`, {
    message0: "start note %1",
    args0: [numberField("NOTE", 60)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NOTE = javascriptGenerator.valueToCode(block, "NOTE");
    const code = `(() => { const s = ${SYNTH}; if (s.voices[${NOTE}]) return; const osc = s.ctx.createOscillator(); const gain = s.ctx.createGain(); osc.type = s.waveform; osc.frequency.value = s.noteToFreq(${NOTE}); gain.gain.value = s.volume; osc.connect(gain); gain.connect(s.ctx.destination); osc.start(); s.voices[${NOTE}] = { osc, gain }; })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}stopnote`, {
    message0: "stop note %1",
    args0: [numberField("NOTE", 60)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NOTE = javascriptGenerator.valueToCode(block, "NOTE");
    const code = `(() => { const s = ${SYNTH}; const v = s.voices[${NOTE}]; if (!v) return; v.gain.gain.setTargetAtTime(0, s.ctx.currentTime, 0.05); v.osc.stop(s.ctx.currentTime + 0.2); delete s.voices[${NOTE}]; })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}stopallnotes`, {
    message0: "stop all notes",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `(() => { const s = ${SYNTH}; Object.keys(s.voices).forEach(n => { const v = s.voices[n]; v.gain.gain.setTargetAtTime(0, s.ctx.currentTime, 0.05); v.osc.stop(s.ctx.currentTime + 0.2); }); s.voices = {}; })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}setinstrument`, {
    message0: "set instrument to %1",
    args0: [
      {
        "type": "field_dropdown",
        "name": "WAVE",
        "options": [
          ["piano-like (sine)", "sine"],
          ["organ-like (square)", "square"],
          ["string-like (sawtooth)", "sawtooth"],
          ["flute-like (triangle)", "triangle"]
        ]
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const WAVE = block.getFieldValue("WAVE");
    const code = `${SYNTH}.waveform = "${WAVE}";`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}resttime`, {
    message0: "rest for %1 beats",
    args0: [numberField("BEATS", 1)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const BEATS = javascriptGenerator.valueToCode(block, "BEATS");
    const code = `await new Promise(done => setTimeout(done, ${BEATS} * (60 / ${SYNTH}.tempo) * 1000));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}settempo`, {
    message0: "set tempo to %1",
    args0: [numberField("TEMPO", 60)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const TEMPO = javascriptGenerator.valueToCode(block, "TEMPO");
    const code = `${SYNTH}.tempo = ${TEMPO};`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}changetempo`, {
    message0: "change tempo by %1",
    args0: [numberField("CHANGE", 20)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const CHANGE = javascriptGenerator.valueToCode(block, "CHANGE");
    const code = `(() => { const s = ${SYNTH}; s.tempo += ${CHANGE}; })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}gettempo`, {
    message0: "tempo",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `${SYNTH}.tempo`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix}setvolume`, {
    message0: "set music volume to %1 %%",
    args0: [numberField("VOLUME", 100)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const VOLUME = javascriptGenerator.valueToCode(block, "VOLUME");
    const code = `${SYNTH}.volume = Math.max(0, Math.min(1, ${VOLUME} / 100));`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}getvolume`, {
    message0: "music volume",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `Math.round(${SYNTH}.volume * 100)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix}playsound`, {
    message0: "play sound %1 until done",
    args0: [textField("NAME", "pop")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `await Scratch.vm.runtime.ext_scratch3_sound.playSoundAndWaitForFinish({ SOUND_MENU: ${NAME} }, { target: (Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage)) });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}startsound`, {
    message0: "start sound %1",
    args0: [textField("NAME", "pop")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `Scratch.vm.runtime.ext_scratch3_sound.playSound({ SOUND_MENU: ${NAME} }, { target: (Scratch.vm.runtime.getEditingTarget() || Scratch.vm.runtime.targets.find(t => !t.isStage)) });`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}stopallsounds`, {
    message0: "stop all sounds",
    args0: [],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `Scratch.vm.runtime.stopAllSounds();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midienable`, {
    message0: "connect midi device %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `await (async () => { const s = ${MIDI}; s.midiAccess = await navigator.requestMIDIAccess({ sysex: false }); ${BLOCKS} })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midioutputs`, {
    message0: "midi output devices",
    args0: [],
    output: "List",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `(() => { const s = ${MIDI}; return s.midiAccess ? Array.from(s.midiAccess.outputs.values()).map(o => o.name) : []; })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix}midiinputs`, {
    message0: "midi input devices",
    args0: [],
    output: "List",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `(() => { const s = ${MIDI}; return s.midiAccess ? Array.from(s.midiAccess.inputs.values()).map(i => i.name) : []; })()`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix}midisetoutput`, {
    message0: "set midi output to %1",
    args0: [textField("NAME", "IAC Driver")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NAME = javascriptGenerator.valueToCode(block, "NAME");
    const code = `(() => { const s = ${MIDI}; if (!s.midiAccess) return; s.midiOutput = Array.from(s.midiAccess.outputs.values()).find(o => o.name === ${NAME}) || null; })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midisendnoteon`, {
    message0: "send midi note on %1 velocity %2 channel %3",
    args0: [numberField("NOTE", 60), numberField("VELOCITY", 100), numberField("CHANNEL", 1)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NOTE = javascriptGenerator.valueToCode(block, "NOTE");
    const VELOCITY = javascriptGenerator.valueToCode(block, "VELOCITY");
    const CHANNEL = javascriptGenerator.valueToCode(block, "CHANNEL");
    const code = `(() => { const s = ${MIDI}; if (!s.midiOutput) return; s.midiOutput.send([0x90 + (${CHANNEL} - 1), ${NOTE}, ${VELOCITY}]); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midisendnoteoff`, {
    message0: "send midi note off %1 channel %2",
    args0: [numberField("NOTE", 60), numberField("CHANNEL", 1)],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const NOTE = javascriptGenerator.valueToCode(block, "NOTE");
    const CHANNEL = javascriptGenerator.valueToCode(block, "CHANNEL");
    const code = `(() => { const s = ${MIDI}; if (!s.midiOutput) return; s.midiOutput.send([0x80 + (${CHANNEL} - 1), ${NOTE}, 0]); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midisendraw`, {
    message0: "send raw midi message %1",
    args0: [textField("BYTES", "144, 60, 100")],
    previousStatement: null,
    nextStatement: null,
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const BYTES = javascriptGenerator.valueToCode(block, "BYTES");
    const code = `(() => { const s = ${MIDI}; if (!s.midiOutput) return; s.midiOutput.send(String(${BYTES}).split(",").map(v => parseInt(v.trim(), 10))); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}whenmidimessage`, {
    message0: "when midi message received %1 %2",
    args0: [
      {
        "type": "input_dummy"
      },
      {
        "type": "input_statement",
        "name": "BLOCKS"
      }
    ],
    inputsInline: true,
    order: 1,
    colour: categoryColor
  }, (block) => {
    const BLOCKS = javascriptGenerator.statementToCode(block, "BLOCKS");
    const code = `(() => { const s = ${MIDI}; if (!s.midiAccess) return; Array.from(s.midiAccess.inputs.values()).forEach(input => { input.onmidimessage = (async (event) => { const status = event.data[0]; const note = event.data[1]; const velocity = event.data[2]; ${BLOCKS} }); }); })();`;
    return `${code}
`;
  });
  registerBlock(`${categoryPrefix}midimessagenote`, {
    message0: "midi message note",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `(typeof note !== "undefined" ? note : 0)`;
    return [`${code}`, 0];
  });
  registerBlock(`${categoryPrefix}midimessagevelocity`, {
    message0: "midi message velocity",
    args0: [],
    output: "Number",
    inputsInline: true,
    colour: categoryColor
  }, (block) => {
    const code = `(typeof velocity !== "undefined" ? velocity : 0)`;
    return [`${code}`, 0];
  });
}
const registerBlocks = (language2 = "en") => {
  register$f();
  register$d();
  register$c();
  register$e();
  register$b();
  register$a();
  register$9();
  register$8();
  register$7();
  register$6();
  register$5();
  register$4();
  register$3();
  register$2();
  register$1();
};
function register(workspace) {
  workspace.registerButtonCallback("variables_register", () => {
    window.modals["createVariable"].toggle();
  });
  workspace.registerButtonCallback("variables_remove", () => {
    let v = prompt("temporary delete variable prompt (put variable name here)");
    if (v != "") {
      delete window.variables[v];
      workspace.refreshToolboxSelection();
    }
  });
}
const css = {
  code: "#main.svelte-ox68os.svelte-ox68os{padding-top:3rem;height:calc(100% - 3rem)}#editor.svelte-ox68os.svelte-ox68os{display:flex;flex-direction:row;height:100%}.blockly-container.svelte-ox68os.svelte-ox68os{width:calc(100vw - 480px);height:100%}.code.svelte-ox68os.svelte-ox68os{width:480px;height:100%}.language-picker.svelte-ox68os.svelte-ox68os{display:flex;align-items:center;gap:0.35rem;padding:0 0.6rem;font-size:0.75rem;font-weight:bold}.language-picker.svelte-ox68os select.svelte-ox68os{max-width:10rem;outline:none;border:none;border-radius:0.25rem;background:#1a1a1a;padding:0.25rem 0.5rem;color:#fff}@media(max-width: 1280px){.blockly-container.svelte-ox68os.svelte-ox68os{width:100vw}.code.svelte-ox68os.svelte-ox68os{display:none}}",
  map: `{"version":3,"file":"+page.svelte","sources":["+page.svelte"],"sourcesContent":["<script lang=\\"ts\\">\\r\\n  import Blockly from \\"blockly/core\\";\\r\\n\\r\\n  import En from \\"blockly/msg/en\\";\\r\\n  import PtBr from \\"blockly/msg/pt-br\\";\\r\\n  import Es from \\"blockly/msg/es\\";\\r\\n  import \\"blockly/blocks\\";\\r\\n  import \\"blockly/javascript\\";\\r\\n\\r\\n  import JSZip from \\"jszip\\";\\r\\n  import * as FileSaver from \\"file-saver\\";\\r\\n  import fileDialog from \\"../resources/fileDialog\\";\\r\\n\\r\\n  import * as ContinuousToolboxPlugin from \\"@blockly/continuous-toolbox\\";\\r\\n\\r\\n  import Patches from \\"../patches\\";\\r\\n  import registerCategories from \\"../resources/categories\\";\\r\\n\\r\\n  import Toolbox from \\"$lib/Toolbox/Toolbox.xml?raw\\";\\r\\n\\r\\n  import BlocklyComponent from \\"$lib/svelte-blockly\\";\\r\\n  import { onMount } from \\"svelte\\";\\r\\n\\r\\n  import Compiler from \\"../resources/compiler\\";\\r\\n\\r\\n  import NavigationBar from \\"$lib/NavigationBar/NavigationBar.svelte\\";\\r\\n  import NavigationButton from \\"$lib/NavigationBar/Button.svelte\\";\\r\\n  import NavigationDivider from \\"$lib/NavigationBar/Divider.svelte\\";\\r\\n\\r\\n  import NavIconSave from \\"$lib/images/nav/save.svg\\";\\r\\n  import NavIconLoad from \\"$lib/images/nav/load.svg\\";\\r\\n  import NavIconExperiments from \\"$lib/images/nav/experiments.svg\\";\\r\\n  import NavIconDark from \\"$lib/images/nav/dark.svg\\";\\r\\n\\r\\n  import TabManager from \\"$lib/TabManager/TabManager.svelte\\";\\r\\n  import Tab from \\"$lib/TabManager/Tab.svelte\\";\\r\\n\\r\\n  import ExperimentsModal from \\"$lib/Modal/ExperimentsModal.svelte\\";\\r\\n  import CreateVariableModal from \\"$lib/Modal/CreateVariableModal.svelte\\";\\r\\n  import EditBlockModal from \\"$lib/Modal/EditBlockModal.svelte\\";\\r\\n\\r\\n  import CodePreview from \\"$lib/CodePreview/CodePreview.svelte\\";\\r\\n\\r\\n  import PropertiesPicker from \\"$lib/PropertiesPicker/PropertiesPicker.svelte\\";\\r\\n  import ExportMenu from \\"$lib/ExportMenu/ExportMenu.svelte\\";\\r\\n  import BlocksMenu from \\"$lib/BlocksMenu/BlocksMenu.svelte\\";\\r\\n  import { language, loadSavedLanguage, setLanguage, supportedLanguages, t, translateToolbox } from \\"$lib/i18n\\";\\r\\n\\r\\n  const blocklyMessages = {\\r\\n    en: En,\\r\\n    \\"pt-BR\\": PtBr,\\r\\n    es: Es,\\r\\n  };\\r\\n\\r\\n  $: blocklyLocale = {\\r\\n    rtl: false,\\r\\n    msg: blocklyMessages[$language],\\r\\n  };\\r\\n\\r\\n  const config = {\\r\\n    toolbox: Toolbox,\\r\\n    collapse: true,\\r\\n    comments: true,\\r\\n    scrollbars: true,\\r\\n    renderer: \\"custom_renderer\\",\\r\\n    zoom: {\\r\\n      controls: true,\\r\\n      wheel: true,\\r\\n      startScale: 0.8,\\r\\n      maxScale: 2,\\r\\n      minScale: 0.5,\\r\\n      scaleSpeed: 1.1,\\r\\n    },\\r\\n    plugins: {\\r\\n      toolbox: ContinuousToolboxPlugin.ContinuousToolbox,\\r\\n      flyoutsVerticalToolbox: ContinuousToolboxPlugin.ContinuousFlyout,\\r\\n      metricsManager: ContinuousToolboxPlugin.ContinuousMetrics,\\r\\n    },\\r\\n  };\\r\\n\\r\\n  $: localizedConfig = {\\r\\n    ...config,\\r\\n    toolbox: translateToolbox(Toolbox, $language),\\r\\n  };\\r\\n\\r\\n  let localConfig = {\\r\\n    dark: false,\\r\\n  };\\r\\n\\r\\n  function updateTheme() {\\r\\n    if (localConfig.dark) {\\r\\n      document.body.classList.add('dark')\\r\\n    } else {\\r\\n      document.body.classList.remove('dark')\\r\\n    }\\r\\n  }\\r\\n\\r\\n  Patches.Blockly.ToolboxFlyout(Blockly, config);\\r\\n  Patches.Blockly.Renderer(Blockly);\\r\\n  Patches.Blockly.DuplicateDrag(Blockly);\\r\\n  \\r\\n  import registerBlocks from \\"../resources/blocks\\"\\r\\n  import registerButtons from \\"../resources/buttons\\"\\r\\n  $: if (typeof window !== \\"undefined\\" && $language) {\\r\\n    registerBlocks($language);\\r\\n  }\\r\\n\\r\\n  /** @type {import('blockly').Workspace} */\\r\\n  let workspace;\\r\\n  let compiler = new Compiler();\\r\\n  let code;\\r\\n  let properties = {\\r\\n    name: \\"Extension\\",\\r\\n    id: \\"extensionID\\",\\r\\n    color: \\"#0fbd8c\\",\\r\\n  };\\r\\n\\r\\n  function updateGeneratedCode() {\\r\\n    if (!workspace) return;\\r\\n    code = compiler.compile(workspace, properties);\\r\\n  }\\r\\n\\r\\n  let connectedWorkspace;\\r\\n  $: if (workspace && workspace !== connectedWorkspace) {\\r\\n    connectedWorkspace = workspace;\\r\\n    window.workspace = workspace;\\r\\n    registerCategories(workspace);\\r\\n    registerButtons(workspace);\\r\\n    workspace.addChangeListener(() => {\\r\\n      updateGeneratedCode();\\r\\n    });\\r\\n    updateGeneratedCode();\\r\\n  }\\r\\n\\r\\n  function openModal(id) {\\r\\n    window.modals[id].toggle();\\r\\n  }\\r\\n\\r\\n  function downloadProject() {\\r\\n    let filteredProjectName = properties.id.replace(/[^a-z0-9\\\\-]+/gim, \\"_\\");\\r\\n    let fileName = filteredProjectName + \\".exf\\";\\r\\n\\r\\n    let projectData = Blockly.serialization.workspaces.save(workspace);\\r\\n\\r\\n    projectData = {\\r\\n      blockly: projectData,\\r\\n      properties: properties,\\r\\n      variables: window.variables || {},\\r\\n      blocks: window.blocks || {}\\r\\n    };\\r\\n\\r\\n    // zip\\r\\n    const zip = new JSZip();\\r\\n    zip.file(\\r\\n      \\"README.txt\\",\\r\\n      \\"This file is not meant to be opened!\\" +\\r\\n        \\"\\\\nBe careful as you can permanently break your extension!\\",\\r\\n    );\\r\\n\\r\\n    // data\\r\\n    const data = zip.folder(\\"data\\");\\r\\n    data.file(\\"project.json\\", JSON.stringify(projectData));\\r\\n\\r\\n    // download\\r\\n    zip.generateAsync({ type: \\"blob\\" }).then((blob) => {\\r\\n      FileSaver.saveAs(blob, fileName);\\r\\n    });\\r\\n  }\\r\\n\\r\\n  function loadProject() {\\r\\n    fileDialog({ accept: \\".exf\\" }).then((files) => {\\r\\n      if (!files) return;\\r\\n      const file = files[0];\\r\\n\\r\\n      const projectNameIdx = file.name.lastIndexOf(\\".exf\\");\\r\\n\\r\\n      JSZip.loadAsync(file.arrayBuffer()).then(async (zip) => {\\r\\n        const dataFolder = zip.folder(\\"data\\");\\r\\n        const projectJsonString = await dataFolder\\r\\n          .file(\\"project.json\\")\\r\\n          .async(\\"string\\");\\r\\n        const projectJson = JSON.parse(projectJsonString);\\r\\n\\r\\n        properties.name = projectJson.properties.name ?? \\"Extension\\";\\r\\n        properties.id = projectJson.properties.id ?? \\"extensionID\\";\\r\\n        properties.color = projectJson.properties.color ?? \\"#0fbd8c\\";\\r\\n\\r\\n        window.variables = projectJson.variables ?? {};\\r\\n        window.blocks = projectJson.blocks ?? {};\\r\\n\\r\\n        Blockly.serialization.workspaces.load(projectJson.blockly, workspace);\\r\\n\\r\\n        updateGeneratedCode();\\r\\n      });\\r\\n    });\\r\\n  }\\r\\n\\r\\n  onMount(() => {\\r\\n    code = \\"\\";\\r\\n    loadSavedLanguage();\\r\\n\\r\\n    window.Blockly = Blockly;\\r\\n    window.workspace = workspace;\\r\\n    window.variables = {};\\r\\n    window.blocks = {};\\r\\n\\r\\n    registerCategories(workspace);\\r\\n\\r\\n    updateTheme();\\r\\n\\r\\n    addEventListener('beforeunload', event => {\\r\\n      try {\\r\\n        if (workspace.getAllBlocks().length > 0) {\\r\\n          event.preventDefault();\\r\\n          event.returnValue = true;\\r\\n        }\\r\\n      } catch {}\\r\\n    })\\r\\n\\r\\n    let newconfig = localStorage.getItem('localConfig')\\r\\n    if (newconfig) {\\r\\n      localConfig.dark = JSON.parse(newconfig).dark ?? false\\r\\n      updateTheme()\\r\\n    }\\r\\n\\r\\n    addEventListener('unload', event => {\\r\\n      localStorage.setItem('localConfig', JSON.stringify(localConfig))\\r\\n    })\\r\\n  });\\r\\n<\/script>\\r\\n\\r\\n<head>\\r\\n  <title>CapivaraMod Builder</title>\\r\\n</head>\\r\\n\\r\\n<NavigationBar>\\r\\n  <NavigationButton icon={NavIconDark} on:click={() => {\\r\\n    localConfig.dark = !localConfig.dark;\\r\\n    updateTheme()\\r\\n  }}></NavigationButton>\\r\\n  <NavigationDivider />\\r\\n  <NavigationButton icon={NavIconSave} on:click={downloadProject}>\\r\\n    {t(\\"save\\", $language)}\\r\\n  </NavigationButton>\\r\\n  <NavigationButton icon={NavIconLoad} on:click={loadProject}>\\r\\n    {t(\\"load\\", $language)}\\r\\n  </NavigationButton>\\r\\n  <NavigationDivider />\\r\\n  <NavigationButton icon={NavIconExperiments} on:click={() => openModal(\\"experiments\\")}>\\r\\n    {t(\\"experiments\\", $language)}\\r\\n  </NavigationButton>\\r\\n  <NavigationDivider />\\r\\n  <NavigationButton on:click={() => window.open(\\"https://discord.gg/NeYug9v2hq\\", '_blank')}>\\r\\n    {t(\\"discord\\", $language)}\\r\\n  </NavigationButton>\\r\\n  <label class=\\"language-picker\\">\\r\\n    <span>{t(\\"language\\", $language)}</span>\\r\\n    <select value={$language} on:change={(event) => setLanguage(event.currentTarget.value)}>\\r\\n      {#each supportedLanguages as option}\\r\\n        <option value={option.id}>{option.label}</option>\\r\\n      {/each}\\r\\n    </select>\\r\\n  </label>\\r\\n</NavigationBar>\\r\\n<div id=\\"main\\">\\r\\n  <TabManager let:activeTab let:tabs let:handleTabClick let:registerTab>\\r\\n    <Tab title={t(\\"editor\\", $language)} {activeTab} {tabs} {handleTabClick} {registerTab}>\\r\\n      <div id=\\"editor\\">\\r\\n        <div class=\\"blockly-container\\">\\r\\n          <BlocklyComponent config={localizedConfig} locale={blocklyLocale} bind:workspace />\\r\\n        </div>\\r\\n        <div class=\\"code\\">\\r\\n          <CodePreview {code} />\\r\\n        </div>\\r\\n      </div>\\r\\n    </Tab>\\r\\n    <Tab title={t(\\"blocks\\", $language)} {activeTab} {tabs} {handleTabClick} {registerTab}>\\r\\n      <BlocksMenu />\\r\\n    </Tab>\\r\\n    <Tab title={t(\\"properties\\", $language)} {activeTab} {tabs} {handleTabClick} {registerTab}>\\r\\n      <PropertiesPicker {properties} on:update={updateGeneratedCode} />\\r\\n    </Tab>\\r\\n    <Tab title={t(\\"export\\", $language)} {activeTab} {tabs} {handleTabClick} {registerTab}>\\r\\n      <ExportMenu {code} />\\r\\n    </Tab>\\r\\n  </TabManager>\\r\\n</div>\\r\\n<ExperimentsModal />\\r\\n<CreateVariableModal />\\r\\n<EditBlockModal />\\r\\n\\r\\n<style>\\r\\n  #main {\\r\\n    padding-top: 3rem;\\r\\n    height: calc(100% - 3rem);\\r\\n  }\\r\\n\\r\\n  #editor {\\r\\n    display: flex;\\r\\n    flex-direction: row;\\r\\n    height: 100%;\\r\\n  }\\r\\n\\r\\n  .blockly-container {\\r\\n    width: calc(100vw - 480px);\\r\\n    height: 100%;\\r\\n  }\\r\\n\\r\\n  .code {\\r\\n    width: 480px;\\r\\n    height: 100%;\\r\\n  }\\r\\n\\r\\n  .language-picker {\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n    gap: 0.35rem;\\r\\n    padding: 0 0.6rem;\\r\\n    font-size: 0.75rem;\\r\\n    font-weight: bold;\\r\\n  }\\r\\n\\r\\n  .language-picker select {\\r\\n    max-width: 10rem;\\r\\n    outline: none;\\r\\n    border: none;\\r\\n    border-radius: 0.25rem;\\r\\n    background: #1a1a1a;\\r\\n    padding: 0.25rem 0.5rem;\\r\\n    color: #fff;\\r\\n  }\\r\\n\\r\\n  @media (max-width: 1280px) {\\r\\n    .blockly-container {\\r\\n      width: 100vw;\\r\\n    }\\r\\n\\r\\n    .code {\\r\\n      display: none;\\r\\n    }\\r\\n  }\\r\\n</style>\\r\\n"],"names":[],"mappings":"AAoSE,iCAAM,CACJ,WAAW,CAAE,IAAI,CACjB,MAAM,CAAE,KAAK,IAAI,CAAC,CAAC,CAAC,IAAI,CAC1B,CAEA,mCAAQ,CACN,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,GAAG,CACnB,MAAM,CAAE,IACV,CAEA,8CAAmB,CACjB,KAAK,CAAE,KAAK,KAAK,CAAC,CAAC,CAAC,KAAK,CAAC,CAC1B,MAAM,CAAE,IACV,CAEA,iCAAM,CACJ,KAAK,CAAE,KAAK,CACZ,MAAM,CAAE,IACV,CAEA,4CAAiB,CACf,OAAO,CAAE,IAAI,CACb,WAAW,CAAE,MAAM,CACnB,GAAG,CAAE,OAAO,CACZ,OAAO,CAAE,CAAC,CAAC,MAAM,CACjB,SAAS,CAAE,OAAO,CAClB,WAAW,CAAE,IACf,CAEA,8BAAgB,CAAC,oBAAO,CACtB,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,IAAI,CACb,MAAM,CAAE,IAAI,CACZ,aAAa,CAAE,OAAO,CACtB,UAAU,CAAE,OAAO,CACnB,OAAO,CAAE,OAAO,CAAC,MAAM,CACvB,KAAK,CAAE,IACT,CAEA,MAAO,YAAY,MAAM,CAAE,CACzB,8CAAmB,CACjB,KAAK,CAAE,KACT,CAEA,iCAAM,CACJ,OAAO,CAAE,IACX,CACF"}`
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let blocklyLocale;
  let localizedConfig;
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  const blocklyMessages = { en: En, "pt-BR": PtBr, es: Es };
  const config = {
    toolbox: Toolbox,
    collapse: true,
    comments: true,
    scrollbars: true,
    renderer: "custom_renderer",
    zoom: {
      controls: true,
      wheel: true,
      startScale: 0.8,
      maxScale: 2,
      minScale: 0.5,
      scaleSpeed: 1.1
    },
    plugins: {
      toolbox: ContinuousToolboxPlugin.ContinuousToolbox,
      flyoutsVerticalToolbox: ContinuousToolboxPlugin.ContinuousFlyout,
      metricsManager: ContinuousToolboxPlugin.ContinuousMetrics
    }
  };
  Patches.Blockly.ToolboxFlyout(Blockly, config);
  Patches.Blockly.Renderer(Blockly);
  Patches.Blockly.DuplicateDrag(Blockly);
  let workspace;
  let compiler = new Compiler();
  let code;
  let properties = {
    name: "Extension",
    id: "extensionID",
    color: "#0fbd8c"
  };
  function updateGeneratedCode() {
    if (!workspace) return;
    code = compiler.compile(workspace, properties);
  }
  let connectedWorkspace;
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    blocklyLocale = {
      rtl: false,
      msg: blocklyMessages[$language]
    };
    localizedConfig = {
      ...config,
      toolbox: translateToolbox(Toolbox, $language)
    };
    {
      if (typeof window !== "undefined" && $language) {
        registerBlocks($language);
      }
    }
    {
      if (workspace && workspace !== connectedWorkspace) {
        connectedWorkspace = workspace;
        window.workspace = workspace;
        registerCategories(workspace);
        register(workspace);
        workspace.addChangeListener(() => {
          updateGeneratedCode();
        });
        updateGeneratedCode();
      }
    }
    $$rendered = `<head data-svelte-h="svelte-1rt5khf"><title>CapivaraMod Builder</title></head> ${validate_component(NavigationBar, "NavigationBar").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(Button, "NavigationButton").$$render($$result, { icon: NavIconDark }, {}, {})} ${validate_component(Divider, "NavigationDivider").$$render($$result, {}, {}, {})} ${validate_component(Button, "NavigationButton").$$render($$result, { icon: NavIconSave }, {}, {
          default: () => {
            return `${escape(t("save", $language))}`;
          }
        })} ${validate_component(Button, "NavigationButton").$$render($$result, { icon: NavIconLoad }, {}, {
          default: () => {
            return `${escape(t("load", $language))}`;
          }
        })} ${validate_component(Divider, "NavigationDivider").$$render($$result, {}, {}, {})} ${validate_component(Button, "NavigationButton").$$render($$result, { icon: NavIconExperiments }, {}, {
          default: () => {
            return `${escape(t("experiments", $language))}`;
          }
        })} ${validate_component(Divider, "NavigationDivider").$$render($$result, {}, {}, {})} ${validate_component(Button, "NavigationButton").$$render($$result, {}, {}, {
          default: () => {
            return `${escape(t("discord", $language))}`;
          }
        })} <label class="language-picker svelte-ox68os"><span>${escape(t("language", $language))}</span> <select${add_attribute("value", $language, 0)} class="svelte-ox68os">${each(supportedLanguages, (option) => {
          return `<option${add_attribute("value", option.id, 0)}>${escape(option.label)}</option>`;
        })}</select></label>`;
      }
    })} <div id="main" class="svelte-ox68os">${validate_component(TabManager, "TabManager").$$render($$result, {}, {}, {
      default: ({ activeTab, tabs, handleTabClick, registerTab }) => {
        return `${validate_component(Tab, "Tab").$$render(
          $$result,
          {
            title: t("editor", $language),
            activeTab,
            tabs,
            handleTabClick,
            registerTab
          },
          {},
          {
            default: () => {
              return `<div id="editor" class="svelte-ox68os"><div class="blockly-container svelte-ox68os">${validate_component(Component, "BlocklyComponent").$$render(
                $$result,
                {
                  config: localizedConfig,
                  locale: blocklyLocale,
                  workspace
                },
                {
                  workspace: ($$value) => {
                    workspace = $$value;
                    $$settled = false;
                  }
                },
                {}
              )}</div> <div class="code svelte-ox68os">${validate_component(CodePreview, "CodePreview").$$render($$result, { code }, {}, {})}</div></div>`;
            }
          }
        )} ${validate_component(Tab, "Tab").$$render(
          $$result,
          {
            title: t("blocks", $language),
            activeTab,
            tabs,
            handleTabClick,
            registerTab
          },
          {},
          {
            default: () => {
              return `${validate_component(BlocksMenu, "BlocksMenu").$$render($$result, {}, {}, {})}`;
            }
          }
        )} ${validate_component(Tab, "Tab").$$render(
          $$result,
          {
            title: t("properties", $language),
            activeTab,
            tabs,
            handleTabClick,
            registerTab
          },
          {},
          {
            default: () => {
              return `${validate_component(PropertiesPicker, "PropertiesPicker").$$render($$result, { properties }, {}, {})}`;
            }
          }
        )} ${validate_component(Tab, "Tab").$$render(
          $$result,
          {
            title: t("export", $language),
            activeTab,
            tabs,
            handleTabClick,
            registerTab
          },
          {},
          {
            default: () => {
              return `${validate_component(ExportMenu, "ExportMenu").$$render($$result, { code }, {}, {})}`;
            }
          }
        )}`;
      }
    })}</div> ${validate_component(ExperimentsModal, "ExperimentsModal").$$render($$result, {}, {}, {})} ${validate_component(CreateVariableModal, "CreateVariableModal").$$render($$result, {}, {}, {})} ${validate_component(EditBlockModal, "EditBlockModal").$$render($$result, {}, {}, {})}`;
  } while (!$$settled);
  $$unsubscribe_language();
  return $$rendered;
});
export {
  Page as default
};
