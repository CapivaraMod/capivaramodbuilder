

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CRguoaJH.js","_app/immutable/chunks/scheduler.B1eZZyvF.js","_app/immutable/chunks/index.Cxp2rW5O.js","_app/immutable/chunks/entry.DuWPDUlt.js","_app/immutable/chunks/index.Bk2mAaNR.js"];
export const stylesheets = [];
export const fonts = [];
