

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DmCjPkWU.js","_app/immutable/chunks/scheduler.B1eZZyvF.js","_app/immutable/chunks/index.Cxp2rW5O.js","_app/immutable/chunks/index.Bk2mAaNR.js"];
export const stylesheets = ["_app/immutable/assets/2.CcMsrbnH.css"];
export const fonts = [];
